/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import edu.stanford.cs.ra.xml.XMLStream;
import edu.stanford.cs.ra.xml.XMLStringBuilder;

/**
 * Lineage of a {@link StageWise} computation. This class can be used as a
 * signature for a {@link StageWise} instance by holding its name, version code,
 * and argument values.
 * 
 * This class is used by {@link CheckpointSet} to compare canonical serialized
 * descriptions of stage computations (which stages were involved, what were
 * their arguments).
 * 
 * Use the static methods to instantiate this class.
 * 
 * @author dramage
 */
public class StageLineage implements Serializable {
	
	//
	// static constructor
	//
	
	/**
	 * Instantiates a StageLineage instance representing the lineage required
	 * to run the given StageRunner.
	 */
	public static StageLineage fromStageRunner(StageRunner stage) {
		return fromStageRunner(stage, new LinkedList<StageDescriptor>());
	}
	
	private static StageLineage fromStageRunner(StageRunner stage, List<StageDescriptor> visited) {
		visited = new LinkedList<StageDescriptor>(visited);
		visited.add(stage.getStageDescriptor());
		
		List<StageLineage> prereqs = new LinkedList<StageLineage>();
		
		for (StageRunner prereq : stage.getRequiredStages()) {
			StageWise.assertNoCircularDependency(prereq.getStageDescriptor(), visited);
			
			prereqs.add(fromStageRunner(prereq, visited));
		}
		
		return new StageLineage(stage.getStageDescriptor(), prereqs);
	}
	
	//
	// class
	// 
	
	/** StageDescriptor name */
	private final StageDescriptor descriptor;
	
	/** Prerequisites of this stage */
	private final List<StageLineage> prereqs;
	
	private StageLineage(StageDescriptor descriptor, List<StageLineage> prereqs) {
		// save descriptor
		this.descriptor = descriptor;
		
		// save provided parent lineages, sorted by name
		prereqs = new LinkedList<StageLineage>(prereqs);
		Collections.sort(prereqs, new Comparator<StageLineage>() {
			public int compare(StageLineage a, StageLineage b) {
				return a.descriptor.name.compareTo(b.descriptor.name);
			}
		});
		this.prereqs = Collections.unmodifiableList(prereqs);
	}

	/**
	 * Describes this Stage canonically to the given XMLStream.
	 */
	public void toXML(XMLStream stream) {
		stream.begin("Lineage");
		toXMLWithoutBookends(stream);
		stream.end("Lineage");
	}
	
	private void toXMLWithoutBookends(XMLStream stream) {
		descriptor.toXML(stream);
		for (StageLineage lineage : prereqs) {
			lineage.toXMLWithoutBookends(stream);
		}
	}
	
	/** Returns the globally unique name of this stage. */
	public String getName() {
		return descriptor.name;
	}
	
	/**
	 * Returns a canonical signature of this lineage.
	 */
	@Override
	public String toString() {
		XMLStringBuilder builder = new XMLStringBuilder();
		toXML(builder);
		return builder.toString();
	}
	
	@Override
	public boolean equals(Object other) {
		return other instanceof StageLineage
			&& ((StageLineage)other).descriptor.equals(this.descriptor)
			&& ((StageLineage)other).prereqs.equals(this.prereqs);
	}
	
	@Override
	public int hashCode() {
		int hashcode = descriptor.hashCode() * 31;
		
		// it's important that the hashcode here is order independent
		for (StageLineage prereq : prereqs) {
			hashcode += prereq.hashCode();
		}
		
		return hashcode;
	}
	
	private static final long serialVersionUID = 1L;
}
