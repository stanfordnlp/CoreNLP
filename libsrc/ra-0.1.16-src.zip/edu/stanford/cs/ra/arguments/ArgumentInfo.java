/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.io.Serializable;
import java.lang.reflect.Field;


/**
 * Information about a particular argument for parsing / populating from String.
 * Two ArgumentInfo instances are equal if they have the same name and type.
 * Get an instance using either {@link ArgumentInfoBuilder} or
 * {@link ArgumentInfo#fromField(Field)}. 
 * 
 * @author dramage
 */
public final class ArgumentInfo implements Serializable {
	
	/** Separates box name from argument name - cannot be in argument name */
	private final static String SEPARATOR = ".";
	
	/**
	 * Returns an ArgumentInfo instance populated by reflection on the
	 * given Field.
	 */
	public static ArgumentInfo fromField(Field field) {
		if (field.getAnnotation(Argument.class) == null) {
			throw new ArgumentException(field+" is not an @Argument");
		}
		
		Class<?> declaring = field.getDeclaringClass();
		
		String boxname = declaring.getAnnotation(Argument.BoxName.class) != null
			? declaring.getAnnotation(Argument.BoxName.class).value()
			: declaring.getName();
		
		String name = field.getAnnotation(Argument.Name.class) != null
			? field.getAnnotation(Argument.Name.class).value()
			: field.getName();
		
		ArgumentInfoBuilder builder
			= new ArgumentInfoBuilder(field.getType()).boxName(boxname).argName(name);
		
		if (field.getAnnotation(Argument.Default.class) != null) {
			builder.defaultValue(field.getAnnotation(Argument.Default.class).value());
		}
		
		builder.description(field.getAnnotation(Argument.class).value());
		
		if (field.getAnnotation(Argument.Policy.class) != null) {
			builder.policy(field.getAnnotation(Argument.Policy.class).value());
		}
		
		if (field.getAnnotation(Argument.Switch.class) != null) {
			builder.switches(field.getAnnotation(Argument.Switch.class).value());
		}
		
		if (field.getType().isAssignableFrom(Flag.class)) {
			if (field.getAnnotation(Argument.Default.class) == null) {
				builder.defaultValue("false");
			}
			
			builder.commandStringsConsumed(0);
		}
		
		return builder.build();
	}

	/**
	 * Helper class for building instances of ArgumentInfo.
	 * 
	 * @author dramage
	 */
	public static class ArgumentInfoBuilder {
		private final Class<?> type;
		private String boxName;
		private String argName;
		private String defaultValue = null;
		private String description = "(no description provided)";
		private ArgumentPolicy policy = ArgumentPolicy.DEFAULT;
		private String[] switches = new String[0];
		private int commandStringsConsumed = 1;
		
		/** Sets the type of this argument and name of containing box. */
		public ArgumentInfoBuilder(Class<?> type) {
			this.type = type;
		}
		
		/**
		 * Sets the fully qualified name of this argument - not compatible
		 * with calls to boxName and argName.  Assumes box and arg name
		 * are split by last instance of SEPARATOR. 
		 */
		public ArgumentInfoBuilder qualifiedName(String name) {
			if (boxName != null || argName != null) {
				throw new IllegalArgumentException("Name already set");
			}
			boxName = name.substring(0, name.lastIndexOf(SEPARATOR));
			argName = name.substring(name.lastIndexOf(SEPARATOR)+1);
			return this;
		}
		
		/**
		 * Sets the name of the box this argument is part of. Not compatible
		 * with qualifiedName.
		 */
		public ArgumentInfoBuilder boxName(String name) {
			if (boxName != null) {
				throw new IllegalArgumentException("Name already set");
			}
			boxName = name;
			return this;
		}
		
		/**
		 * Sets the argument's unqualified name.  Not compatible with
		 * qualifiedName.
		 */
		public ArgumentInfoBuilder argName(String name) {
			if (argName != null) {
				throw new IllegalArgumentException("Name already set");
			}
			
			if (name.contains(SEPARATOR)) {
				throw new IllegalArgumentException(
						"Argument name cannot contain "+SEPARATOR);
			}
			argName = name;
			return this;
		}
		
		/** Default value for this argument or null for no default */
		public ArgumentInfoBuilder defaultValue(String defaultValue) {
			this.defaultValue = defaultValue;
			return this;
		}
		
		/** Sets the human readable description of this Argument. */
		public ArgumentInfoBuilder description(String description) {
			this.description = description;
			return this;
		}
		
		/** Sets the policy for this argument */
		public ArgumentInfoBuilder policy(ArgumentPolicy policy) {
			this.policy = policy;
			return this;
		}
		
		/**
		 * Sets the set of command line switches that can be used to mark
		 * this argument on the command line.
		 */
		public ArgumentInfoBuilder switches(String ... switches) {
			this.switches = switches;
			return this;
		}

		/**
		 * Sets the number of command line strings are consumed by this switch.
		 */
		public ArgumentInfoBuilder commandStringsConsumed(
				int commandStringsConsumed) {
			this.commandStringsConsumed = commandStringsConsumed;
			return this;
		}
		
		/**
		 * Creates an instance of ArgumentInfo reflecting the values in this
		 * builder.
		 */
		public ArgumentInfo build() {
			if (boxName == null || argName == null) {
				throw new IllegalArgumentException("Cannot build unless" +
						"boxName and argName are both specified.");
			}
			
			return new ArgumentInfo(boxName, argName, type, defaultValue,
					description, policy, switches, commandStringsConsumed);
		}
	}
	
	
	//
	// actual data structure
	//
	
	private final String name;
	private final Class<?> type;
	private final String defaultValue;
	private final String description;
	private final ArgumentPolicy policy;
	private final String[] switches;
	private final int commandStringsConsumed;
	
	/**
	 * Private constructor - instantiate with ArgumentInfoBuilder.
	 */
	private ArgumentInfo(String boxName, String argName, Class<?> type,
			String defaultValue, String description, ArgumentPolicy policy,
			String[] switches, int commandStringsConsumed) {
		
		this.name = boxName + SEPARATOR + argName;
		this.type = type;
		this.defaultValue = defaultValue;
		this.description = description;
		this.policy = policy;
		this.switches = new String[switches.length];
		for (int i = 0; i < switches.length; i++) {
			this.switches[i] = switches[i];
		}
		this.commandStringsConsumed = commandStringsConsumed;
	}
	
	/**
	 * Returns the name of this argument's box
	 */
	public String getBoxName() {
		return name.substring(0, name.lastIndexOf(SEPARATOR));
	}
	
	/**
	 * Returns the name for this argument within its argument box.
	 */
	public String getArgName() {
		return name.substring(name.lastIndexOf(SEPARATOR)+1);
	}
	
	/**
	 * Returns the globally unique name of this argument as
	 * getBoxName()+getArgName()
	 */
	public String getQualifiedName() {
		return name;
	}
	
	/** Returns the type of the wrapped argument. */
	public Class<?> getType() {
		return type;
	}
	
	/**
	 * Returns the default value for this Argument or null is no default
	 * is defined.
	 */
	public String getDefault() {
		return defaultValue;
	}
	
	/**
	 * Returns a description of this argument.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Returns the policy for populating this argument.
	 */
	public ArgumentPolicy getPolicy() {
		return policy;
	}

	/**
	 * Returns an array of all command line switches that can be used to specify
	 * this argument on the comamnd line.
	 */
	public String[] getSwitches() {
		String[] tmp = new String[switches.length];
		for (int i = 0; i < switches.length; i++) {
			tmp[i] = switches[i];
		}
		return tmp;
	}

	/**
	 * Returns the number of strings following a switch to be consumed
	 * by this argument.  May currently be either 0 (for flags) or 1 (for
	 * everything else).
	 */
	public int getCommandStringsConsumed() {
		return commandStringsConsumed;
	}
	
	/**
	 * Returns a verbose multi-line description of this argument.
	 */
	public String toDescriptionString(String prefix) {
		StringBuilder builder = new StringBuilder().append(prefix);

		for (String swtch : getSwitches()) {
			builder.append(swtch).append(",");
		}
		builder.replace(builder.length()-1, builder.length(), " ");

		Class<?> type = getType();
		while (type.isArray()) {
			type = type.getComponentType();
			builder.append("list-of-");
		}
		
		if (type.isEnum()) {
			builder.append("{ ");
			for (Object val : type.getEnumConstants()) {
				builder.append(val).append(" ");
			}
			builder.replace(builder.lastIndexOf(" "), builder.length(), " }");
			builder.append(" ");
		} else if (type != Flag.class) {
			builder.append(type.getName()).append(" ");
		}

		builder.append("[").append(getPolicy()).append("]");
		
		if (getDefault() != null) {
			builder.append(" Default: ").append(getDefault());
		}
		
		for (String line : getDescription().split("\\n *")) {
			builder.append("\n").append(prefix).append(line);
		}
		
		return builder.append("\n").toString();
	}
	
	@Override
	public boolean equals(Object other) {
		if (other == null || other.getClass() != this.getClass()) {
			return false;
		}
		
		ArgumentInfo arg = (ArgumentInfo) other;
		return this.name.equals(arg.name)
			&& this.type.equals(arg.type);
	}
	
	@Override
	public int hashCode() {
		return this.name.hashCode() * 31 + this.type.hashCode();
	}
	
	@Override
	public String toString() {
		return getQualifiedName();
	}
	
	private static final long serialVersionUID = 1L;
}
