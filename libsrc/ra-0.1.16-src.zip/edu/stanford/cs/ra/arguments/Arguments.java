/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.lang.reflect.Constructor;
import java.util.List;

/**
 * Command line argument helper tool. Fields that need values read from the
 * command line can define those arguments using the Arg* annotations. Then,
 * parse an input argv into a collection of Objects that define Arg* annotations
 * using {@link Arguments#parse(String[], Object...)}.
 * 
 * @author dramage
 */
public class Arguments {

	// TODO: allow arguments to be specified on arguments to a constructor
	// TODO: allow InputStream and OutputStream to be specified instead of File
	
	static {
		// ensure that Flag gets loaded by classloader so its static block runs
		new Flag(true);
	}
	
	@Argument.BoxName("Arguments")
	private static class ArgumentCommandLineArgs {
		@Argument("Print usage information and exit")
		@Argument.Switch("--help")
		@Argument.Policy(ArgumentPolicy.OPTIONAL)
		Flag argHelp;
	}
		

	/**
	 * Parses the given command line arguments into the given list
	 * of target objects (which have fields decorated with Argument.Switch,
	 * ArgMessage, etc.).  On encountering an error, throws an
	 * ArgumentException.
	 * 
	 * @return List of warning messages, if any
	 * @throws ArgumentException on error parsing or populating targets
	 */
	public static ArgumentPopulatorResult parse(String[] args, Object ... targets) throws ArgumentException {
		ArgumentCommandLineArgs box = new ArgumentCommandLineArgs();
		
		List<ArgumentBox> boxes = ArgumentBoxes.fromInstances(targets);
		boxes.add(ArgumentBoxes.fromInstance(box));
		
		ArgumentPopulator populator = ArgumentPopulators.fromCommandLineWithProps(args);
		ArgumentPopulatorResult result = populator.populate(boxes);
		
		// display warnings
		for (String warning : result.getWarnings()) {
			System.out.println("Warning: "+warning);
		}
		
		// do help and exit if requested
		if (box.argHelp.isSet) {
			System.out.println(ArgumentBoxes.usage(boxes));
			System.exit(-1);
		}
		
		return result;
	}

	//
	// Utility methods for dealing with argument boxes
	//

	/**
	 * Checks and instantiates the given type as an argument box, setting
	 * default values, and returning an instance.
	 */
	public static <T> T instantiate(Class<T> type) {
		Object instance;
		try {
			Constructor<T> constructor; 
			try {
				constructor = type.getDeclaredConstructor();
			} catch (NoSuchMethodException e) {
				constructor = type.getConstructor();
			}
			
			synchronized (constructor) {
				boolean accessible = constructor.isAccessible();
				constructor.setAccessible(true);
				instance = constructor.newInstance();
				constructor.setAccessible(accessible);
			}
		} catch (Exception e) {
			try {
				instance = type.newInstance();
			} catch (Exception e2) {
				e.printStackTrace();
				throw new ArgumentException("Unexpected failure to instantiate - does "+type+" have a public no-arg constructor?  If it is an inner class, is it static?", e);
			}
		}
		
		ArgumentBoxes.setDefaultValues(ArgumentBoxes.fromInstance(instance));

		return type.cast(instance);
	}
	
	
	//
	// actual main method
	//
	
	/**
	 * If this class's main() method is invoked, assume a class name as
	 * first argument.
	 */
	@Argument("Name of class to output default XML for")
	@Argument.Switch("--generate-props")
	@Argument.Policy(ArgumentPolicy.REQUIRED)
	private static Class<?> type;

	/**
	 * Generates a .props file for a given class name.
	 */
	public static void main(String[] argv) throws Exception {
		Arguments.parse(argv, Arguments.class);
		ArgumentBox box = ArgumentBoxes.fromInstance(Arguments.instantiate(type));
		System.out.println(ArgumentBoxes.asProps(box));
	}
	
}
