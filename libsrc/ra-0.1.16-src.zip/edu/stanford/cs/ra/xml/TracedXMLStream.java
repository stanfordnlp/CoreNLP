/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.stanford.cs.ra.util.ReflectionUtils;

/**
 * An XMLStream wrapper that adds flexible control over which lines
 * are added or traced in the wrapped stream.
 * 
 * @author dramage
 */
public class TracedXMLStream implements XMLStream {

	/** Wrapped builder */
	private final XMLStream builder;
	
	/** (ordered) list of actions to take */
	private final List<TagAction> conditions
	  = new LinkedList<TagAction>();
	
	/** private stack of all states seen */
	private final LinkedList<String> tagStack
	  = new LinkedList<String>();
	
	/** immutable view of tagStack */
	private final List<String> tagStackView
	  = Collections.unmodifiableList(tagStack);
	
	/** state of each element in the wrapped stack */
	private final LinkedList<ActionType> stateStack
	  = new LinkedList<ActionType>();
	
	/** immutable view of stateStack */
	private final List<ActionType> stateStackView
	  = Collections.unmodifiableList(stateStack);

	/** last seen trace for a given tag */
	private final Map<String,StackTraceElement> lastTrace
	  = new HashMap<String,StackTraceElement>();
	
	/** how many SUPPRESS levels we are deep */
	private int suppress = 0;
	
	/** true if we are closed */
	private boolean closed = false;
	
	/** Initialize this XMLBuilder to wrap the given builder */
	public TracedXMLStream(XMLStream builder) {
		this.builder = builder;
	}

	/**
	 * Outputs a trace tag if the trace has changed since the last
	 * time doTrace was alled.
	 */
	private final void doTrace(String tag) {
		if (tagStack.size() == 0) {
			// cannot trace when no tag is open
			return;
		}
		
		StackTraceElement top = ReflectionUtils.getTraceTop();
		if (!top.equals(lastTrace.put(tag, top))) {
			builder.line("trace", top, "tag", tag);
		}
	}
	
	/**
	 * Begins the given tag with the given arguments, depending on
	 * what our list of {@link TagAction}s has to say.  If a condition
	 * specified SUPPRESS, this tag is added to the suppress list, and
	 * all its children will also be suppressed (unless they are preceded
	 * by a matching condition with a different policy).  If NORMAL,
	 * this tag is passed through as normal.  If TRACE, a trace tag
	 * is added before the tag is opened.  If all {@link TagAction}s
	 * specify DEFAULT for this tag, either passes through or suppresses
	 * depending on whether a SUPPRESS is open.
	 */
	public XMLStream begin(String tag, Object... args) {
		if (closed) {
			return this;
		}
		
		for (TagAction condition : conditions) {
			switch (condition.consider(tag, tagStackView, stateStackView)) {
			case SUPPRESS:
				tagStack.add(tag);
				stateStack.add(ActionType.SUPPRESS);
				suppress++;
				return this;
				
			case NORMAL:
				tagStack.add(tag);
				stateStack.add(ActionType.NORMAL);
				builder.begin(tag, args);
				return this;
			
			case TRACE:
				tagStack.add(tag);
				stateStack.add(ActionType.TRACE);
				doTrace(tag);
				builder.begin(tag, args);
				return this;
			
			case DEFAULT:
				break;
			}
		}
		
		tagStack.add(tag);
		stateStack.add(ActionType.DEFAULT);
		if (suppress == 0) {
			builder.begin(tag, args);
		}
		return this;
	}

	/**
	 * Ends the given tag, possibly suppressing it.
	 */
	public XMLStream end(String tag) {
		if (closed) {
			return this;
		}
		
		if (!tag.equals(tagStack.getLast())) {
			throw new IllegalArgumentException("Unexpected close of tag " + tag
					+ ".. expected "+tagStack.getLast());
		}
		
		tagStack.removeLast();
		
		switch (stateStack.removeLast()) {
		case SUPPRESS:
			suppress--;
			return this;
			
		case NORMAL:
			builder.end(tag);
			return this;
			
		case TRACE:
			builder.end(tag);
			return this;
			
		case DEFAULT:
			if (suppress == 0) {
				builder.end(tag);
			}
			return this;
		}
		
		return this;
	}

	/**
	 * Ends the given line, possible suppressing it.
	 */
	public XMLStream line(String tag, Object body, Object... args) {
		if (closed) {
			return this;
		}

		for (TagAction condition : conditions) {
			switch (condition.consider(tag, tagStackView, stateStackView)) {
			case SUPPRESS:
				return this;
				
			case NORMAL:
				builder.line(tag, body, args);
				return this;
			
			case TRACE:
				doTrace(tag);
				builder.line(tag, body, args);
				return this;
			
			case DEFAULT:
				continue;
			}
		}
		
		if (suppress == 0) {
			builder.line(tag, body, args);
		}
		return this;
	}

	/**
	 * Inserts the given xml unless we are in a suppress tag.  Does 
	 * not examine contents of the xml to allow tracing and policy
	 * changes on embedded tags.
	 */
	public XMLStream xml(EscapedXML xml) {
		if (closed) {
			return this;
		}
		
		if (suppress == 0) {
			builder.xml(xml);
		}
		return this;
	}
	
	public void close() {
		if (closed) {
			return;
		}
		
		while (tagStack.size() > 0) {
			end(tagStack.getLast());
		}
		closed = true;
		builder.close();
	}
	
	/**
	 * Returns stack of tags.
	 */
	public List<String> getTagStack() {
		return tagStackView;
	}
	
	/**
	 * Returns the stack of actions taken on the tags in getTagStack.
	 */
	public List<ActionType> getActionStack() {
		return stateStackView;
	}
	
	/**
	 * Adds the given condition as the first element in the trace.
	 */
	public void addTagAction(TagAction condition) {
		this.conditions.add(condition);
	}
	
	//
	// Actions
	// 
	
	/**
	 * Actions that can be taken when encountering a tag. A {@link TagAction}
	 * returns an element from this enum to inform {@link TracedXMLStream} of
	 * which action to perform.
	 */
	public enum ActionType {
		/**
		 * Do not change action as a result of the TagAction that returns this
		 * value.
		 */
		DEFAULT,

		/**
		 * Suppresses the tag and its decendants in the wrapped XMLBuilder.
		 */
		SUPPRESS,

		/**
		 * Pass the tag through to the wrapped XMLBuilder even if one of its
		 * parents has been suppressed.
		 */
		NORMAL,
		
		/**
		 * Pass the tag through to the wrapped XMLBuilder and outputs a
		 * <code>&lt;trace&gt;</code> tag marking the line number in the in
		 * the calling coding.
		 */
		TRACE;
	}
	
	/**
	 * Interface used by {@link TracedXMLStream} for determining what action
	 * to take on encountering a given tag in a given context.
	 */
	public interface TagAction {
		public ActionType consider(String tag, List<String> tagStack, List<ActionType> actionStack); 
	}
	
	/**
	 * Always uses the given policy with the given tag.
	 */
	public static class FixedTagAction implements TagAction {
		private final ActionType action;
		private final String tag;
		
		public FixedTagAction(String tag, ActionType action) {
			this.tag = tag;
			this.action = action;
		}
		
		public ActionType consider(String tag, List<String> tagStack, List<ActionType> actionStack) {
			return this.tag.equals(tag) ? action : ActionType.DEFAULT;
		}
	}
}
