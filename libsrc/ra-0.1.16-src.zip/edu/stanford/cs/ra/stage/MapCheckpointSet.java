/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.HashMap;
import java.util.Map;

/**
 * {@link CheckpointSet} implementation backed by in-memory map.
 * 
 * @author dramage
 */
public class MapCheckpointSet implements CheckpointSet {

	private final Map<StageLineage,Map<String,Object>> checkpoints
		= new HashMap<StageLineage,Map<String,Object>>();
	
	public void createCheckpoint(StageLineage lineage,
			Map<String, Object> context) {
		
		checkpoints.put(lineage, context);
	}

	public boolean hasCheckpoint(StageLineage lineage) {
		return checkpoints.containsKey(lineage);
	}

	public Map<String, Object> loadCheckpoint(StageLineage lineage) {
		return checkpoints.get(lineage);
	}

}
