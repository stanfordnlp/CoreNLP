/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.util;

import java.io.File;
import java.io.FileFilter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import edu.stanford.cs.ra.stringify.Stringify;

/**
 * Path manipulation utilities.
 * 
 * @author dramage
 */
public class PathUtils {
	
	/**
	 * Returns the part of path that follows the given prefix.
	 */
	public static String relativePath(File path, File prefix) {
		String pathString = path.getAbsolutePath(); 
		String prefixString = prefix.getAbsolutePath();
		
		if (!pathString.startsWith(prefixString)) {
			return pathString;
		} else {
			String rel = pathString.substring(prefixString.length());
			if (rel.startsWith(File.separator)) {
				rel = rel.substring(File.separator.length());
			}
			return rel.length() == 0 ? "." : rel;
		}
	}

	/**
	 * Returns a list of File instances that match the given shell-like
	 * patten.
	 * 
	 * @param base Base of the search
	 * @param pattern Unix shell-like pattern including
	 *   <code>* ? . .. []</code>.
	 *   
	 * @return A list of files relative to the given base directory matching
	 *   the given filename pattern.  This should always be analogous to
	 *   the output of the unix command "ls".  e.g. "ls *.txt".
	 */
	public static File[] glob(File base, String pattern) {
		if (pattern.length() > 0) {
			return findFiles(base, pattern).toArray(new File[0]);
		} else {
			return new File[0];
		}
	}

	/**
	 * Inner helper for glob.
	 */
	private static List<File> findFiles(File current, String pattern) {
		if (pattern.startsWith(File.separator)) {
			// could have specified a whole path pattern
			pattern = pattern.substring(File.separator.length());
			List<String> segments = Stringify.escapedSplit(String.class, pattern, File.separatorChar);
			for (int i = segments.size(); i > 0; i--) {
				File candidate = new File(File.separator+Stringify.escapedJoin(segments.subList(0, i), File.separatorChar));
				if (candidate.isDirectory()) {
					return findFiles(candidate, Stringify.escapedJoin(segments.subList(i, segments.size()), File.separatorChar));
				}
			}
			return findFiles(new File(File.separator), pattern);
		}
		
		if (current == null || !current.isDirectory()) {
			return Collections.emptyList();
		}
		
		// empty segment list, add directory
		if (pattern.length() == 0) {
			return Collections.singletonList(current);
		}

		LinkedList<File> found = new LinkedList<File>();

		int index = pattern.indexOf(File.separator);
		
		if (index != -1 && index != pattern.length()-File.separator.length()) {
			String segment = pattern.substring(0,index);
			String remainder = pattern.substring(index+File.separator.length());

			if (segment.equals(".")) {
				// special folder for current
				found.addAll(findFiles(current, remainder));
			} else if (segment.equals("..")) {
				// special folder for current's parent
				found.addAll(findFiles(current.getParentFile(), remainder));
			} else if (segment.equals("**")) {
				// special symbol for recursive search
				
				// look in current folder without **
				found.addAll(findFiles(current, remainder));
				
				// look in every subfolder with **
				File[] files = current.listFiles();
				if (files != null) {
					for (File subdir : files) {
						if (subdir.isDirectory()) {
							found.addAll(findFiles(subdir, pattern));
						}
					}
				}
			} else {
				// standard pattern element
				FileFilter filter = new GlobFilenameFilter(segment);
				// more segments remain, recursively explore subdirs
				for (File file : current.listFiles(filter)) {
					found.addAll(findFiles(file, remainder));
				}
			}
			
		} else {
			if (pattern.endsWith(File.separator)) {
				pattern = pattern.substring(0, pattern.length()-File.separator.length());
			}
			
			FileFilter filter = new GlobFilenameFilter(pattern);
			// no more segments, add all matching files
			File[] files = current.listFiles(filter);
			if (files != null) {
				for (File file : files) {
					found.add(file);
				}
			}
		}

		return found;
	}
	
	// adapted from jakarata-oro, apl 2.0
	private static class GlobFilenameFilter implements FileFilter {
		private final Pattern regex;

		public GlobFilenameFilter(String input) {
			char[] pattern = input.toCharArray();
			boolean inCharSet = false;
			
			StringBuilder builder = new StringBuilder();
			
			for(int ch=0; ch < pattern.length; ch++) {
				switch(pattern[ch]) {
				case '*':
					if(inCharSet)
						builder.append('*');
					else
						builder.append(".*");
					break;
				case '?':
					if(inCharSet)
						builder.append('?');
					else
						builder.append('.');
					break;
				case '[':
					inCharSet = true;
					builder.append(pattern[ch]);

					if(ch + 1 < pattern.length) {
						switch(pattern[ch + 1]) {
						case '!':
						case '^':
							builder.append('^');
							++ch;
							continue;
						case ']':
							builder.append(']');
							++ch;
							continue;
						}
					}
					break;
				case ']':
					inCharSet = false;
					builder.append(pattern[ch]);
					break;
				case '\\':
					builder.append('\\');
					if(ch == pattern.length - 1)
						builder.append('\\');
					else if(isGlobMetaCharacter(pattern[ch + 1]))
						builder.append(pattern[++ch]);
					else
						builder.append('\\');
					break;
				default:
					if(!inCharSet && isPerl5MetaCharacter(pattern[ch]))
						builder.append('\\');
					builder.append(pattern[ch]);
					break;
				}
			}

			regex = Pattern.compile(builder.toString());
		}
		
		public boolean accept(File pathname) {
			return regex.matcher(pathname.getName()).matches();
		}
		
		private static boolean isGlobMetaCharacter(char ch) {
			return "*?[]".indexOf(ch) >= 0;
		}
		
		private static boolean isPerl5MetaCharacter(char ch) {
			return ("'*?+[]()|^$.{}\\".indexOf(ch) >= 0);
		}
	}
}
