/*
 * Copyright © 2002, 2005 Elliotte Rusty Harold
 *   
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of version 2.1 of 
 * the GNU Lesser General Public License as published by the 
 * Free Software Foundation.
 *   
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *   
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *   
 * You can contact Elliotte Rusty Harold by sending e-mail to
 * elharo@ibiblio.org. Please include the word "XOM" in the
 * subject line. The XOM home page is http://www.xom.nu/
 */

/**
 * <p>
 * <code>nu.xom.canonical</code>  
 * supports the output of 
 * <a target="_top"
 * href="https://www.w3.org/TR/2001/REC-xml-c14n-20010315">Canonical XML</a>
 * from XOM.
 * For basic canonicalization of existing documents, this (or any other tree-based
 * solution) is likely not as efficient as a streaming, SAX-based solution.
 * However, this is useful for output from XOM in canonical form.
 * </p>
 * 
 * @since 1.0
 */
package nu.xom.canonical;