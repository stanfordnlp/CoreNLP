/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;


import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import edu.stanford.cs.ra.stringify.Stringify;

/**
 * A stateful output stack for writing XML fragments to an OutputStream.
 * Writes are done immediately at each call to {@link #begin(String, Object...)},
 * {@link #line(String, Object, Object...)}, and {@link #end(String)}.
 * 
 * @author dramage
 */
public class XMLOutputStream implements XMLStream {
	private final static String PREFIX_STRING = "  ";

	/** Stack of open tags */
	private final LinkedList<String> stackTags;
	private final LinkedList<String[]> stackArgs;

	/** Sink to write completed tags to */
	private OutputStream sink;
	
	/** PrintStream wrapper to sink */
	private PrintStream printSink;

	/** Currently waiting on an open tag line in case it gets closed .. */
	private boolean isTagOpen = false;

	/** Whether we allow operations to write */
	private boolean isStreamOpen = true;
	
	/** Whether the header has been printed. */
	private boolean isXMLHeaderPrinted = false;
	
	/** Prefix of whitespace before the line */
	private String prefix = "";
	
	/**
	 * New instance of XMLOutputStream that sends XML fragments to the given sink.
	 */
	public XMLOutputStream(OutputStream sink) {
		this.stackTags = new LinkedList<String>();
		this.stackArgs = new LinkedList<String[]>();
		setOutputStream(sink);
	}
	
	private final void printXMLHeader() {
//		if (!isXMLHeaderPrinted && isStreamOpen && !isTagOpen) {
//			printSink.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
//			isXMLHeaderPrinted = true;
//		}
	}
	
	/**
	 * Closes any remaining open tags.  Subsequence calls to XMLBuilder
	 * implemented methods will do nothing.  Does not close the underlying
	 * stream.  See {@link XMLStream#close()}.
	 */
	public void close() {
		if (!isStreamOpen) {
			return;
		}
		
		while (stackTags.size() > 0) {
			end(stackTags.getLast());
		}
		this.isStreamOpen = false;
		printSink.flush();
	}
	
	/**
	 * See {@link XMLStream#line(String, Object, Object...)}.
	 */
	public XMLStream line(String tag, Object body, Object ... args) {
		if (!isStreamOpen) {
			return this;
		}
		printXMLHeader();
		if (args.length % 2 != 0) {
			throw new XMLException("Expected even number of key,value arguments");
		}
		if (isTagOpen) {
			printSink.println(">");
			isTagOpen = false;
		}
		printSink.print(prefix);
		printSink.print("<");
		printSink.print(tag);
		for (int i = 0; i < args.length; i += 2) {
			if (args[i+1] != null) {
				printSink.print(" ");
				printSink.print(args[i]);
				printSink.print("=\"");
				printSink.print(XMLUtils.escapeForAttribute(Stringify.toString(args[i+1])));
				printSink.print("\"");
			}
		}

		String bodyString = Stringify.toString(body);
		if (bodyString.length() > 0) {
			printSink.print(">");
			if (!(body instanceof EscapedXML)) {
				bodyString = XMLUtils.escapeForTextNode(bodyString);
			}
			printSink.print(reformat(bodyString, prefix+PREFIX_STRING));
			printSink.print("</");
			printSink.print(tag);
			printSink.println(">");
		} else {
			printSink.println(" />");
		}
		printSink.flush();
		return this;
	}

	/**
	 * See {@link XMLStream#begin(String, Object...)}.
	 */
	public XMLStream begin(String tag, Object ... args) {
		if (!isStreamOpen) {
			return this;
		}
		printXMLHeader();
		if (args.length % 2 != 0) {
			throw new XMLException("Expected even number of key,value arguments");
		}
		if (isTagOpen) {
			printSink.println(">");
			isTagOpen = false;
		}
		printSink.print(prefix);
		StringBuilder line = new StringBuilder();

		String[] strings = Stringify.toStrings(args);
		stackTags.add(tag);
		stackArgs.add(strings);
		
		line.append("<");
		line.append(tag);
		for (int i = 0; i < args.length; i += 2) {
			if (args[i+1] != null) {
				line.append(" ");
				line.append(args[i]);
				line.append("=\"");
				line.append(XMLUtils.escapeForAttribute(strings[i+1]));
				line.append("\"");
			}
		}
		printSink.print(line);
		isTagOpen = true;
		printSink.flush();
		
		// update indentation level
		prefix = prefix + PREFIX_STRING;
		return this;
	}

	/**
	 * See {@link XMLStream#end(String)}.
	 */
	public XMLStream end(String tag) {
		if (!isStreamOpen) {
			return this;
		}
		printXMLHeader();
		// assert valid end record 
		if (!stackTags.getLast().equals(tag)) {
			throw new XMLException("Unexpected close of tag " + tag
					+ ".. expected "+stackTags.getLast());
		}
		stackTags.removeLast();
		stackArgs.removeLast();
		
		// decrease indentation level
		prefix = prefix.substring(PREFIX_STRING.length());
		
		if (isTagOpen) {
			printSink.println(" />");
			isTagOpen = false;
		} else {
			printSink.print(prefix);
			StringBuilder line = new StringBuilder();
			line.append("</");
			line.append(tag);
			line.append(">");
			printSink.println(line);
		}
		printSink.flush();
		return this;
	}
	
	/**
	 * See {@link XMLStream#xml(EscapedXML)}.
	 */
	public XMLStream xml(EscapedXML xml) {
		if (!isStreamOpen) {
			return this;
		}
		
		if (isTagOpen) {
			printSink.println(">");
			isTagOpen = false;
		}
		
		printSink.print(prefix);
		printSink.println(reformat(xml.xml, prefix).trim());
		printSink.flush();
		return this;
	}
	
	/**
	 * Returns an unmodifiable view of the tag stack.
	 */
	public List<String> getTagStack() {
		return Collections.unmodifiableList(stackTags);
	}
	
	/**
	 * Gets the underlying PrintStream
	 */
	public OutputStream getOutputStream() {
		return sink;
	}

	/**
	 * Sets the underlying PrintStream.
	 */
	public void setOutputStream(OutputStream stream) {
		this.sink = stream;
		if (sink instanceof PrintStream) {
			this.printSink = (PrintStream)sink;
		} else {
			this.printSink = new PrintStream(sink);
		}
	}
	
	/**
	 * Closes all open XML frames on the stack.
	 * 
	 * Called by the main loop exception handler.
	 */
	@Override
	public void finalize() throws Throwable {
		super.finalize();
		close();
	}

	/**
	 * If it is multi-line, prefix each line with the given prefix.  Otherwise
	 * does nothing.
	 */
	private static String reformat(String s, String prefix) {
		if (!s.contains("\n")) {
			return s;
		}

		StringBuilder builder = new StringBuilder();
		for (String part : s.split("\n")) {
			builder.append("\n").append(prefix).append(part);
		}
		builder.append("\n").append(prefix.substring(PREFIX_STRING.length()));
		
		return builder.toString();
	}
}
