/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * A stage of computation as managed by {@link StageWise}. A class is a valid
 * Stage if it marks fields with {@link edu.stanford.cs.ra.arguments.Argument}
 * annotations or with {@link Stage.ImportField} or with
 * {@link Stage.ExportField}. A class may optionally define at most one run
 * method by marking it with {@link Stage.Run}. Prerequisite stages can be
 * marked with the {@link Stage.Requires} annotation. Stage outputs can be
 * marked for automatic serialization with the {@link Stage.Serialize}
 * annotation. A stage (with its dependencies) can be run with the
 * {@link StageWise} class.
 * 
 * @author dramage
 */
public final class Stage {
	//
	// Cannot be instantiated
	//
	private Stage() { }
	
	
	//
	// Annotations describing a stage class
	//
	
	/**
	 * Marks that {@link StageWise} should serialize all context fields marked
	 * with CreatesField and ReadsAndModifiesField after the stage completes.
	 */
	@Documented
	@Target({ElementType.TYPE})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Serialize { }
	
	/**
	 * Marker specifying what stages the current stage depends on. If applied to
	 * a class, accepts a list of prerequisite types to run first. If applied to
	 * a Field, adds the Class referenced by the field as an additional stage
	 * pre-requisite just before running. The field must be of type
	 * <code>Class&lt;? extends Stage&gt;</code> or a compatible subtype. Any
	 * arguments provided when used as a Field annotation are ignored.
	 */
	@Documented
	@Target({ElementType.TYPE, ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Requires {
		Class<?>[] value();
		String[] arguments() default {};
	}

	
	//
	// Annotations describing a stage field or parameter
	//
	
	/**
	 * Marks a field as a {@link StageWise} context element that will be
	 * written by this stage and exported to the {@link StageWise} context
	 * (and potentially serialized if the stage is marked for serialization).
	 */
	@Documented
	@Target({ElementType.FIELD, ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface ExportField {
		String value() default "";
	}
	
	/**
	 * Marks a field or parameter as a {@link StageWise} context element that
	 * will be read by this Stage. {@link StageWise} will place a value in this
	 * field (or run method parameter) before calling the run method, or throw
	 * an exception if no previous Stage creates a compatible named field. The
	 * contents of this field will <em>not</em> be serialized after the stage
	 * ends unless the field is also marked with {@link ExportField}.
	 */
	@Documented
	@Target({ElementType.FIELD, ElementType.PARAMETER})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface ImportField {
		String value() default "";
	}
	
//	/**
//	 * Marks an OutputStream field or parameter as a StageWise-managed
//	 * OutputStream. Before a call to a run method, this field or parameter will
//	 * be set to a new unique OutputStream that will write to a file in this
//	 * run's workbook directory according to the given name. StageWise will
//	 * throw an exception if no workbook path had been specified on the command
//	 * line if a stage tries to use ExportStream or ImportStream.
//	 */
//	@Documented
//	@Target({ElementType.FIELD, ElementType.PARAMETER})
//	@Retention(RetentionPolicy.RUNTIME)
//	public @interface ExportStream {
//		String value() default "";
//	}
//	
//	/**
//	 * Marks an InputStream field or paramater as a StageWise-managed
//	 * InputStream. Before a call to a run method, this field or parameter will
//	 * be set to read from a compatible previous stage's corresponding
//	 * ExportStream. StageWise will throw an exception if no workbook path had
//	 * been specified on the command line if a stage tries to use ExportStream
//	 * or ImportStream.
//	 */
//	@Documented
//	@Target({ElementType.FIELD, ElementType.PARAMETER})
//	@Retention(RetentionPolicy.RUNTIME)
//	public @interface ImportStream {
//		String value() default "";
//	}
	
	//
	// Annotations describing a stage instance method or static method
	//

	/**
	 * Called by StageWise after instantiating the stage, running all its
	 * pre-requisites, and providing values for all fields marked as Argument
	 * or as Context.  StageWise will call this method only once on any
	 * given instance.
	 */
	@Documented
	@Target({ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Run { }
	
	/**
	 * All methods marked with this annotation are called by StageWise
	 * exactly one time per instance before running.  The decorated method
	 * may be either static methord, instance method, or a constructor method.
	 * All fields marked with @Argument or @ImportField or @ExportField have
	 * their values injected automatically by RA.
	 */
	@Documented
	@Target({ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Init { }
}
