/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stringify;

import java.io.File;
import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import edu.stanford.cs.ra.stringify.Stringify.StaticFromString;
import edu.stanford.cs.ra.stringify.Stringify.StaticToString;
import edu.stanford.cs.ra.stringify.Stringify.StringifyException;
import edu.stanford.cs.ra.util.PathUtils;
import edu.stanford.cs.ra.util.ReflectionUtils;

/**
 * Builtin string converters for all primitive types, many basic java
 * standard library objects, and arrays thereof.
 */
class StringifyBuiltins {


	//
	// Common Java classes
	//

	@StaticToString
	public static String fromClass(Class<?> type) {
		if (type.isArray()) {
			return fromClass(type.getComponentType())+"[]";
		} else {
			return type.getName();
		}
	}

	/** All primitive types */
	private final static Class<?>[] primitives = new Class<?>[] {
		Integer.TYPE, Long.TYPE, Float.TYPE, Double.TYPE,
		Character.TYPE, Byte.TYPE, Short.TYPE, Boolean.TYPE };

	@StaticFromString
	public static Class<?> toClass(String in) {
		// array types are special
		if (in.endsWith("[]")) {
			return Array.newInstance(toClass(in.substring(0,in.length()-2)),0).getClass();
		}

		// primitive types are special
		for (Class<?> primitive : primitives) {
			if (primitive.getName().equals(in)) {
				return primitive;
			}
		}

		// everything else
		try {
			return ReflectionUtils.getClassByName(in);
		} catch (ClassNotFoundException e) {
			throw new StringifyException(e);
		}
	}

	/** Special treatment of file arrays via path separator and globbing. */
	@StaticFromString
	public static File[] forFileArray(String in) {
		File base = new File(".");

		LinkedList<File> files = new LinkedList<File>();
		for (String segment : in.split(File.pathSeparator)) {
			if (segment.length() > 0) {
				for (File file : PathUtils.glob(base, segment)) {
					files.add(file);
				}
			}
		}
		Collections.sort(files);
		return files.toArray(new File[0]);
	}

	/** Special treatment of file arrays via path separator and globbing. */
	@StaticToString
	public static String fromFileArray(File[] files) {
		StringBuilder builder = new StringBuilder(":");
		for (File file : files) {
			builder.append(Stringify.toString(file).replaceAll(
					File.pathSeparator, "\\"+File.pathSeparator));
			builder.append(":");
		}
		return builder.toString().substring(0, builder.length()-1);
	}

	//
	// Primitives for the join-split structure backend
	//

	public static <T> Object arrayFromString(Class<T> type, String in) {
		List<T> values = Stringify.escapedSplit(type, in, ',');
		Object array = Array.newInstance(type, values.size());
		int i = 0;
		for (T value : values) {
			Array.set(array, i++, value);
		}
		return array;
	}

	public static String arrayToString(Object array) {
		final int length = Array.getLength(array);
		List<Object> list = new ArrayList<Object>(length);
		for (int i = 0; i < length; i++) {
			list.add(Array.get(array,i));
		}
		return Stringify.escapedJoin(list, ',');
	}


	//
	// Primitives for the JSON backend
	//

	static class JSONBackend {

		/** Primitive json types that might not need quoting in arrays */
		private static final Set<Class<?>>
		jsonPrimitives = new HashSet<Class<?>>();

		static {
			jsonPrimitives.add(Integer.class);
			jsonPrimitives.add(Integer.TYPE);
			jsonPrimitives.add(Long.class);
			jsonPrimitives.add(Long.TYPE);
			jsonPrimitives.add(Float.class);
			jsonPrimitives.add(Float.TYPE);
			jsonPrimitives.add(Double.class);
			jsonPrimitives.add(Double.TYPE);
			jsonPrimitives.add(Byte.TYPE);
			jsonPrimitives.add(Byte.class);
			jsonPrimitives.add(Short.TYPE);
			jsonPrimitives.add(Short.class);
			jsonPrimitives.add(Boolean.TYPE);
			jsonPrimitives.add(Boolean.class);
		}

		/** Converts the given object to a valid JSON member String */
		private static String toMemberString(Object object) {
			if (object == null) {
				return "null";
			} 

			Class<?> type = object.getClass();

			// if it is a primitive that is valid unescaped JSON
			if (jsonPrimitives.contains(type)) {
				String candidate = Stringify.toString(object);
				if (candidate.matches("-?\\d*(\\.\\d+)?((e|E)(\\+|-)?\\d+)?")) {
					return candidate;
				} else if (candidate.equals("true") || candidate.equals("false") || candidate.equals("null")) {
					return candidate;
				}
			}

			if (type.isArray()) {
				return arrayToString(object);
			} else {
				return JSONObject.quote(Stringify.toString(object));
			}
		}

		/** Converts the given String into an array */
		public static String arrayToString(Object array) {
			final int length = Array.getLength(array);
			StringBuilder builder = new StringBuilder("[");
			for (int i = 0; i < length; i++) {
				builder.append(toMemberString(Array.get(array,i)));
				if (i+1 < length) {
					builder.append(", ");
				}
			}
			builder.append("]");
			return builder.toString();
		}

		/**
		 * Mini-JSON parser for array types only.
		 */
		public static Object arrayFromString(Class<?> type, String in) {
			try {
				return arrayFromJSONArray(type, new JSONArray(in));
			} catch (JSONException e) {
				// try again with surrounding "[]"
			}
			try {
				return arrayFromJSONArray(type, new JSONArray("["+in+"]"));
			} catch (JSONException e) {
				throw new StringifyException("Invalid array format",e);
			}
		}

		/**
		 * Converts the given JSONArray into a Java array.
		 */
		public static Object arrayFromJSONArray(Class<?> type, JSONArray json) {
			try {
				final int length = json.length();
				final Object array = Array.newInstance(type, length);

				if (type.isArray()) {
					for (int i = 0; i < length; i++) {
						JSONArray sub = json.getJSONArray(i);
						Array.set(array, i, arrayFromJSONArray(type.getComponentType(), sub));
					}
				} else {
					for (int i = 0; i < length; i++) {
						Array.set(array, i, Stringify.fromString(type, json.getString(i)));
					}
				}

				return array;
			} catch (JSONException e) {
				throw new StringifyException("Invalid array format",e);
			}
		}
	}


	//
	// Primitives for the custom chunker backend
	//

	static class ChunkBackend {

		public static Object arrayFromString(Class<?> type, String in) {
			ArrayChunk chunk = parseArray(in);

			final int length = chunk.value.size();
			Object array = Array.newInstance(type, length);

			for (int i = 0; i < length; i++) {
				System.err.println("!"+i+" "+chunk.value.get(i)+" "+type);

				Array.set(array, i, Stringify.fromString(type,
						chunk.value.get(i).trim().substring()));
			}

			return array;
		}

		public static abstract class Chunk<T> {
			public final String context;
			public final int start;
			public final int end;
			public final T value;
			public Chunk(String context, int start, int end, T value) {
				this.context = context;
				this.start = start;
				this.end = end;
				this.value = value;

				assert(start >= 0);
				assert(end >= start);
				assert(end <= context.length());
			}

			public String substring() {
				return context.substring(start, end);
			}

			@Override
			public String toString() {
				return this.getClass().getSimpleName()+"@["+start+"-"+end+"]: "+value.toString();
			}

			public abstract Chunk<?> trim();
		}

		public static class LiteralChunk extends Chunk<String> {
			public LiteralChunk(String context, int start, int end, String value) {
				super(context, start, end, value);
			}

			/** Returns a trimmed version of this literal chunk */
			public Chunk<?> trim() {
				int newStart = start;
				while (newStart < end && Character.isWhitespace(context.charAt(newStart))) {
					newStart++;
				}

				int newEnd = end;
				while (newEnd > newStart && Character.isWhitespace(context.charAt(newEnd-1))) {
					newEnd--;
				}

				return new LiteralChunk(context, newStart, newEnd, value.substring(newStart-start, value.length()-(end-newEnd)));
			}
		}

		public static class ArrayChunk extends Chunk<List<Chunk<?>>> {
			public ArrayChunk(String context, int start, int end, List<Chunk<?>> value) {
				super(context, start, end, value);
			}

			public Chunk<?> trim() {
				// self trimming
				return this;
			}
		}

		private static ArrayChunk parseArray(String str) {
			str = str.trim();
			try {
				ArrayChunk chunk = parseArrayChunk(str, 0, true);
				if (chunk.end == str.length()) {
					return chunk;
				}
			} catch (StringifyException e) {
				// didn't have the brackets;
			}

			return parseArrayChunk(str, 0, false);
		}

		public static ArrayChunk parseArrayChunk(String str, int start, boolean outerBrackets) {
			// maximum string length
			final int length = str.length();

			boolean inArray = !outerBrackets;
			List<Chunk<?>> chunks = new ArrayList<Chunk<?>>();

			for (int i = start; i < length; i++) {
				final char ch = str.charAt(i);
				if (Character.isWhitespace(ch)) {
					continue;
				} else if (inArray) {
					switch (ch) {
					case ']':
						// done with array
						return new ArrayChunk(str, start, i+(outerBrackets?1:0), chunks);
					case '[':
						ArrayChunk arrChunk = parseArrayChunk(str, i, true);
						chunks.add(arrChunk);
						i = arrChunk.end - 1;
						break;
					case ',':
						// ignore commas, means end of chunk we already read
						break;
					case '{':
					case '}':
						throw new StringifyException("Unhandled block type '{'");
					default:
						Chunk<?> chunk = parseChunk(str, i).trim();
					chunks.add(chunk);
					i = chunk.end;
					}
				} else {
					// not in array, better be starting one
					if (ch != '[') {
						throw new StringifyException("Expected array at "+i);
					}
					inArray = true;
				}
			}

			return new ArrayChunk(str, start, length, chunks);
		}

		public static Chunk<?> parseChunk(String str, int start) {
			final int length = str.length();

			int i = start;
			while (i < length && Character.isWhitespace(str.charAt(i))) {
				i++;
			}

			if (i == length) {
				return null;
			}

			switch(str.charAt(i)) {
			case '[':
				return parseArrayChunk(str, i, true);
			case '"':
				LiteralChunk litChunk = parseLiteralChunk(str, i+1, "\"\n\r\b");
				if (litChunk.end == str.length() || litChunk.context.charAt(litChunk.end) != '\"') {
					throw new StringifyException("Runaway quote starting at "+litChunk.start);
				}
				return litChunk;
			case ']':
			case '{':
			case '}':
				throw new StringifyException("Unexpected structure character: "+str.charAt(i));
			default:
				return parseLiteralChunk(str, i, ",:[]{}\n\r\b");
			}
		}

		public static LiteralChunk parseLiteralChunk(String str, int start, String stopchars) {
			// maximum string length
			final int length = str.length();

			StringBuilder builder = new StringBuilder(2 * length);
			StringBuilder unicode = new StringBuilder(4);

			boolean inSlash = false;
			boolean inUnicode = false;

			for (int i = start; i < length; i++) {
				final char ch = str.charAt(i);
				if (inUnicode) {
					// reading unicode characters
					unicode.append(ch);
					if (unicode.length() == 4) {
						// unicode now contains the four hex digits
						// which represents our unicode character
						try {
							int value = Integer.parseInt(unicode.toString(), 16);
							builder.append((char) value);
							unicode.setLength(0);
							inUnicode = false;
							inSlash = false;
						} catch (NumberFormatException nfe) {
							throw new StringifyException("Unable to parse unicode value: " + unicode, nfe);
						}
					}
				} else if (inSlash) {
					// currently escaping
					inSlash = false;
					switch (ch) {
					case 'r':
						builder.append('\r');
						break;
					case 'f':
						builder.append('\f');
						break;
					case 't':
						builder.append('\t');
						break;
					case 'n':
						builder.append('\n');
						break;
					case 'b':
						builder.append('\b');
						break;
					case 'u':
						inUnicode = true;
						break;
					default :
						builder.append(ch);
					}
				} else if (ch == '\\') {
					inSlash = true;
				} else if (stopchars.indexOf(ch) >= 0) {
					return new LiteralChunk(str, start, i, builder.toString());
				} else {
					builder.append(ch);
				}
			}

			if (inSlash) {
				// still in a slash, pretend it's ok
				builder.append('\\');
			}

			return new LiteralChunk(str, start, length, builder.toString());
		}
		
		public static void test() {
			System.out.println(parseArrayChunk("[a,b,c]",0,true));
			System.out.println(parseArrayChunk("a,  b, c ",0,false));
			System.out.println(parseArrayChunk("[ [1, 2] , \"[3]\"]",0,true));
			System.out.println(parseLiteralChunk("\"abc\"",0,""));
			System.out.println(parseLiteralChunk("abc",0,""));
			System.out.println(parseLiteralChunk("\"\\\"ab\"",0,""));
		}

	}




	//
	// Custom numeric formatters from JavaNLP
	//

	@StaticToString
	public static String toString(double[] a) {
		return toString(a, null);
	}

	public static String toString(double[] a, NumberFormat nf) {
		if (a == null) return null;
		if (a.length == 0) return "[]";
		StringBuffer b = new StringBuffer();
		b.append("[");
		for (int i = 0; i < a.length - 1; i++) {
			String s;
			if (nf == null) {
				s = String.valueOf(a[i]);
			} else {
				s = nf.format(a[i]);
			}
			b.append(s);
			b.append(", ");
		}
		String s;
		if (nf == null) {
			s = String.valueOf(a[a.length - 1]);
		} else {
			s = nf.format(a[a.length - 1]);
		}
		b.append(s);
		b.append(']');
		return b.toString();
	}

	@StaticToString
	public static String toString(float[] a) {
		return toString(a, null);
	}

	public static String toString(float[] a, NumberFormat nf) {
		if (a == null) return null;
		if (a.length == 0) return "[]";
		StringBuffer b = new StringBuffer();
		b.append("[");
		for (int i = 0; i < a.length - 1; i++) {
			String s;
			if (nf == null) {
				s = String.valueOf(a[i]);
			} else {
				s = nf.format(a[i]);
			}
			b.append(s);
			b.append(", ");
		}
		String s;
		if (nf == null) {
			s = String.valueOf(a[a.length - 1]);
		} else {
			s = nf.format(a[a.length - 1]);
		}
		b.append(s);
		b.append(']');
		return b.toString();
	}

	@StaticToString
	public static String toString(int[] a) {
		return toString(a, null);
	}

	public static String toString(int[] a, NumberFormat nf) {
		if (a == null) return null;
		if (a.length == 0) return "[]";
		StringBuffer b = new StringBuffer();
		b.append("[");
		for (int i = 0; i < a.length - 1; i++) {
			String s;
			if (nf == null) {
				s = String.valueOf(a[i]);
			} else {
				s = nf.format(a[i]);
			}
			b.append(s);
			b.append(", ");
		}
		String s;
		if (nf == null) {
			s = String.valueOf(a[a.length - 1]);
		} else {
			s = nf.format(a[a.length - 1]);
		}
		b.append(s);
		b.append(']');
		return b.toString();
	}

	@StaticToString
	public static String toString(byte[] a) {
		return toString(a, null);
	}

	public static String toString(byte[] a, NumberFormat nf) {
		if (a == null) return null;
		if (a.length == 0) return "[]";
		StringBuffer b = new StringBuffer();
		b.append("[");
		for (int i = 0; i < a.length - 1; i++) {
			String s;
			if (nf == null) {
				s = String.valueOf(a[i]);
			} else {
				s = nf.format(a[i]);
			}
			b.append(s);
			b.append(", ");
		}
		String s;
		if (nf == null) {
			s = String.valueOf(a[a.length - 1]);
		} else {
			s = nf.format(a[a.length - 1]);
		}
		b.append(s);
		b.append(']');
		return b.toString();
	}

	@StaticToString
	public static String toString(int[][] counts) {
		return toString(counts, null, null, 10, 10, NumberFormat.getInstance(), false);
	}

	public static String toString(int[][] counts, Object[] rowLabels, Object[] colLabels, int labelSize, int cellSize, NumberFormat nf, boolean printTotals) {
		// first compute row totals and column totals
		if (counts.length==0 || counts[0].length==0) return "";
		int[] rowTotals = new int[counts.length];
		int[] colTotals = new int[counts[0].length]; // assume it's square
		int total = 0;
		for (int i = 0; i < counts.length; i++) {
			for (int j = 0; j < counts[i].length; j++) {
				rowTotals[i] += counts[i][j];
				colTotals[j] += counts[i][j];
				total += counts[i][j];
			}
		}
		StringBuffer result = new StringBuffer();
		// column labels
		if (colLabels != null) {
			result.append(padLeft("", labelSize)); // spacing for the row labels!
			for (int j = 0; j < counts[0].length; j++) {
				String s = (colLabels[j]==null ? "null" : colLabels[j].toString());
				if (s.length() > cellSize - 1) {
					s = s.substring(0, cellSize - 1);
				}
				s = padLeft(s, cellSize);
				result.append(s);
			}
			if (printTotals) {
				result.append(padLeftOrTrim("Total", cellSize));
			}
			result.append("\n");
		}
		for (int i = 0; i < counts.length; i++) {
			// row label
			if (rowLabels != null) {
				String s = (rowLabels[i]==null ? "null" : rowLabels[i].toString());
				s = padOrTrim(s, labelSize); // left align this guy only
				result.append(s);
			}
			// value
			for (int j = 0; j < counts[i].length; j++) {
				result.append(padLeft(nf.format(counts[i][j]), cellSize));
			}
			// the row total
			if (printTotals) {
				result.append(padLeft(nf.format(rowTotals[i]), cellSize));
			}
			result.append("\n");
		}
		// the col totals
		if (printTotals) {
			result.append(pad("Total", labelSize));
			for (int j = 0; j < colTotals.length; j++) {
				result.append(padLeft(nf.format(colTotals[j]), cellSize));
			}
			result.append(padLeft(nf.format(total), cellSize));
		}
		return result.toString();
	}


	@StaticToString
	public static String toString(double[][] counts) {
		return toString(counts, 10, null, null, NumberFormat.getInstance(), false);
	}

	public static String toString(double[][] counts, int cellSize, Object[] rowLabels, Object[] colLabels, NumberFormat nf, boolean printTotals) {
		if (counts==null) return null;
		// first compute row totals and column totals
		double[] rowTotals = new double[counts.length];
		double[] colTotals = new double[counts[0].length]; // assume it's square
		double total = 0.0;
		for (int i = 0; i < counts.length; i++) {
			for (int j = 0; j < counts[i].length; j++) {
				rowTotals[i] += counts[i][j];
				colTotals[j] += counts[i][j];
				total += counts[i][j];
			}
		}
		StringBuffer result = new StringBuffer();
		// column labels
		if (colLabels != null) {
			result.append(padLeft("", cellSize));
			for (int j = 0; j < counts[0].length; j++) {
				String s = colLabels[j].toString();
				if (s.length() > cellSize - 1) {
					s = s.substring(0, cellSize - 1);
				}
				s = padLeft(s, cellSize);
				result.append(s);
			}
			if (printTotals) {
				result.append(padLeftOrTrim("Total", cellSize));
			}
			result.append("\n");
		}
		for (int i = 0; i < counts.length; i++) {
			// row label
			if (rowLabels != null) {
				String s = rowLabels[i].toString();
				s = padOrTrim(s, cellSize); // left align this guy only
				result.append(s);
			}
			// value
			for (int j = 0; j < counts[i].length; j++) {
				result.append(padLeft(nf.format(counts[i][j]), cellSize));
			}
			// the row total
			if (printTotals) {
				result.append(padLeft(nf.format(rowTotals[i]), cellSize));
			}
			result.append("\n");
		}
		// the col totals
		if (printTotals) {
			result.append(pad("Total", cellSize));
			for (int j = 0; j < colTotals.length; j++) {
				result.append(padLeft(nf.format(colTotals[j]), cellSize));
			}
			result.append(padLeft(nf.format(total), cellSize));
		}
		return result.toString();
	}

	@StaticToString
	public static String toString(float[][] counts) {
		return toString(counts, 10, null, null, NumberFormat.getIntegerInstance(), false);
	}

	public static String toString(float[][] counts, int cellSize, Object[] rowLabels, Object[] colLabels, NumberFormat nf, boolean printTotals) {
		// first compute row totals and column totals
		double[] rowTotals = new double[counts.length];
		double[] colTotals = new double[counts[0].length]; // assume it's square
		double total = 0.0;
		for (int i = 0; i < counts.length; i++) {
			for (int j = 0; j < counts[i].length; j++) {
				rowTotals[i] += counts[i][j];
				colTotals[j] += counts[i][j];
				total += counts[i][j];
			}
		}
		StringBuffer result = new StringBuffer();
		// column labels
		if (colLabels != null) {
			result.append(padLeft("", cellSize));
			for (int j = 0; j < counts[0].length; j++) {
				String s = colLabels[j].toString();
				s = padLeftOrTrim(s, cellSize);
				result.append(s);
			}
			if (printTotals) {
				result.append(padLeftOrTrim("Total", cellSize));
			}
			result.append("\n");
		}
		for (int i = 0; i < counts.length; i++) {
			// row label
			if (rowLabels != null) {
				String s = rowLabels[i].toString();
				s = pad(s, cellSize); // left align this guy only
				result.append(s);
			}
			// value
			for (int j = 0; j < counts[i].length; j++) {
				result.append(padLeft(nf.format(counts[i][j]), cellSize));
			}
			// the row total
			if (printTotals) {
				result.append(padLeft(nf.format(rowTotals[i]), cellSize));
			}
			result.append("\n");
		}
		// the col totals
		if (printTotals) {
			result.append(pad("Total", cellSize));
			for (int j = 0; j < colTotals.length; j++) {
				result.append(padLeft(nf.format(colTotals[j]), cellSize));
			}
			result.append(padLeft(nf.format(total), cellSize));
		}
		return result.toString();
	}

	/**
	 * Return a String of length a minimum of totalChars characters by
	 * padding the input String str at the right end with spaces. 
	 * If str is already longer
	 * than totalChars, it is returned unchanged.
	 */
	public static String pad(String str, int totalChars) {
		if (str == null) {
			str = "null";
		}
		int slen = str.length();
		StringBuilder sb = new StringBuilder(str);
		for (int i = 0; i < totalChars - slen; i++) {
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * Pads the given String to the left with the given character to ensure that
	 * it's at least totalChars long.
	 */
	public static String padLeft(String str, int totalChars, char ch) {
		if (str == null) {
			str = "null";
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0, num = totalChars - str.length(); i < num; i++) {
			sb.append(ch);
		}
		sb.append(str);
		return sb.toString();
	}


	/**
	 * Pads the given String to the left with spaces to ensure that it's
	 * at least totalChars long.
	 */
	public static String padLeft(String str, int totalChars) {
		return padLeft(str, totalChars, ' ');
	}


	public static String padLeft(Object obj, int totalChars) {
		return padLeft(obj.toString(), totalChars);
	}

	public static String padLeft(int i, int totalChars) {
		return padLeft(new Integer(i), totalChars);
	}

	public static String padLeft(double d, int totalChars) {
		return padLeft(new Double(d), totalChars);
	}

	/**
	 * Pad or trim so as to produce a string of exactly a certain length.
	 *
	 * @param str The String to be padded or truncated
	 * @param num The desired length
	 */
	public static String padOrTrim(String str, int num) {
		if (str == null) {
			str = "null";
		}
		int leng = str.length();
		if (leng < num) {
			StringBuilder sb = new StringBuilder(str);
			for (int i = 0; i < num - leng; i++) {
				sb.append(" ");
			}
			return sb.toString();
		} else if (leng > num) {
			return str.substring(0, num);
		} else {
			return str;
		}
	}

	/**
	 * Pad or trim so as to produce a string of exactly a certain length.
	 *
	 * @param str The String to be padded or truncated
	 * @param num The desired length
	 */
	public static String padLeftOrTrim(String str, int num) {
		if (str == null) {
			str = "null";
		}
		int leng = str.length();
		if (leng < num) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < num - leng; i++) {
				sb.append(" ");
			}
			sb.append(str);
			return sb.toString();
		} else if (leng > num) {
			return str.substring(str.length() - num);
		} else {
			return str;
		}
	}

}
