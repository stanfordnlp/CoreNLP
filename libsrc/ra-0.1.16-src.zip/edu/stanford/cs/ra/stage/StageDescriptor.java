/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import edu.stanford.cs.ra.xml.XMLStream;

/**
 * Information about a stage, consisting of its names and arguments.
 * Implements equality based on field values.  Safe to use as a hash key.
 * 
 * @author dramage
 */
class StageDescriptor implements Serializable {
	
	/** Global unique name of the descriptor. */
	public final String name;
	
	/** All argument values. */
	public final Map<String,String> arguments;
	
	/** Initializes this descriptor with the given name and arguments. */
	public StageDescriptor(String name, Map<String,String> arguments) {
		this.name = name;
		this.arguments = Collections.unmodifiableMap(
				new LinkedHashMap<String,String>(arguments));
	}
	
	public void toXML(XMLStream stream) {
		stream.begin("StageDescriptor", "name", name);
		for (Map.Entry<String, String> entry : arguments.entrySet()) {
			stream.line("Argument", "", "name", entry.getKey(), "value", entry.getValue());
		}
		stream.end("StageDescriptor");
	}
	
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof StageDescriptor)) {
			return false;
		}
		
		StageDescriptor otherDescriptor = (StageDescriptor)other;
		return this.name.equals(otherDescriptor.name)
			&& this.arguments.equals(otherDescriptor.arguments);
	}
	
	@Override
	public int hashCode() {
		int hash = this.name.hashCode();
		
		// it's important to use operations here that are order independent.
		for (Map.Entry<String,String> entry : arguments.entrySet()) {
			hash += entry.getKey().hashCode();
			hash += entry.getValue().hashCode();
		}
		
		return hash;
	}

	@Override
	public String toString() {
		return "StageDescriptor("+name+","+arguments+")";
	}
	
	private static final long serialVersionUID = 1L;
}
