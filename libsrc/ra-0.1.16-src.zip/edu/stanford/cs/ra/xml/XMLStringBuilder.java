/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

/**
 * Builds a String from convenient XML fragments.  Wraps {@link XMLOutputStream}
 * around {@link ByteArrayOutputStream}.
 * 
 * @author dramage
 */
public class XMLStringBuilder implements XMLStream {

	private final ByteArrayOutputStream bytes;
	private final XMLOutputStream stream;

	public XMLStringBuilder() {
		bytes = new ByteArrayOutputStream();
		stream = new XMLOutputStream(new PrintStream(bytes));
	}

	/** See {@link XMLStream#line(String, Object, Object...)}. */
	public XMLStringBuilder line(String tag, Object body, Object ... args) {
		stream.line(tag, body, args);
		return this;
	}

	/** See {@link XMLStream#begin(String, Object...)}. */
	public XMLStringBuilder begin(String tag, Object ... args) {
		stream.begin(tag, args);
		return this;
	}

	/** See {@link XMLStream#end(String)}. */
	public XMLStringBuilder end(String tag) {
		stream.end(tag);
		return this;
	}

	/** See {@link XMLStream#xml(EscapedXML)}. */
	public XMLStringBuilder xml(EscapedXML xml) {
		stream.xml(xml);
		return this;
	}
	
	/** See {@link XMLStream#close()}. */
	public void close() {
		stream.close();
	}
	
	/** See {@link XMLStream#getTagStack()}. */
	public List<String> getTagStack() {
		return stream.getTagStack();
	}

	/**
	 * Closes any outstanding tags and returns the String representation
	 * of the fragments.  Future calls to to begin, line, end, etc., 
	 * have no effect.
	 */
	@Override
	public String toString() {
		stream.close();
		return bytes.toString();
	}
}
