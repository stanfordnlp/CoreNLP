package edu.stanford.cs.ra.workbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * A ResourceSet that looks at a subfolder of a given ResourceSet.
 * 
 * @author dramage
 */
public class SubResourceSet implements ResourceSet {
	
	private static final long serialVersionUID = 2L;

	/** Underlying ResourceSet that we wrap. */
	private ResourceSet resources;
	
	/** Folder name to use as a prefix. */
	private String folder;
	
	/**
	 * Instantiates this ResourceSet to wrap the given resource set
	 * pre-prending the given folder name as the prefix for all calls
	 * to get* has* and list*.
	 */
	public SubResourceSet(ResourceSet resources, String folder) {
		this.resources = resources;
		this.folder = folder;
		
		if (!folder.endsWith("/")) {
			folder += "/";
		}
	}

	/** {@inheritDoc} */
	public InputStream getInputStream(String path) throws QuietIOException {
		return resources.getInputStream(folder+path);
	}

	/** {@inheritDoc} */
	public OutputStream getOutputStream(String path) throws QuietIOException {
		return resources.getOutputStream(folder+path);
	}

	/** {@inheritDoc} */
	public boolean hasResource(String path) {
		return resources.hasResource(folder+path);
	}

	/** {@inheritDoc} */
	public String[] listResources() {
		return listResources("");
	}
	
	/** {@inheritDoc} */
	public String[] listResources(String path) {
		return resources.listResources(folder+path);
	}

	/**
	 * Returns the ResourceSet underlying this SubResourceSet.
	 */
	public ResourceSet getResourceSet() {
		return resources;
	}

	public URI getInputURI(String path) {
		return resources.getInputURI(folder+path);
	}

	public URI getOutputURI(String path) {
		return resources.getOutputURI(folder+path);
	}

	/**
	 * Returns the folder prefix used when requesting resources from
	 * the underlying resource set.
	 */
	public String getFolder() {
		return folder;
	}
	
}
