/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stringify;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.stanford.cs.ra.util.ReflectionUtils;
import edu.stanford.cs.ra.xml.XMLStringBuilder;
import edu.stanford.cs.ra.xml.XMLSummarizable;

/**
 * <p>
 * Stringify is an infrastructure for simple over-riding of Java's toString
 * method with custom implementations and for providing a standardized means of
 * instantiating a class from a String descriptor.
 * </p>
 * 
 * <p>
 * Usage is simple: call String s = Stringify.toString(object) or MyClass object =
 * Stringify.fromString(s).
 * </p>
 * 
 * <p>
 * Stringify will search for a registered FromString instance or ToString
 * instance for the requested type. If none is found, it searches the calling
 * class for static methods marked with {@link StaticToString} or
 * {@link StaticFromString} to call instead. If again not found, Stringify
 * degrades gracefully to calling toString() or new MyClass(String) when able.
 * </p>
 * 
 * @author dramage
 */
@SuppressWarnings("unchecked")
public class Stringify {

	//
	// Public Stringify interfaces
	//
	
	/**
	 * For converting an object of type T into a String.
	 */
	public interface ToString<T> {
		/**
		 * Returns a simple String representation of the given object.
		 */
		public String toString(T object);
	}
	
	/**
	 * For converting from a String to an object of type T.
	 */
	public interface FromString<T> {
		/**
		 * Creates a an object from a simple String description.
		 * 
		 * @throws StringifyException on malformed input.
		 */
		public T fromString(String string) throws StringifyException;
	}
	
	/**
	 * Marks a static method as a ToString method the type of the
	 * first (and only) argument.
	 */
	@Documented
	@Target({ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface StaticToString {
		// Empty marker interface
	}

	/**
	 * Marks a static method as a FromString method for its return type.
	 */
	@Documented
	@Target({ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface StaticFromString {
		// Empty marker interface
	}
	
	
	//
	// Cached lookup data structures
	//
	
	/** For Any -> String */
	private static final Map<Class<?>, ToString<?>>
		toStringers = new HashMap<Class<?>,ToString<?>>();
	
	/** For String -> Any */
	private static final Map<Class<?>, FromString<?>>
		fromStringers = new HashMap<Class<?>,FromString<?>>();
	
	/** Classes that we've already extracted StaticFromString */
	private static final Set<Class<?>>
		loadedStaticStringers = new HashSet<Class<?>>();
	
	static {
		loadStaticStringers(StringifyBuiltins.class);
		loadStaticStringers(StringifyPrimitives.class);
		
		//
		// ToString: common types
		//
		
		registerToString(XMLSummarizable.class, new ToString<XMLSummarizable>() {
			public String toString(XMLSummarizable object) {
				XMLStringBuilder builder = new XMLStringBuilder();
				object.summarize(builder);
				return builder.toString();
			}
		});
	}

	//
	// registration of FromString and ToString instances
	//
	
	/**
	 * Registers the given FromString for handling classes of the given type.
	 */
	public static <V> void registerFromString(Class<V> type, FromString<V> fromString) {
		fromStringers.put(type, fromString);
	}
	/**
	 * Registers the given ToString for handling classes of the given type.
	 */
	public static <V> void registerToString(Class<V> type, ToString<V> toString) {
		toStringers.put(type, toString);
	}

	/**
	 * Register the given constructor for handling the given type.
	 */
	private static <V> void registerFromStringConstructor(final Class<V> type,
			final Constructor<V> constructor, boolean overwrite) {
		if (!overwrite && fromStringers.containsKey(type)) {
			return;
		}
			
		registerFromString(type, new FromString<V>() {
			public V fromString(String string) {
				try {
					return constructor.newInstance(string);
				} catch (InvocationTargetException e) {
					Throwable inner = e.getCause();
					if (inner instanceof StringifyException) {
						throw (StringifyException)inner;
					} else {
						throw new StringifyException(inner);
					}
				} catch (StringifyException e) {
					throw e;
				} catch (Exception e) {
					throw new StringifyException("Unable to " +
							"instantiate using String constructor",e);
				}
			}
		});
	}
	
	/**
	 * Registers the given static method for handling the given type.  It
	 * should take one argument, which can be turned into a String with
	 * fromString.
	 */
	private static <V> void registerFromStringStatic(final Class<V> type,
			final Method method, boolean overwrite) {
		if (!overwrite && fromStringers.containsKey(type)) {
			return;
		}
		
		assert method.getParameterTypes().length == 1;
		final Class<?> argtype = method.getParameterTypes()[0];
		assert hasFromString(argtype);
		
		registerFromString(type, new FromString<V>() {
			public V fromString(String string) {
				try {
					Object argument = string;
					if (argtype != String.class) {
						argument = Stringify.fromString(argtype, string);
					}
					return (V)method.invoke(null, argument);
				} catch (InvocationTargetException e) {
					Throwable inner = e.getTargetException();
					if (inner instanceof StringifyException) {
						throw (StringifyException)inner;
					} else {
						throw new StringifyException(inner);
					}
				} catch (StringifyException e) {
					throw e;
				} catch (Exception e) {
					throw new StringifyException("Unable to call "+method
							+" - it should be public, static, and take one"
							+" string as an argument");
				}
			}
		});
	}


	/**
	 * Registers the given FromString for handling classes of the given type.
	 */
	private static <V> void registerToStringStatic(final Class<V> type,
			final Method method, boolean overwrite) {
		if (!overwrite && toStringers.containsKey(type)) {
			return;
		}
			
		registerToString(type, new ToString<V>() {
			public String toString(V object) {
				try {
					return (String)method.invoke(null, object);
				} catch (InvocationTargetException e) {
					Throwable inner = e.getTargetException();
					if (inner instanceof StringifyException) {
						throw (StringifyException)inner;
					} else {
						throw new StringifyException(e);
					}
				} catch (StringifyException e) {
					throw e;
				} catch (Exception e) {
					throw new StringifyException("Unable to call "+method
							+" - it should be public, static, and take one "
							+type+" as an argument");
				}
			}
		});
	}
	
	//
	// main utility methods
	//
	
	/**
	 * Returns true if we can build an instance of the given type from
	 * a String description.
	 */
	public static boolean hasFromString(Class<?> type) {
		// ensure that we've loaded any custom stringers in the class itself
		loadStaticStringers(type, false);
		
		return  type.isEnum()
			|| (type.isArray() && hasFromString(type.getComponentType()))
			|| fromStringers.containsKey(type);
	}
	
	/**
	 * Returns an instance of the requested type from the given description.
	 * 
	 * @throws StringifyException if no FromString has been registered
	 *   for the given type or an error occurs while instantiating from
	 *   the String.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T fromString(Class<T> type, String desc) throws StringifyException {
		// ensure that we've loaded any custom stringers in the class itself
		loadStaticStringers(type, false);
		
		if (fromStringers.containsKey(type)) {
			return (T)fromStringers.get(type).fromString(desc);
		} else if (type.isEnum()) {
			return (T)Enum.valueOf((Class)type, desc);
		} else if (type.isArray()) {
			return (T)StringifyBuiltins.arrayFromString(type.getComponentType(), desc);
		} else {
			throw new StringifyException("No FromString for "+type);
		}
	}
	
	/**
	 * Converts the given object to a String, either by calling the registered
	 * method or by falling back to the object's builtin toString.
	 */
	public static String toString(Object object) {
		if (object == null) {
			return "null";
		}
		
		// ensure that we've loaded any custom stringers in the class itself
		loadStaticStringers(object.getClass(), false);
		
		// enums are covered by default toString at the bottom
		
		if (object.getClass().isArray()) {
			return StringifyBuiltins.arrayToString(object);
		}
		
		for (Class<?> type : ReflectionUtils.getClassHierarchy(object.getClass())) {
			if (toStringers.containsKey(type)) {
				return ((ToString)toStringers.get(type)).toString(object);
			}
		}

		return object.toString();
	}

	/**
	 * Converts an array of objects to a String, either by calling the
	 * registered method or by the object's builtin toString.
	 */
	public static String[] toStrings(Object ... objects) {
		if (objects == null) {
			return new String[0];
		}
		
		String[] strings = new String[objects.length];
		for (int i = 0; i < objects.length; i++) {
			strings[i] = toString(objects[i]);
		}
		return strings;
	}
	
	/**
	 * Loads all {@link StaticToString} and {@link StaticFromString} methods
	 * in the given class.
	 */
	public static <T> void loadStaticStringers(Class<T> type) {
		loadStaticStringers(type, true);
	}
	
	/**
	 * Loads all {@link StaticToString} and {@link StaticFromString} methods
	 * in the given class, only over-writing existing definitions of overwrite
	 * is true.
	 */
	private static <T> void loadStaticStringers(Class<T> type, boolean overwrite) {
		if (loadedStaticStringers.contains(type)) {
			// don't re-read static stringers from class files
			return;
		}
		
		// record addition of type
		loadedStaticStringers.add(type);
		
		// look for String constructor (this may be over-written below)
		Constructor<T> constructor = null;
		try {
			constructor = type.getConstructor(String.class);
		} catch (Exception e) {
			// ok if we don't find a constructor
		}
		
		if (constructor != null &&
			Modifier.isPublic(constructor.getModifiers()) &&
			!type.isMemberClass()) {

			registerFromStringConstructor(type, constructor, overwrite);
		}
		
		// look for annotated static methods
		for (Method method : ReflectionUtils.getAllMethods(type)) {
			if (method.getAnnotation(StaticFromString.class) != null) {
				
				if (Modifier.isPublic(method.getModifiers()) &&
					Modifier.isStatic(method.getModifiers()) &&
					method.getParameterTypes().length == 1 &&
					hasFromString(method.getParameterTypes()[0])) {
					
					registerFromStringStatic(method.getReturnType(), method, overwrite);
					
				} else {
					throw new IllegalArgumentException("Invalid "+
							StaticFromString.class.getSimpleName()+" "+method+
							": should be public, static, and take only one " +
							"FromString-able argument");
				}
			}
			
			if (method.getAnnotation(StaticToString.class) != null) {
				
				if (Modifier.isPublic(method.getModifiers()) &&
					Modifier.isStatic(method.getModifiers()) &&
					method.getParameterTypes().length == 1 &&
					method.getReturnType() == String.class) {
					
					registerToStringStatic(method.getParameterTypes()[0], method, overwrite);
					
				} else {
					throw new IllegalArgumentException("Invalid "+
							StaticToString.class.getSimpleName()+" "+method+
							": should be public, static, and take only one " +
							"argument, returning a String");
				}
			}
		}
		
		// Load static definitions from supertype without overwriting
		if (type.getSuperclass() != null) {
			loadStaticStringers(type.getSuperclass(), false);
		}
		
		// Load static definitions from enclosing type without overwriting
		if (type.getEnclosingClass() != null) {
			loadStaticStringers(type.getEnclosingClass(), false);
		}
		
		// Load static definitions from paired utility class ending with "s"
		if (type.getName() != null) {
			Class<?> paired = null;
			try {
				paired = Class.forName(type.getName()+"s");
			} catch (ClassNotFoundException e) {
				// no such class, that's ok
			}
			if (paired != null) {
				loadStaticStringers(paired);
			}
		}
		
	}

	//
	// Generic string escaping utilities
	//

	/**
	 * Returns a backslash-escaped version of the given string, consistent
	 * with Java's use of escaping.
	 */
	public static String escape(String string) {
		return escapeJavaStyleString(string, "");
	}

	/**
	 * Returns a backslash-escaped version of the given string, consistent
	 * with Java's use of escaping, additionally escaping any other chars
	 * specified.
	 */
	public static String escape(String string, String additional) {
		return escapeJavaStyleString(string, "");
	}

    /**
     * Returns an unescaped version of the given string.
     */
    public static String unescape(String string) {
    	return unescapeJavaStyleString(string);
    }
    
    /**
     * Returns a String consisting of the stringified representation
     * of all of the given objects, connected with the given glue character.
     * Each string is first escaped (including any glue characters in that
     * String), so that the objects can be safely resplit with escapedSplit.
     */
    public static <T> String escapedJoin(Collection<T> objects, char glue) {
    	if (objects.size() == 0) {
    		return "";
    	}
    	
    	StringBuilder builder = new StringBuilder();
    	for (Object obj : objects) {
    		builder.append(escapeJavaStyleString(toString(obj), ""+glue));
    		builder.append(glue);
    	}
    	return builder.substring(0, builder.length()-1);
    }
    
    /**
     * Returns a String consisting of the stringified representation
     * of all of the given objects, connected with the given glue character,
     * and quoting each string with the given quote character, which is
     * escaped with \.
     */
    public static <T> String escapedQuotedJoin(Collection<T> objects, char glue, char quote) {
    	if (objects.size() == 0) {
    		return "";
    	}
    	
    	StringBuilder builder = new StringBuilder();
    	for (Object obj : objects) {
    		builder.append(quote).
    			append(escapeJavaStyleString(toString(obj), ""+quote)).
    			append(quote).append(glue);
    	}
    	return builder.substring(0, builder.length()-1);
    }
    
    /**
     * Splits the given string by the given glue character, unescaping
     * each substring, and then calling fromString on it.  Returns the
     * resulting list of objects.
     */
    public static <T> List<T> escapedSplit(Class<T> type, String string, char glue) {
        final int sz = string.length();
        
        if (sz == 0) {
        	return Collections.emptyList();
        }
        
        int numBackslashes = 0;
        
        List<Integer> splitPositions = new ArrayList<Integer>(string.length() / 4);
        splitPositions.add(-1);
        for (int charIndex = 0; charIndex < sz; charIndex++) {
        	char ch = string.charAt(charIndex);
        	
        	if (ch == '\\') {
        		numBackslashes++;
        	} else {
        		if (ch == glue && numBackslashes % 2 == 0) {
        			// split here
        			splitPositions.add(charIndex);
        		}
        		numBackslashes = 0;
        	}
        }
        splitPositions.add(string.length());
        
        List<T> objects = new ArrayList<T>(splitPositions.size()-1);
        
        for (int splitIndex = 1; splitIndex < splitPositions.size(); splitIndex++) {
        	String substring = string.substring(
        			splitPositions.get(splitIndex-1)+1,
					splitPositions.get(splitIndex));
        	
        	objects.add(fromString(type, unescapeJavaStyleString(substring)));
        }
        
        return objects;
    }
    
    /**
     * Splits the given string by the given glue character (with repetition),
     * unescaping each substring, and then calling fromString on it.  Returns
     * the resulting list of objects.
     */
    public static <T> List<T> escapedQuotedSplit(Class<T> type, String string, char glue, char quote) {
        final int sz = string.length();
        int numBackslashes = 0;
        boolean inQuote = false;
        
        List<Integer> splitPositions = new ArrayList<Integer>(string.length() / 4);
        splitPositions.add(-1);
        
        for (int charIndex = 0; charIndex < sz; charIndex++) {
        	char ch = string.charAt(charIndex);
        	
        	if (ch == '\\') {
        		numBackslashes++;
        	} else {
        		if (numBackslashes % 2 == 0) {
            		if (ch == quote) {
            			inQuote = !inQuote;
            		} else if (ch == glue && !inQuote) {
            			// split here
            			splitPositions.add(charIndex);
            		}
        		}
        		numBackslashes = 0;
        	}
        }
        splitPositions.add(string.length());
        
        List<T> objects = new ArrayList<T>(splitPositions.size()-1);
        
        for (int splitIndex = 1; splitIndex < splitPositions.size(); splitIndex++) {
        	String substring = string.substring(
        			splitPositions.get(splitIndex-1)+1,
					splitPositions.get(splitIndex));
        	
        	objects.add(fromString(type, unescapeJavaStyleString(substring)));
        }
        
        return objects;
    }
    

    /**
	 * <p>
	 * Worker method for the {@link #escapeJavaScript(String)} method.
	 * </p>
	 * 
	 * <p>
	 * Excerpted from Apache Commons Lang 2.3.
	 * </p>
	 * 
	 * @author Apache Jakarta Turbine
	 * @author Purple Technology
	 * @author <a href="mailto:alex@purpletech.com">Alexander Day Chaffee</a>
	 * @author Antony Riley
	 * @author Helge Tesgaard
	 * @author <a href="sean@boohai.com">Sean Brown</a>
	 * @author <a href="mailto:ggregory@seagullsw.com">Gary Gregory</a>
	 * @author Phil Steitz
	 * @author Pete Gieser
	 * @since 2.0
	 * @version $Id: StringEscapeUtils.java 471626 2006-11-06 04:02:09Z bayard $
	 * 
	 * @param str
	 *            String to escape values in, may be null
	 * @param toEscape
	 * 			  String of extra characters to escape.
	 */
    private static String escapeJavaStyleString(String str, String toEscape) {
    	
        if (str == null) {
            return null;
        }
        
        final int sz = str.length();
        
    	StringBuilder builder = new StringBuilder(sz * 2);
    	
        for (int i = 0; i < sz; i++) {
            char ch = str.charAt(i);

            // handle unicode
            if (ch > 0xfff) {
                builder.append("\\u").append(hex(ch));
            } else if (ch > 0xff) {
                builder.append("\\u0").append(hex(ch));
            } else if (ch > 0x7f) {
            	builder.append("\\u00").append(hex(ch));
            } else if (ch < 32) {
            	switch (ch) {
            	case '\b':
            		builder.append('\\').append('b');
            		break;
            	case '\n':
            		builder.append('\\').append('n');
            		break;
            	case '\t':
            		builder.append('\\').append('t');
            		break;
            	case '\f':
            		builder.append('\\').append('f');
            		break;
            	case '\r':
            		builder.append('\\').append('r');
            		break;
            	default :
            		if (ch > 0xf) {
            			builder.append("\\u00").append(hex(ch));
            		} else {
            			builder.append("\\u000").append(hex(ch));
            		}
            		break;
            	}
            } else {
            	switch (ch) {
            	case '\'':
            		builder.append('\\').append('\'');
            		break;
            	case '"':
            		builder.append('\\').append('"');
            		break;
            	case '\\':
            		builder.append('\\').append('\\');
            		break;
            	default:
            		if (toEscape.indexOf(ch) >= 0) {
            			builder.append('\\');
            		}
            		builder.append(ch);
            		break;
            	}
            }
        }
        
        return builder.toString();
    }

    /**
     * <p>Returns an upper case hexadecimal <code>String</code> for the given
     * character.</p>
     * 
     * @param ch The character to convert.
     * @return An upper case hexadecimal <code>String</code>
     */
    private static String hex(char ch) {
        return Integer.toHexString(ch).toUpperCase();
    }
    

    /**
     * <p>Unescapes any Java literals found in the <code>String</code> to a
     * <code>Writer</code>.</p>
     *
     * <p>For example, it will turn a sequence of <code>'\'</code> and
     * <code>'n'</code> into a newline character, unless the <code>'\'</code>
     * is preceded by another <code>'\'</code>.</p>
     * 
     * <p>A <code>null</code> string input has no effect.</p>
	 * 
	 * <p>
	 * Excerpted from Apache Commons Lang 2.3.
	 * </p>
	 * 
	 * @author Apache Jakarta Turbine
	 * @author Purple Technology
	 * @author <a href="mailto:alex@purpletech.com">Alexander Day Chaffee</a>
	 * @author Antony Riley
	 * @author Helge Tesgaard
	 * @author <a href="sean@boohai.com">Sean Brown</a>
	 * @author <a href="mailto:ggregory@seagullsw.com">Gary Gregory</a>
	 * @author Phil Steitz
	 * @author Pete Gieser
	 * @since 2.0
	 * @version $Id: StringEscapeUtils.java 471626 2006-11-06 04:02:09Z bayard $
	 * 
     * 
     * @param str  the <code>String</code> to unescape, may be null
     */
    private static String unescapeJavaStyleString(String str) {
        if (str == null) {
            return null;
        }
        
        final int sz = str.length();
        StringBuilder builder = new StringBuilder(2 * sz);
        StringBuilder unicode = new StringBuilder(4);
        boolean hadSlash = false;
        boolean inUnicode = false;
        for (int i = 0; i < sz; i++) {
            char ch = str.charAt(i);
            if (inUnicode) {
                // if in unicode, then we're reading unicode
                // values in somehow
                unicode.append(ch);
                if (unicode.length() == 4) {
                    // unicode now contains the four hex digits
                    // which represents our unicode character
                    try {
                        int value = Integer.parseInt(unicode.toString(), 16);
                        builder.append((char) value);
                        unicode.setLength(0);
                        inUnicode = false;
                        hadSlash = false;
                    } catch (NumberFormatException nfe) {
                        throw new RuntimeException("Unable to parse unicode value: " + unicode, nfe);
                    }
                }
                continue;
            }
            if (hadSlash) {
                // handle an escaped value
                hadSlash = false;
                switch (ch) {
                    case '\\':
                        builder.append('\\');
                        break;
                    case '\'':
                    	builder.append('\'');
                        break;
                    case '\"':
                    	builder.append('"');
                        break;
                    case 'r':
                    	builder.append('\r');
                        break;
                    case 'f':
                    	builder.append('\f');
                        break;
                    case 't':
                    	builder.append('\t');
                        break;
                    case 'n':
                    	builder.append('\n');
                        break;
                    case 'b':
                    	builder.append('\b');
                        break;
                    case 'u':
                        {
                            // uh-oh, we're in unicode country....
                            inUnicode = true;
                            break;
                        }
                    default :
                    	builder.append(ch);
                        break;
                }
                continue;
            } else if (ch == '\\') {
                hadSlash = true;
                continue;
            }
            builder.append(ch);
        }
        if (hadSlash) {
            // then we're in the weird case of a \ at the end of the
            // string, let's output it anyway.
        	builder.append('\\');
        }
        
        return builder.toString();
    }
	
    
	//
	// Inner utiltiy classes
	//
	
//    /**
//     * A FromString instance for all registered instantiations of a given
//     * subtype.
//     */
//    public static class InterfaceFromString<T> implements FromString<T> {
//    	private final Map<Class<? extends T>,FromString<? extends T>> subtypes
//    		= new HashMap<Class<? extends T>,FromString<? extends T>>();
//    	
//		public T fromString(String desc) throws StringifyException {
//			final int argStart = desc.indexOf('(');
//			final int argEnd   = desc.lastIndexOf(')');
//			if (argStart > argEnd || (argEnd >= 0 && argEnd != desc.length()-1)) {
//				throw new StringifyException("Illegal InterfaceFromString " +
//						"format: should be ClassName(args)");
//			}
//			
//			final String   name = desc.substring(0, argStart >= 0 ? argStart : desc.length());
//			final String[] args = argStart < 0 ? new String[0] : desc.substring(argStart+1,argEnd).split(regex);
//		}
//    	
//		public <TT extends T> void register(Class<TT> subtype, FromString<TT> fromstring) {
//			subtypes.put(subtype, fromstring);
//		}
//    }
	
	/**
	 * Exception thrown when trying to build an object.
	 * 
	 * @author dramage
	 */
	public static class StringifyException extends RuntimeException {
		private static final long serialVersionUID = 1L;

		public StringifyException(String msg, Throwable cause) {
			super(msg, cause);
		}
		
		public StringifyException(String msg) {
			super(msg);
		}
		
		public StringifyException(Throwable cause) {
			super(cause);
		}
	}
}
