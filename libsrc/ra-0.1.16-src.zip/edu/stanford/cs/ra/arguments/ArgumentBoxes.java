/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.ReflectionUtils;

/**
 * Helper functions for dealing with {@link ArgumentBox} instances.
 * 
 * @author dramage
 */
public class ArgumentBoxes {

	/**
	 * If the given instance is an ArgumentBox, returns it.  Otherwise
	 * returns a box constructed via reflection to describe the annotated
	 * fields of the instance's type.
	 */
	public static ArgumentBox fromInstance(Object instance) {
		if (instance instanceof ArgumentBox) {
			return (ArgumentBox)instance;
		} else {
			return new ReflectedArgumentBox(instance);
		}
	}
	
	/**
	 * Returns a list of ArgumentBox instances by calling fromInstance on
	 * each given instance.
	 */
	public static List<ArgumentBox> fromInstances(Object ... instances) {
		List<ArgumentBox> boxes = new LinkedList<ArgumentBox>();
		for (Object instance : instances) {
			boxes.add(fromInstance(instance));
		}
		return boxes;
	}

	/**
	 * Returns a String suitable for writing to a .props properties file
	 * describing the current arguments of the given boxes.
	 */
	public static String asProps(Collection<ArgumentBox> boxes) {
		StringBuilder props = new StringBuilder();

		props.append("# RA generated arguments ")
			.append(new Date()).append("\n");

		for (ArgumentBox box : boxes) {
			props.append("\n# ").append(box.getName()).append("\n");

			for (ArgumentInfo arg : box.getArguments()) {
				props.append("\n").append(arg.toDescriptionString("# "));
				props.append(arg.getQualifiedName()).append(" = ").append(box.getValue(arg)).append("\n");
			}
		}

		return props.toString();
	}

	/**
	 * Returns a String suitable for writing to a .props properties file
	 * describing the current arguments of the given boxes.
	 */
	public static String asProps(ArgumentBox ... boxes) {
		return asProps(Arrays.asList(boxes));
	}
	
	/**
	 * Returns a map from argument name to stringified argument value for
	 * all arguments in the box.
	 */
	public static Map<String,String> asMap(ArgumentBox box, boolean qualified) {
		Map<String,String> strings = new TreeMap<String,String>();
		for (ArgumentInfo argument : box.getArguments()) {
			String name = qualified ? argument.getQualifiedName() : argument.getArgName();
			strings.put(name, box.getValue(argument));
		}
		return strings;
	}
	
	/**
	 * Sets default values on the given boxes
	 */
	public static void setDefaultValues(ArgumentBox box) {
		for (ArgumentInfo arg : box.getArguments()) {
			if (arg.getDefault() != null) {
				box.setValue(arg, arg.getDefault());
			}
		}
	}

	/**
	 * Returns an unmodifiable view of the given box.
	 */
	public static ArgumentBox unmodifiableArgumentBox(final ArgumentBox box) {
		return new ArgumentBox() {
			public void check() throws ArgumentException {
				// do nothing
			}

			public Collection<ArgumentInfo> getArguments() {
				return Collections.unmodifiableCollection(box.getArguments());
			}

			public String getName() {
				return box.getName();
			}

			public String getValue(ArgumentInfo argument) {
				return box.getValue(argument);
			}

			public void setValue(ArgumentInfo argument, String value) {
				throw new UnsupportedOperationException();
			}
			
			@Override
			public boolean equals(Object other) {
				if (!(other instanceof ArgumentBox)) {
					return false;
				}
				
				return ArgumentBoxes.equals(this, (ArgumentBox)other);
			}
			
			@Override
			public int hashCode() {
				throw new UnsupportedOperationException();
			}
			
		};
	}
	
	/**
	 * Returns true if box1 and box2 share the same argument values.
	 */
	public static boolean equals(ArgumentBox box1, ArgumentBox box2) {
		if (!box1.getName().equals(box2.getName())) {
			return false;
		}
		
		if (!box1.getArguments().equals(box2.getArguments())) {
			return false;
		}
		
		for (ArgumentInfo argument : box1.getArguments()) {
			if (!box1.getValue(argument).equals(box2.getValue(argument))) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Returns a usage string for the types added to this parser via
	 * addTargetType* methods.
	 */
	public static String usage(Collection<ArgumentBox> boxes) {
		StringBuilder usage = new StringBuilder();

		usage.append("\nUsage:\n");

		for (ArgumentBox box : boxes) {
			for (ArgumentInfo arg : box.getArguments()) {
				usage.append(arg.toDescriptionString("  "));
				usage.append("\n");
			}
		}

		return usage.toString();
	}
	
	/** Returns a map from every ArgumentInfo instance to the box defining it */
	static Map<ArgumentInfo,ArgumentBox> getInfoToBoxMap(Collection<ArgumentBox> boxes) {
		Map<ArgumentInfo,ArgumentBox> map = new HashMap<ArgumentInfo,ArgumentBox>();
		for (ArgumentBox box : boxes) {
			for (ArgumentInfo info : box.getArguments()) {
				if (map.containsKey(info)) {
					throw new ArgumentException("ArgumentBox "+box.getName()
							+" and "+map.get(info).getName()
							+" both expect argument "+info);
				}
				map.put(info, box);
			}
		}
		return map;
	}
	

	//
	// reflection helper classes
	//
	
	/**
	 * Returns true if the field is an argument (has any Arg* annotations).
	 */
	private static boolean isArgumentField(Field field) {
		return field.getAnnotation(Argument.class) != null;
	}
	
	/**
	 * For recursive arguments assignment.
	 */
	private static boolean isArgumentsInsideField(Field field) {
		return field.getAnnotation(Argument.ArgumentsInside.class) != null;
	}
	
	private static String getFieldAsString(Object instance, Field field) {
		try {
			return Stringify.toString(ReflectionUtils.getFieldValue(instance, field));
		} catch (Exception e) {
			throw new ArgumentException("Unable to get value from "+field, e);
		}
	}

	private static void setFieldFromString(Object instance, Field field, String value) {
		Object val;
		
		try {
			val = Stringify.fromString(field.getType(), value);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ArgumentException("Unable to parse argument for "+field+": "+"'"+value+"'", e);
		}
		
		// extra check for Class<?>
		// TODO: this is broken; need a real instance of Types() to check this
		// or a work-around in ReflectionUtils.
		if (val instanceof Class<?>) {
			Class<?> inferredType = (Class<?>)val;
			
			Type[] specified = ((ParameterizedType)field.getGenericType()).getActualTypeArguments();
			
			if (specified.length == 1) {
				if (specified[0] instanceof Class<?>) {
					
					Class<?> specifiedType = (Class<?>) specified[0];
					if (!specifiedType.isAssignableFrom(inferredType)) {
						throw new ArgumentException("Incompatible type specified");
					}
				} else if (specified[0] instanceof WildcardType) {
					WildcardType wildcard = (WildcardType) specified[0];
					boolean ok = true;
					for (Type type : wildcard.getUpperBounds()) {
						ok &= ((Class<?>)type).isAssignableFrom(inferredType);
					}
					if (!ok) {
						throw new ArgumentException("Incompatible type specified");
					}
				}
			}
		}
		
		try {
			ReflectionUtils.setFieldValue(instance, field, val);
		} catch (Exception e) {
			throw new ArgumentException(e.getCause() != null ? e.getCause().getMessage() : e.getMessage(), e);
		}
	}
	
	/**
	 * An {@link ArgumentBox} that knows about its types via reflection.
	 * This class should not be instantiated directly - instances should
	 * instead be retrieved via {@link ArgumentBoxes#fromInstance(Class)}.
	 * 
	 * @author dramage
	 */
	private static class ReflectedArgumentBox implements ArgumentBox {

		/** The object to populate */
		private final Object instance;
		
		/** Type of the object */
		private final Class<?> type;
		
		/** Arguments defined in this class with defining Field */
		private final Map<ArgumentInfo, Field> fields
			= new HashMap<ArgumentInfo, Field>();
		
		/** Arguments with the sub-box that defines them */
		private final Map<ArgumentInfo, ArgumentBox> boxes
			= new HashMap<ArgumentInfo, ArgumentBox>();
		
		/** All arguments */
		private final List<ArgumentInfo> allArguments
			= new LinkedList<ArgumentInfo>();

		/**
		 * Initializes this instance by reflection on the field
		 * annotations on the given type.
		 */
		private ReflectedArgumentBox(Object instance) {
			if (instance instanceof Class<?>) {
				// special settings for static values
				this.type = (Class<?>) instance;
				this.instance = ReflectionUtils.resolveObjectReference(type, null);
			} else {
				this.type = instance.getClass();
				this.instance = instance;
			}
			
			for (Field field : ReflectionUtils.getAllFields(type)) {
				if (isArgumentField(field)) {
					// an Argument field; remember it
					ArgumentInfo info;
					try {
						info = ArgumentInfo.fromField(field);
					} catch (IllegalArgumentException e) {
						throw new ArgumentException(e.getMessage() + ": "+field);
					}
					if (fields.containsKey(info)) {
						throw new ArgumentException("Both "+field+" and "+fields.get(info)+" declare ArgumentInfo "+info);
					}
					fields.put(info, field);
					allArguments.add(info);
				} else if (isArgumentsInsideField(field)) {
					// an ArgumentsInside field; read all arguments in it
					
					// instantiate if null
					Object inner = ReflectionUtils.getFieldValue(instance, field);
					if (inner == null) {
						inner = Arguments.instantiate(field.getType());
						ReflectionUtils.setFieldValue(instance, field, inner);
					}

					// recurse to add argument info
					ArgumentBox subbox = ArgumentBoxes.fromInstance(inner);
					for (ArgumentInfo info : subbox.getArguments()) {
						allArguments.add(info);
						if (boxes.containsKey(info)) {
							throw new ArgumentException("More than one " +
									"ArgumentBox somehow references "+info);
						}
						boxes.put(info, subbox);
					}
					
					// throw new RuntimeException("Not yet implemented");
				}
			}
		}
		
		public String getName() {
			if (type.getAnnotation(Argument.BoxName.class) != null) {
				return type.getAnnotation(Argument.BoxName.class).value();
			} else {
				return type.getName();
			}
		}
		
		public Collection<ArgumentInfo> getArguments() {
			return Collections.unmodifiableCollection(allArguments);
		}

		public String getValue(ArgumentInfo argument) {
			if (fields.containsKey(argument)) {
				return getFieldAsString(instance, fields.get(argument));
			} else if (boxes.containsKey(argument)) {
				return boxes.get(argument).getValue(argument);
			} else {
				throw new ArgumentException("Argument "+argument+" was not defined by box "+getName());
			}
		}

		public void setValue(ArgumentInfo argument, String value) {
			if (fields.containsKey(argument)) {
				setFieldFromString(instance, fields.get(argument), value);
			} else if (boxes.containsKey(argument)) {
				boxes.get(argument).setValue(argument, value);
			} else {
				throw new ArgumentException("Argument "+argument+" was not defined by box"+getName());
			}
		}
		
		/**
		 * Calls ArgCheck methods on all classes.
		 */
		public void check() {
			for (Method method : ReflectionUtils.getAllMethods(type)) {
				if (method.getAnnotation(Argument.Check.class) != null) {
					if (method.getParameterTypes().length != 0) {
						throw new ArgumentException("@ArgCheck method "+method+" must take no arguments");
					}
					
					try {
						synchronized(method) {
							boolean accessible = method.isAccessible();
							method.setAccessible(true);
							method.invoke(instance);
							method.setAccessible(accessible);
						}
					} catch (InvocationTargetException e) {
						Throwable thrown = e.getTargetException();
						if (thrown instanceof ArgumentException) {
							throw (ArgumentException) thrown;
						} else {
							throw new ArgumentException("Error while calling @Argument.Check method "+method, thrown);
						}
					} catch (ArgumentException e) {
						// some systems don't seem to wrap this in an ITE ?
						// reported by oliner 10/19/2007 
						throw e;
					} catch (Exception e) {
						throw new ArgumentException("Unexpected error when calling @Argument.Check method "+method + ".  This is probably a bug in RA.", e);
					}
				}
			}
			
			for (ArgumentBox subbox : new HashSet<ArgumentBox>(boxes.values())) {
				subbox.check();
			}
		}

		@Override
		public String toString() {
			return getName();
		}
	}
}
