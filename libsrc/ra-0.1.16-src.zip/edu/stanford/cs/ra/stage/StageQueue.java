/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Queue of stages to be run.  Keeps a list of top-level stages ready to
 * be run and for each a list of stages that need to be run.
 * 
 * @author dramage
 */
class StageQueue {

	/** StageWise provides sub-queues to be run */
	private final StageWise stagewise;
	
	/** Which StageDescriptors have already been run */
	private final Set<StageLineage> ran
		= new HashSet<StageLineage>();
	
	/** Queue of stages to be run. */
	private final Queue<StageSchedule> queue
		= new LinkedList<StageSchedule>();
	
	/** True if we are currently in runAll() */
	private boolean running;
	
	/**
	 * Instantiates this queue to use the given StageWise instance as
	 * a backend.
	 */
	public StageQueue(StageWise stagewise) {
		this.stagewise = stagewise;	
	}
	
	/**
	 * Enqueues the given StageRunner to run (last) in the queue.  Does
	 * nothing if the given runner has already been run.
	 */
	public void enqueue(StageRunner runner) {
		// get the schedule and require the root
		queue.add(StageSchedule.fromStageRunner(stagewise, runner));
	}
	
	/**
	 * Runs the next StageRunner in the queue.
	 */
	public void runNext() {
		if (queue.isEmpty()) {
			return;
		}
		
		// next top-level stage
		StageSchedule schedule = queue.poll();
		schedule.require();
		
		// allow the top-level stage to be run
		ran.remove(schedule.lineage);
		
		stagewise.stream.begin("StageWise", "target",
				schedule.runner.getStageDescriptor().name);
		
		// run all stages for the top-level stage
		for (StageSchedule node : schedule.asList()) {
			// don't run if already run
			StageSchedule.StageAction action = node.getAction();
			if (ran.contains(node.lineage)) {
				action = StageSchedule.StageAction.SKIP;
			} else {
				// add the descriptor to the ran set and remove
				// the reference to its corresponding runner to avoid
				// memory leak
				ran.add(node.lineage);
				stagewise.runners.remove(node.lineage);
			}

			// always run if freshness requested
			if (action == StageSchedule.StageAction.LOAD && stagewise.freshness.isSet) {
				action = StageSchedule.StageAction.RUN;
			}
			
			stagewise.stream.begin("Stage",
					"name", node.runner.getStageDescriptor().name,
					"action", action);
			
			node.runner.getStageDescriptor().toXML(stagewise.stream);
			
			switch (action) {
			case LOAD:
				// load checkpoint into the StageWise context
				for (Map.Entry<String,Object> entry :
					stagewise.checkpoints.loadCheckpoint(node.lineage).entrySet()) {
					
					stagewise.setField(entry.getKey(), entry.getValue());
				}
				break;
				
			case RUN:
				// set import fields into runner
				for (String field : node.runner.getImportFields()) {
					node.runner.setField(field, stagewise.getField(field));
				}
				
				// run runner
				node.runner.run(stagewise, node.lineage);
				
				// retrieve export fields from runner
				for (String field : node.runner.getExportFields()) {
					stagewise.setField(field, node.runner.getField(field));
				}
				
				// serialize if marked
				if (node.runner.shouldCheckpoint()) {
					Map<String,Object> export = new HashMap<String,Object>();
					for (String field : node.runner.getExportFields()) {
						export.put(field, node.runner.getField(field));
					}
					stagewise.checkpoints.createCheckpoint(node.lineage, export);
				}
				break;
				
			case SKIP:
				// do nothing
				break;
				
			default:
				throw new RuntimeException("Unexpected action type.  This is a bug in RA - please report it to the authors.");
			}
			
			stagewise.stream.end("Stage");
		}
		
		stagewise.stream. end("StageWise");
	}
	
	/**
	 * Runs all stages in the queue.
	 */
	public void runAll() {
		if (running) {
			return;
		}
		
		synchronized(this) {
			running = true;
			while (!queue.isEmpty()) {
				runNext();
			}
			running = false;
		}
	}
}
