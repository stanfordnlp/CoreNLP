/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Represents the computation dependency relationship for a stage.
 * 
 * @author dramage
 */
class StageSchedule {
	
	//
	// static constructor
	//

	/**
	 * Instantiates a StageSchedule for the given runner in the given context.
	 * Each {@link StageRunner} is run only once.  Multiple {@link StageRunner}'s
	 * with equal {@link StageDescriptor}'s are considered repeats.  
	 */
	public static StageSchedule fromStageRunner(
			StageWise stagewise, StageRunner runner) {
		
		return fromStageRunner(stagewise, runner,
				new LinkedList<StageDescriptor>());
	}
	
	private static StageSchedule fromStageRunner(
			StageWise stagewise,
			StageRunner stage,
			// Map<StageDescriptor,StageRunner> shared,
			List<StageDescriptor> visited) {
		
		stage = stagewise.getSharedRunner(stage);
		
		visited = new LinkedList<StageDescriptor>(visited);
		visited.add(stage.getStageDescriptor());
		
		List<StageSchedule> prereqs = new LinkedList<StageSchedule>();
		
		for (StageRunner prereq : stage.getRequiredStages()) {
			StageDescriptor descriptor = prereq.getStageDescriptor();
			StageWise.assertNoCircularDependency(descriptor, visited);
			
			prereqs.add(fromStageRunner(stagewise, prereq, visited));
		}
		
		return new StageSchedule(stagewise, stage, prereqs);
	}
	
	
	//
	// class
	//
	
	/** Possible actions for each element of the schedule */
	public static enum StageAction {
		/** Run this stage if not already ran */
		RUN,
		
		/** Loads this stage from a checkpoint */
		LOAD,
		
		/** Skip this stage */
		SKIP
	}
	
	/** Surrounding context */
	private final StageWise stagewise;
	
	/** The stage runner we have a plan for */
	public final StageRunner runner;
	
	/** Lineage of that runner */
	public final StageLineage lineage;
	
	/** All pre-requisite stages' schedules */
	private final List<StageSchedule> prereqs;
	
	/** Default action is skip, but this might change by call to require() */
	private StageAction action = StageAction.SKIP;
	
	/** Use constructor method to instantiate */
	private StageSchedule(StageWise stagewise, StageRunner runner, List<StageSchedule> prereqs) {
		this.stagewise = stagewise;
		this.runner = runner;
		this.prereqs = prereqs;
		
		this.lineage = StageLineage.fromStageRunner(runner);
	}
	
	public StageAction getAction() {
		return action;
	}
	
	/**
	 * Marks this schedule element as required.  Recursively requires
	 * every sub-element.  Prunes those sub-elements that are before
	 * a LOAD but do not provide exports needed outside the LOAD.
	 */
	public void require() {
		if (runner.shouldCheckpoint() && stagewise.checkpoints.hasCheckpoint(lineage)) {
			action = StageAction.LOAD;
		} else {
			action = StageAction.RUN;
		}
		
		// recursively require
		for (StageSchedule s : prereqs) {
			s.require();
		}
		
		prune(runner.getImportFields());
	}
	
	/**
	 * For every stage element that is marked RUN but is behind
	 * a LOAD, marks it as SKIP if it does not provided a needed export.
	 */
	private void prune(Collection<String> fields) {
		switch (action) {
		case LOAD:
			// run every export and its dependents if we need the field
			for (StageSchedule prereq : prereqs) {
				for (StageSchedule sub : prereq.asList()) {
					if (intersection(fields, sub.runner.getExportFields()).size() > 0) {
						sub.require();
					} else {
						sub.action = StageAction.SKIP;
					}
				}
			}
			break;
			
		case RUN:
			// run: recurse with expanded requires set
			Set<String> required = new HashSet<String>(fields);
			required.addAll(runner.getImportFields());
			for (StageSchedule s : prereqs) {
				s.prune(required);
			}
			break;
			
		case SKIP:
			// do nothing
			break;
			
		default:
			throw new RuntimeException("Unexpected action type.  This is a bug.");
		}
	}
	
	/**
	 * Returns the topologically sorted list of the elements in this
	 * schedule.
	 */
	public List<StageSchedule> asList() {
		List<StageSchedule> list = new LinkedList<StageSchedule>();
		for (StageSchedule s : prereqs) {
			list.addAll(s.asList());
		}
		list.add(this);
		return list;
	}
	
	@Override
	public String toString() {
		return runner.getStageDescriptor().name+":"+action;
	}
	
	/** Returns the intersection of two collections */
	private static <T> Set<T> intersection(Collection<T> first, Collection<T> second) {
		Set<T> intersection = new HashSet<T>(first);
		intersection.retainAll(second);
		return intersection;
	}
}
