

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/*		 
 * fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2002-2007 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.bytes;
import it.unimi.dsi.fastutil.objects.*;
import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.bytes.*;
import it.unimi.dsi.fastutil.longs.*;
import java.util.Map;
import java.util.Iterator;
import java.util.Random;
/** A class providing static methods and objects that do useful things with
 * type-specific counters.
 */
public class Byte2LongCounters {
 /** Cannot instantiate */
 private Byte2LongCounters() {}
 /**
	 * Retains all non-zero entries in the counter.
	 */
 public static void retainNonZeros(Byte2LongCounter counter) {
  final Iterator<Byte2LongMap.Entry > entries
    = counter.byte2LongEntrySet().iterator();
  while (entries.hasNext()) {
   final Byte2LongMap.Entry entry = entries.next();
   if (entry.getLongValue() == 0l) {
    entries.remove();
   }
  }
 }
 /**
	 * Returns a random key from the given counter with probability in
	 * proportion to its total().
	 * @throws IllegalArgumentException if the counter contains no elements.
	 */
 public static byte sample(Byte2LongCounter counter, Random random) {
  if (counter.size() == 0) {
   throw new IllegalArgumentException("Cannot sample from empty counter");
  }
  final double threshold = random.nextDouble();
  final double total = (double)counter.total();
  double sum = 0;
  for (Byte2LongMap.Entry entry : counter.byte2LongEntrySet()) {
   sum += (double)(entry.getValue()) / total;
   if (sum > threshold) {
    return entry.getKey();
   }
  }
  return counter.keySet().iterator().next();
 }
}
