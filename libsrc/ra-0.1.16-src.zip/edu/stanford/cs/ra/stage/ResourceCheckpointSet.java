/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.stanford.cs.ra.RA;
import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;
import edu.stanford.cs.ra.workbook.ResourceSet;

/**
 * CheckpointSet implementation based on resources in a ResourceSet.
 * 
 * @author dramage
 */
public class ResourceCheckpointSet implements CheckpointSet {

	/** Max number of attempts to get a checkpoint */
	private final static int MAX_CHECKPOINT_ATTEMPTS = 9999;
	
	/** Workbook containing the goods */
	private final ResourceSet resources;
	
	/** Prefix directory for writing new checkpoints */
	private final String writeTo;
	
	/** Cache of read descriptors */
	private final Map<String,StageLineage> cache
		= new HashMap<String,StageLineage>();
	
	/**
	 * Initializes this resource checkpoint set to examine subfolders
	 * of resources for checkpoints and to write new checkpoints with
	 * the given prefix.
	 */
	public ResourceCheckpointSet(ResourceSet resources, String writeTo) {
		this.resources = resources;
		this.writeTo = writeTo;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean hasCheckpoint(StageLineage lineage) {
		return getCheckpointPath(lineage) != null;
	}
	
	/**
	 * Returns the name of a checkpoint with compatible lineage if one is
	 * found.  Otherwise returns null.  If more than one checkpoint with
	 * compatible lineage is found, provides no garuntees on which is
	 * returned. 
	 */
	private String getCheckpointPath(StageLineage lineage) {
		for (String folder : resources.listResources("")) {
			// consider folder as that holds checkpoints as well as all
			// its subfolders
			List<String> candidates = new LinkedList<String>();
			candidates.add(folder);
			candidates.addAll(Arrays.asList(resources.listResources(folder)));
			
			// check if it's a checkpoint
			for (String checkpoint : candidates) {
				if (resources.hasResource(checkpoint+"/lineage.obj")) {
					StageLineage readLineage = cache.get(checkpoint);
					if (readLineage == null) {
						InputStream input =
							resources.getInputStream(checkpoint+"/lineage.obj");
						readLineage = IOUtils.readObject(input);
						IOUtils.close(input);

						cache.put(checkpoint, readLineage);
					}

					if (lineage.equals(readLineage)) {
						return checkpoint;
					}
				}
			}
		}
		
		return null;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public Map<String,Object> loadCheckpoint(StageLineage lineage) {
		InputStream stream = resources.getInputStream(
				getCheckpointPath(lineage)+"/context.obj");
		Map<String,Object> map = IOUtils.readObject(stream);
		IOUtils.close(stream);
		
		return map;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public void createCheckpoint(StageLineage lineage, Map<String,Object> context) {
		
		//
		// find filename
		// 
		
		String path = null;
		{
			String shortname = lineage.getName();
			int lastDotIndex = lineage.getName().lastIndexOf('.')+1;
			if (lastDotIndex > 0 && lastDotIndex < shortname.length()) {
				shortname = shortname.substring(lastDotIndex);
			}
			
			int hash = lineage.getName().hashCode();
			int id = 0;
			do {
				path = String.format("%s/%s-%08X-%08X",
						writeTo,shortname,hash,
						(System.currentTimeMillis()/1000)+id);
				id++;

				if (id >= MAX_CHECKPOINT_ATTEMPTS) {
					throw new QuietIOException("Unable to allocate a new " +
							"checkpoint - time to clean the " +
							"checkpoints directory");
				}
			} while (resources.hasResource(path));
		}
		
		
		// write files
		
		try {
			IOUtils.writeFinalString(
					resources.getOutputStream(path+"/lineage.xml"),
					lineage.toString());

			IOUtils.writeFinalObject(
					resources.getOutputStream(path+"/lineage.obj"),
					lineage);

			IOUtils.writeFinalObject(
					resources.getOutputStream(path+"/context.obj"),
					context);
		} catch (QuietIOException e) {
			RA.stream.line("warning", "Unable to write to resource set "
					+ Stringify.toString(resources) + "\n"
					+ Stringify.toString(e));
		}
		
		// cache lineage
		cache.put(path, lineage);
	}
	
}
