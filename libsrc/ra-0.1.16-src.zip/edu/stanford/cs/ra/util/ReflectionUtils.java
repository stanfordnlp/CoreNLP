/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.util;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.WeakHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import edu.stanford.cs.ra.RA;

/**
 * Utilities for working with the reflection API.  Some code originally by
 * Originally by Vladimir Roubtsov.
 * 
 * http://www.javaworld.com/javaworld/javaqa/2003-07/02-qa-0725-classsrc2.html
 * 
 * @author dramage
 */
public class ReflectionUtils {

//	public static boolean isAssignable(Class<?> fromClass, Class<?> toClass) {
//		if (toClass.getTypeParameters().)
//		return toClass.isAssignableFrom(fromClass);
//	}
//	
//	public static boolean isAssignable(Class<?> fromClass, Type toType) {
//		if (toType instanceof Class<?>) {
//			return isAssignable(fromClass, (Class<?>)toType);
//		} else if (toType instanceof ParameterizedType) {
//			ParameterizedType toParam = (ParameterizedType) toType;
//			if (!isAssignable)
//			return isAssignable(fromClass, toParam.getRawType())
//				&& is
//		} else if (toType instanceof WildcardType) {
//			WildcardType toWild = (WildcardType) toType;
//			boolean ok = true;
//			for (Type upper : toWild.getUpperBounds()) {
//				ok &= isAssignable(upper, fromClass);
//			}
//			for (Type lower : toWild.getLowerBounds()) {
//				ok &= isAssignable(fromClass, lower);
//			}
//			return ok;
//		} else {
//			throw new UnsupportedOperationException("Unsupported toType type");
//		}
//	}
//	
//	public static boolean isAssignable(Type fromType, Type toType) {
//		if (fromType instanceof Class<?>) {
//			return isAssignable((Class<?>)fromType, toType);
//		} else {
//			throw new UnsupportedOperationException("Unsupported fromType type");
//		}
//	}
	
	/** Cache mapping classes to their class hierarchies */
	static Map<Class<?>,List<Class<?>>> hierarchyCache
		= new WeakHashMap<Class<?>,List<Class<?>>>();
	
	/** Cache class names to their class values */
	static Map<String, Class<?>> classCache
		= new WeakHashMap<String,Class<?>>();
	
	/**
	 * Returns a list of all classes currently loaded by the system ClassLoader.
	 * Throws ReflectionException if we are unable to access the (unsafe)
	 * inner fields needed to perform this task.
	 */
	public static List<Class<?>> getLoadedClasses() throws ReflectionException {
		return Arrays.asList(ClassScope.getLoadedClasses(ClassLoader.getSystemClassLoader()));
	}
	
	/**
	 * Returns a class corresponding to the given name with Class.forName
	 * if possible.  If no such as class is found, reads the classpath (all
	 * directories and jars), returning the first class found whose name
	 * ends with the given name.  A call to
	 * ReflectionUtils.getClassByName("ReflectionUtils") is therefore
	 * equivalent to Class.forName("edu.stanford.cs.ra.ReflectionUtils"). 
	 */
	public static Class<?> getClassByName(String name) throws ClassNotFoundException {
		if (classCache.containsKey(name)) {
			return classCache.get(name);
		}
		
		try {
			// try fully qualified name
			return Class.forName(name);
		} catch (ClassNotFoundException e) {
			// try standard java packages
			for (String prefix : new String[]{
					"java.io.",
					"java.lang.",
					"java.util.",
					"java.math.",
					"java.text.",
			}) {
				try {
					classCache.put(name, Class.forName(prefix+name));
					return classCache.get(name);
				} catch (ClassNotFoundException e2) {
					// keep trying
				}
			}

			// try classpath search
			for (String path : System.getProperty("java.class.path")
					.split(System.getProperty("path.separator"))) {

				for (String fullName : listClasses(new File(path))) {
					if (fullName.endsWith(name) && "$.".indexOf(
							fullName.charAt(fullName.length()-name.length()-1))
							>= 0) {

						// if the fullname ends with the given name at a
						// boundary symbol, return that class
						classCache.put(name, Class.forName(fullName));
						return classCache.get(name);
					}
				}
			}

			throw e;
		}
	}
	
	/**
	 * Returns a list of fully qualified class names of all classes in the
	 * given directory or jar.
	 */
	public static List<String> listClasses(File path) {
		List<String> classes = new LinkedList<String>();
		
		if (path.isDirectory()) {
			// find all class files in tree
			for (File file : PathUtils.glob(path, "**/*.class")) {
				String className = PathUtils.relativePath(file, path);
				className = className.replaceAll(File.separator, ".");
				className = className.substring(
						0, className.length()-".class".length());
				classes.add(className);
			}
		} else {
			// find all class files in jar
			JarFile jar;
			try {
				jar = new JarFile(path);
			} catch (IOException e) {
				// quiet move on
				return Collections.emptyList();
			}
			
			Enumeration<JarEntry> entries = jar.entries();
			while (entries.hasMoreElements()) {
				JarEntry entry = entries.nextElement();
				if (entry.getName().endsWith(".class")) {
					String className = entry.getName();
					className = className.replaceAll(File.separator, ".");
					className = className.substring(
							0, className.length() - ".class".length());
					classes.add(className);
				}
			}
		}

		return classes;
	}
	
	/**
	 * Returns the full set of fields and super-class fields on the
	 * given class. 
	 */
	public static List<Field> getAllFields(Class<?> type) {
		List<Field> fields = new LinkedList<Field>();
		for (Class<?> c : getClassHierarchy(type)) {
			fields.addAll(Arrays.asList(c.getDeclaredFields()));
		}
		return Collections.unmodifiableList(fields);
	}
	
	/**
	 * Returns the full set of methods and super-class methods on the
	 * given class. 
	 */
	public static List<Method> getAllMethods(Class<?> type) {
		List<Method> methods = new LinkedList<Method>();
		for (Class<?> c : getClassHierarchy(type)) {
			methods.addAll(Arrays.asList(c.getDeclaredMethods()));
		}
		return Collections.unmodifiableList(methods);
	}
	
	/**
	 * Returns the set of fields that have the given annotation.
	 */
	public static Set<Field> selectFieldsByAnnotation(Set<Field> fields, Annotation annotation) {
		Set<Field> keep = new HashSet<Field>();
		for (Field field : fields) {
			if (field.getAnnotation(annotation.getClass()) != null) {
				keep.add(field);
			}
		}
		return keep;
	}
	
	/**
	 * Returns the complete list of class, super-classes, and interfaces on
	 * the given class.  All classes come before all interfaces.  Subtypes
	 * come before supertypes.
	 */
	public static List<Class<?>> getClassHierarchy(Class<?> type) {
		List<Class<?>> hierarchy = hierarchyCache.get(type);
		if (hierarchy == null) {
			hierarchy = new LinkedList<Class<?>>();
			for (Class<?> superclass = type; superclass != null; superclass = superclass.getSuperclass()) {
				hierarchy.add(superclass);
			}
			for (Class<?> superintf : type.getInterfaces()) {
				hierarchy.addAll(getClassHierarchy(superintf));
			}
			hierarchyCache.put(type, Collections.unmodifiableList(hierarchy));
		}
		
		return hierarchy;
	}
	
	/**
	 * Returns a field by its name.  Should be canonical dotted notation.
	 * 
	 * @throws ReflectionException on encountering any error.
	 */
	public static Field getFieldByName(String name) throws ReflectionException {
		int index = name.lastIndexOf('.');
		String classname = name.substring(0, index);
		String fieldname = name.substring(index+1, name.length());
		try {
			Class<?> type = Class.forName(classname);
			for (Field field : type.getDeclaredFields()) {
				if (field.getName().equals(fieldname)) {
					return field;
				}
			}
		} catch (Exception e) {
			throw new ReflectionException("Class "+classname+" contains no field named "+fieldname, e);
		}
		throw new ReflectionException("Class "+classname+" contains no field named "+fieldname);
	}

	/** Package prefixes to ignore in the current stack trace */
	private static String[] ignoreTrace = new String[] { 
		"java.", "javax.", "sun.", RA.class.getPackage().getName(), "scala."
	};
	
	/**
	 * Returns the StackTraceElements corresponding to the stack, but
	 * with the top element as the highest user-land line on the stack; i.e.
	 * not in java.* javax.* sun.* and this package.
	 */
	public static StackTraceElement[] getTrace() {
		StackTraceElement[] trace = Thread.currentThread().getStackTrace();

		int top = 0;
		while (top < trace.length) {
			String name = trace[top].getClassName();
			
			boolean ignore = false;
			for (String prefix : ignoreTrace) {
				if (name.startsWith(prefix)) {
					ignore = true;
					break;
				}
			}
			
			if (ignore) {
				top++;
			} else {
				break;
			}
		}

		StackTraceElement[] rv = new StackTraceElement[trace.length - top];
		for (int i = 0; i < rv.length; i++) {
			rv[i] = trace[i + top];
		}
		
		return rv;
	}
	
	/**
	 * Returns the first element on the current stack trace that is in
	 * user-land; i.e. not in java.* javax.* sun.* and this package.
	 */
	public static StackTraceElement getTraceTop() {
		for (StackTraceElement trace : Thread.currentThread().getStackTrace()) {
			String name = trace.getClassName();
			boolean ignore = false;
			for (String prefix : ignoreTrace) {
				if (name.startsWith(prefix)) {
					ignore = true;
					break;
				}
			}
			if (!ignore) {
				return trace;
			}
		}
		return null;
	}
	
	/**
	 * Returns the value of the given field evaluated on the given object.
	 * Ignores accessibility.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getFieldValue(Object instance, Field field) throws ReflectionException {
		instance = resolveObjectReference(field.getDeclaringClass(), instance);
		if ((instance == null) && !Modifier.isStatic(field.getModifiers())) {
			throw new NullPointerException("Null instance given for non-static field "+field);
		}
		
		Object value;
		try {
			synchronized (field) {
				boolean accessible = field.isAccessible();
				field.setAccessible(true);
				value = field.get(instance);
				field.setAccessible(accessible);
			}
		} catch (Exception e) {
			throw new ReflectionException("Unable to get value for "+field, e);
		}
		return (T)value;
	}
	
	
	/**
	 * Returns the value of the given field evaluated on the given object.
	 * Ignores accessibility.
	 */
	public static void setFieldValue(Object instance, Field field, Object value) throws ReflectionException {
		instance = resolveObjectReference(field.getDeclaringClass(), instance);
		if ((instance == null) && !Modifier.isStatic(field.getModifiers())) {
			throw new NullPointerException("Null instance given for non-static field "+field);
		}
		
		try {
			synchronized (field) {
				boolean accessible = field.isAccessible();
				field.setAccessible(true);
				field.set(instance, value);
				field.setAccessible(accessible);
			}
		} catch (Exception e) {
			throw new ReflectionException("Unable to set value for "+field, e);
		}
	}
	
	/**
	 * Resolves references to Scala objects by reading their
	 * singleton value field.  If instance != null, returns
	 * instance.  Otherwise returns either null (for truly
	 * static classes) or the global singleton instance
	 * (for scala.ScalaObject instances).  Works with Scala
	 * 2.x.
	 */
	public static Object resolveObjectReference(Class<?> type, Object instance) {
		if (instance != null) {
			return instance;
		}
		
		boolean isScalaObject = false;
		for (Class<?> superI : getClassHierarchy(type)) {
			if (superI.getName().equals("scala.ScalaObject")) {
				isScalaObject = true;
				break;
			}
		}
		
		if (isScalaObject) {
			try {
				return type.getField("MODULE$").get(null);
			} catch (Exception e) {
				throw new ReflectionException("Unexpected ScalaObject structure (assuming Scala 2.x binary structure)", e);
			}
		}
		
		return instance;
	}
	
	/** Quiet exception thrown when doing crazy reflection shtuff. */
	public static class ReflectionException extends RuntimeException {
		public ReflectionException(String message, Throwable cause) {
			super(message, cause);
		}
		
		public ReflectionException(String message) {
			super(message);
		}

		private static final long serialVersionUID = 1L;
	}
	
	/**
	 * For retrieving list of classes currently loaded by a class loader.
	 * Originally by Vladimir Roubtsov.
	 * 
	 * http://www.javaworld.com/javaworld/javaqa/2003-07/02-qa-0725-classsrc2.html
	 */
	private static abstract class ClassScope {
		@SuppressWarnings("unchecked")
		public static Class<?>[] getLoadedClasses(final ClassLoader loader) throws ReflectionException {
			if (loader == null)
				throw new ReflectionException("null input: loader");
			if (CLASSES_VECTOR_FIELD == null)
				throw new ReflectionException(
						"ClassScope::getLoadedClasses() cannot"
								+ " be used in this JRE", CVF_FAILURE);

			try {
				final Vector classes = (Vector)
					CLASSES_VECTOR_FIELD.get(loader);
				if (classes == null)
					return EMPTY_CLASS_ARRAY;

				final Class<?>[] result;

				// Note: Vector is synchronized in Java 2, which helps us make
				// the following into a safe critical section:

				synchronized (classes) {
					result = new Class[classes.size()];
					classes.toArray(result);
				}

				return result;
			}
			// This should not happen if <clinit> was successful:
			catch (IllegalAccessException e) {
				e.printStackTrace(System.out);

				return EMPTY_CLASS_ARRAY;
			}
		}

		private static final Field CLASSES_VECTOR_FIELD; // Set in <clinit> [can be null]

		private static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
		private static final Throwable CVF_FAILURE; // Set in <clinit>

		static {
			Throwable failure = null;

			Field tempf = null;
			try {
				// This can fail if this is not a Sun-compatible JVM
				// or if the security is too tight:

				tempf = ClassLoader.class.getDeclaredField("classes");
				if (tempf.getType() != Vector.class)
					throw new RuntimeException("not of type java.util.Vector: "
							+ tempf.getType().getName());
				tempf.setAccessible(true);
			} catch (Throwable t) {
				failure = t;
			}
			CLASSES_VECTOR_FIELD = tempf;
			CVF_FAILURE = failure;
		}
	} // End of class
}
