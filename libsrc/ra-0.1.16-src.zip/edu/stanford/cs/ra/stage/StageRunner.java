/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.Collection;

import edu.stanford.cs.ra.arguments.ArgumentBox;

/**
 * A single stage of computation for running with StageWise.  StageWise
 * assumes a particular life-cycle for each StageRunner:
 * 
 * <ol>
 * <li> StageRunner is instantiated, e.g. from a Stage instance and an
 *   ArgumentPopulator that can provide argument values.</li>
 * <li> A StageLineage instance is created and stored in StageWise
 *      to describe the stage.</li>
 * <li> It is inserted into a StageSchedule to be run (or loaded from checkpoint).</li>
 * <li> All prerequisite stages are run or loaded.</li>
 * <li> If no compatible checkpoint is found, all ImportField values are set with
 *   setField().  Then run is called.  Then all ExportField values are retrieved
 *   and stored with getField().</li>
 * <li> If shouldCheckpoin() is true, writes a checkpoint consisting of
 *   the StageDescriptor and all fields returned by getExportFields.</li>
 * </ol>
 * 
 * Note that the StageRunner will never be run more than once.
 * 
 * @author dramage
 */
public interface StageRunner {
	
	/**
	 * Returns the description of this StageRunner.
	 */
	public StageDescriptor getStageDescriptor();
	
//	/**
//	 * Gets a unique version code for the class file.  Implementations are
//	 * encouraged to use ObjectStreamClass.lookup(class).getSerialVersionUID()
//	 */
//	public long getVersionCode();
	
	/**
	 * Returns an ArgumentBox that describes the arguments to this stage
	 */
	public ArgumentBox getArgumentBox();
	
	/**
	 * Returns all context fields exported by the stage.
	 */
	public Collection<String> getExportFields();

	/**
	 * Returns all context fields that are read (and not modified) by the stage.
	 */
	public Collection<String> getImportFields();
	
	/**
	 * Called to get the value of an export or import field.
	 */
	public Object getField(String name);
	
	/**
	 * Called to set the value of an export or import field.
	 */
	public void setField(String name, Object value);
	
	/**
	 * Returns all stages that are pre-requisites of the current stage.
	 */
	public Collection<StageRunner> getRequiredStages();
	
	/**
	 * Returns true if {@link StageWise} should look for a checkpoint before
	 * running and/or create checkpoint after running.
	 */
	public boolean shouldCheckpoint();
	
	/**
	 * Called to actually run the given stage.
	 */
	public void run(StageWise context, StageLineage lineage);
}
