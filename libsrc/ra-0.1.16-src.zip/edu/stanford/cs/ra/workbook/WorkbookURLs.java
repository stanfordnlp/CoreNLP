package edu.stanford.cs.ra.workbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;

import edu.stanford.cs.ra.RA;

/**
 * Experimental support for URL's with the "workbook://" prefix.
 * 
 * @author dramage
 */
class WorkbookURLs {
	
	private static boolean registered = false;
	
	/** Register stream handlers */
	public static void init() {
		if (!registered) {
			URL.setURLStreamHandlerFactory(new WorkbookStreamHandlerFactor());
			registered = true;
		}
	}
	
	private static class WorkbookStreamHandlerFactor implements URLStreamHandlerFactory {
		public URLStreamHandler createURLStreamHandler(String protocol) {
			if (!protocol.equals("workbook")) {
				throw new IllegalArgumentException("Invalid protocol: "+protocol);
			}
			return new WorkbookStreamHandler();
		};
	}
	
	private static class WorkbookStreamHandler extends URLStreamHandler {
		@Override
		protected URLConnection openConnection(URL url) throws IOException {
			return new URLConnection(url) {
				@Override
				public void connect() throws IOException {
					// do nothing
				}

				@Override
				public InputStream getInputStream() throws IOException {
					return RA.getWorkbook().getInputStream(url.getHost()+"/"+url.getPath());
				}

				@Override
				public OutputStream getOutputStream() throws IOException {
					return RA.getWorkbook().getOutputStream(url.getHost()+"/"+url.getPath());
				}
			};
		}
	}
}