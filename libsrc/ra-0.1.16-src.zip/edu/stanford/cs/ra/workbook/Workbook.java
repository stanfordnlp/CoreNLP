package edu.stanford.cs.ra.workbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import edu.stanford.cs.ra.RA;
import edu.stanford.cs.ra.stage.CheckpointSet;
import edu.stanford.cs.ra.stage.StageLineage;
import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * A Workbook consists of a run resource set (where all written resources
 * go) that is generally a subfolder of base resource set (where this run
 * folder and other folders live), as well as general resource search path
 * in a third resource path set.
 * 
 * @author dramage
 */
public class Workbook implements ResourceSet, CheckpointSet {
	
	private static final long serialVersionUID = 1L;

	/** The resource set for generating new run folders */
	private final ResourceSet runs;
	
	/** A pooled set of resources for research search path */
	private final ResourceSet resources;
	
	/** Name of the run path relative to the runs root for this invocation */
	private final String thisRun;
	
	/** Sub-folders of base */
	private transient List<String> baseCache = null;
	
	/** Cache of read descriptors */
	private transient final Map<String,StageLineage> lineageCache
		= new HashMap<String,StageLineage>();

	public Workbook(String thisRun, ResourceSet runs, ResourceSet resources) {
		if (thisRun != null && !thisRun.endsWith("/")) {
			thisRun += "/";
		}
		
		this.thisRun = thisRun;
		this.runs = runs;
		this.resources = resources;
	}
	
	/**
	 * Returns true if this workbook is writable.
	 */
	public boolean canWrite() {
		return thisRun != null && runs != null;
	}
	
	/**
	 * Returns true if the current run folder, the workbook base folder,
	 * or the resource search path contains the given resource.
	 */
	public boolean hasResource(String path) {
		if (thisRun != null && runs != null && runs.hasResource(thisRun+path)) {
			return true;
		} else if (runs != null && runs.hasResource(path)) {
			return true;
		} else if (resources != null && resources.hasResource(path)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Returns an InputStream for the given resource path by first
	 * searching the current run folder, then the workbook base folder,
	 * then the resource search path.
	 */
	public InputStream getInputStream(String path) throws QuietIOException {
		if (thisRun != null && runs != null && runs.hasResource(thisRun+path)) {
			return runs.getInputStream(thisRun+path);
		} else if (runs != null && runs.hasResource(path)) {
			return runs.getInputStream(path);
		} else if (resources != null) {
			return resources.getInputStream(path);
		} else {
			throw new QuietIOException(new FileNotFoundException(
					"No workbook search path contains "+path));
		}
	}
	
	/**
	 * Returns an absolute URI that will give you the full path to the given
	 * input stream.  Throws QuietIOException if hasResource(path) is false.
	 */
	public URI getInputURI(String path) throws QuietIOException {
		if (thisRun != null && runs != null && runs.hasResource(thisRun+path)) {
			return runs.getInputURI(thisRun+path);
		} else if (runs != null && runs.hasResource(path)) {
			return runs.getInputURI(path);
		} else if (resources != null) {
			return resources.getInputURI(path);
		} else {
			throw new QuietIOException(new FileNotFoundException(
					"No workbook search path contains "+path));
		}
	}
	
	/**
	 * Returns a File that will give you the full path that would be
	 * read by getInputStream.  Throws QuietIOException if hasResource(path)
	 * if false.
	 */
	public File getInputFile(String path) throws QuietIOException {
		return new File(getInputURI(path));
	}

	/**
	 * Returns an OutputStream for writing into this workbook's current
	 * run folder.  Throws QuietIOException if the workbook has no
	 * run folder.
	 */
	public OutputStream getOutputStream(String path) throws QuietIOException {
		return runs.getOutputStream(getOutputPath(path));
	}

	/**
	 * Returns the path relative to the workbook runs ResourceSet for where 
	 * the given path will be written in a call to getOutputStream.
	 */
	public String getOutputPath(String path) throws QuietIOException {
		if (thisRun == null || runs == null) {
			throw new QuietIOException(new FileNotFoundException(
					"No writable workbook run folder found"));
		}
		return thisRun+path;
	}
	
	/**
	 * Returns an absolute URI that will give you the full path to the given
	 * output stream.  May throw QuietIOException if the workbook has
	 * no run folder or if it is not backed by files.
	 */
	public URI getOutputURI(String path) {
		return runs.getOutputURI(getOutputPath(path));
	}
	
	/**
	 * Returns a File that will give you the full path to the given
	 * output stream.  May throw QuietIOException if the workbook has
	 * no run folder or if it is not backed by files.
	 */
	public File getOutputFile(String path) {
		return new File(getOutputURI(path));
	}
	
	/**
	 * Lists all resources in the current run directory, workbook directory,
	 * and resource search path.
	 */
	public String[] listResources() {
		return listResources("");
	}
	
	/**
	 * Lists all resources in the current run directory, workbook directory,
	 * and resource search path matching the given path string prefix.
	 */
	public String[] listResources(String path) {
		Collection<String> r = new TreeSet<String>();
		if (runs != null) {
			r.addAll(Arrays.asList(runs.listResources(thisRun+path)));
			r.addAll(Arrays.asList(runs.listResources(path)));
		}
		if (resources != null) {
			r.addAll(Arrays.asList(resources.listResources(path)));
		}
		return r.toArray(new String[0]);
	}

	/**
	 * Returns a reverse-sorted view of the folders under the base, i.e.
	 * ties are broken by recency with the default naming conventions.
	 */
	private Collection<String> getRunFolders() {
		if (baseCache == null) {
			baseCache = new ArrayList<String>();
			if (runs != null) {
				for (String sub : runs.listResources()) {
					if (sub.endsWith("/") && !sub.equals(thisRun)) {
						baseCache.add(sub);
					}
				}
			}
			Collections.sort(baseCache);
			Collections.reverse(baseCache);
		}
		return baseCache;
	}
	
	/** {@inheritDoc} */
	public boolean hasCheckpoint(StageLineage lineage) {
		return getCheckpointPath(lineage) != null;
	}
	
	/**
	 * Returns the name of a checkpoint with compatible lineage if one is
	 * found.  Otherwise returns null.  If more than one checkpoint with
	 * compatible lineage is found, returns the one in the folder whose
	 * name comes last lexicographically.
	 */
	private String getCheckpointPath(StageLineage lineage) {
		for (String folder : getRunFolders()) {
			for (String subfolder : runs.listResources(folder)) {
				if (!subfolder.endsWith("/")) {
					continue;
				}
				if (runs.hasResource(subfolder+"lineage.obj")) {
					// it's a checkpoint
					StageLineage readLineage = lineageCache.get(subfolder);
					if (readLineage == null) {
						InputStream input =
							runs.getInputStream(subfolder+"lineage.obj");
						readLineage = IOUtils.readObject(input);
						IOUtils.close(input);

						lineageCache.put(subfolder, readLineage);
					}

					if (lineage.equals(readLineage)) {
						return subfolder;
					}
				}
			}
		}
		
		return null;
	}
	
	/** {@inheritDoc} */
	public Map<String,Object> loadCheckpoint(StageLineage lineage) {
		if (runs == null) {
			throw new QuietIOException(new FileNotFoundException("No workbook specified"));
		}
		InputStream stream = runs.getInputStream(
				getCheckpointPath(lineage)+"context.obj");
		Map<String,Object> map = IOUtils.readObject(stream);
		IOUtils.close(stream);
		
		return map;
	}
	
	/** {@inheritDoc} */
	public void createCheckpoint(StageLineage lineage, Map<String,Object> context) {
		if (!canWrite()) {
			return;
		}
		
		//
		// find filename
		// 
		
		String path = null;
		{
			String shortname = lineage.getName();
			int lastDotIndex = lineage.getName().lastIndexOf('.')+1;
			if (lastDotIndex > 0 && lastDotIndex < shortname.length()) {
				shortname = shortname.substring(lastDotIndex);
			}
			
			int hash = lineage.getName().hashCode();
			path = String.format("%s-%08X-%08X",
					shortname,hash,
					(System.currentTimeMillis()/1000));

			if (runs.hasResource(thisRun+path)) {
				throw new QuietIOException("Unable to allocate a new " +
						"checkpoint for "+shortname+" in the run folder " +
						thisRun);
			}
		}
		
		
		// write files
		
		try {
			IOUtils.writeFinalString(
					runs.getOutputStream(thisRun+path+"/lineage.xml"),
					lineage.toString());

			IOUtils.writeFinalObject(
					runs.getOutputStream(thisRun+path+"/lineage.obj"),
					lineage);

			IOUtils.writeFinalObject(
					runs.getOutputStream(thisRun+path+"/context.obj"),
					context);
		} catch (QuietIOException e) {
			RA.stream.line("warning", "Unable to write to resource set "
					+ Stringify.toString(runs) + " " + thisRun + "\n"
					+ Stringify.toString(e));
		}
		
		// cache lineage
		lineageCache.put(path, lineage);
	}
	
	
}
