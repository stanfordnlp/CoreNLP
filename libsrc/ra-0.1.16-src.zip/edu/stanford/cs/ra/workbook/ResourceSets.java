/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.LinkedList;
import java.util.List;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.stringify.Stringify.StaticFromString;
import edu.stanford.cs.ra.stringify.Stringify.StringifyException;
import edu.stanford.cs.ra.util.PathUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * Implementations and convenience functions for ResourceSet.
 * 
 * @author dramage
 */
public class ResourceSets {
	
	/**
	 * Returns a ResourceSet instance appropriate for reading from
	 * the given directory (and soon, jar or zip file).
	 */
	public static ResourceSet forPath(File file) {
		if (file.exists()) {
			if (file.isDirectory()) {
				return new FileResourceSet(file);
			} else {
				throw new StringifyException("Resource path "+file+" must be to an " +
				"existing directory");
			}
		}

		// doesn't exist - ignore silently
		return null;
	}
	
	/**
	 * Returns a PooledResourceSet based on the contents of the given
	 * resource path.  Each element of the path (separated by
	 * File.pathSeparator) can be a directory a shell-style pattern that
	 * matches directories.
	 */
	@StaticFromString
	public static ResourceSet forPath(String pathString) {
		if (pathString == null || pathString.length() == 0) {
			return null;
		}
		
		List<ResourceSet> resources = new LinkedList<ResourceSet>();

		for (String segment : Stringify.escapedSplit(String.class, pathString, File.pathSeparatorChar)) {
			if (!segment.equals("")) {
				if (new File(segment).isDirectory()) {
					resources.add(ResourceSets.forPath(new File(segment)));
				} else {
					for (File file : PathUtils.glob(new File(""), segment)) {
						if (file.exists() && file.isDirectory()) {
							resources.add(ResourceSets.forPath(file));
						}
					}
				}
			}
		}

		return new PooledResourceSet(resources);
	}
	
	/**
	 * An empty resource set the provides no resources or streams.
	 */
	public static ResourceSet emptyResourceSet() {
		return new ResourceSet() {
			private static final long serialVersionUID = 1L;
			private final QuietIOException exception
				= new QuietIOException(new FileNotFoundException("No resources defined"));

			public InputStream getInputStream(String path)
					throws QuietIOException {
				throw exception;
			}

			public OutputStream getOutputStream(String path)
					throws QuietIOException {
				throw exception;
			}

			public boolean hasResource(String path) {
				return false;
			}

			public String[] listResources() {
				return new String[0];
			}
			
			public String[] listResources(String path) {
				return new String[0];
			}

			public URI getInputURI(String path) {
				throw exception;
			}

			public URI getOutputURI(String path) {
				throw exception;
			}
			
		};
	}
}
