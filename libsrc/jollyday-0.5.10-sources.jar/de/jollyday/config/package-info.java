//
// Diese Datei wurde mit der JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.1 generiert 
// Siehe <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Änderungen an dieser Datei gehen bei einer Neukompilierung des Quellschemas verloren. 
// Generiert: 2019.12.18 um 09:41:15 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/Holiday", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.jollyday.config;
