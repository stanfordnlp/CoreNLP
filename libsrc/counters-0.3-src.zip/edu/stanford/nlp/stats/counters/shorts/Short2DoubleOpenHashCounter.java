

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/* 
 * Counters: Fast & compact NLP data structures for Java
 * Based on fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2007 Daniel Ramage
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.shorts;
import it.unimi.dsi.fastutil.shorts.*;
import java.util.Map;
import java.util.NoSuchElementException;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.AbstractObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
/**
 * A type-specific counter; provides a {@link Map} from key to numeric values that can be incremented and decremented, along with a running total.
 *
 * @see Map
 * @author dramage
 */
/**
 * A Counter implementation backed by an OpenHashMap.
 * 
 * TODO: worry about readObject
 */
public class Short2DoubleOpenHashCounter extends Short2DoubleOpenHashMap implements Short2DoubleCounter {
 public Short2DoubleOpenHashCounter() {
  super();
 }
 /** Constructor for given expected number of entries */
 public Short2DoubleOpenHashCounter(int n) {
  super(n);
 }
 /** Constructor for given expected number of entries, load factor */
 public Short2DoubleOpenHashCounter(int n, float f) {
  super(n,f);
 }
 /** Copy constructor */
 public Short2DoubleOpenHashCounter(Short2DoubleCounter counter) {
  super(counter);
  this.total = counter.total();
 }
 /** Copy constructor */
 public Short2DoubleOpenHashCounter(Map<Short,? extends Number> map) {
  super(map.size());
  for (Map.Entry<Short,? extends Number> entry : map.entrySet()) {
   put((short)entry.getKey(), entry.getValue().doubleValue());
  }
 }
 protected double total;
 @Override
 public double put(final short k, final double v) {
  final double rv = super.put(k,v);
  total = total - rv + v;
  return rv;
 }
 @Override
 public Double put(final Short ok, final Double ov) {
  final Double rv = super.put(ok,ov);
  total = total - rv + ov;
  return rv;
 }
 @Override
 public void clear() {
  super.clear();
  total = 0;
 }
 /** The entry class for a hash map does not record key and value, but
	 * rather the position in the hash table of the corresponding entry. This
	 * is necessary so that calls to {@link java.util.Map.Entry#setValue(Object)} are reflected in
	 * the map */
 private final class MapEntry implements Short2DoubleMap.Entry , Map.Entry<Short, Double> {
  private int index;
  MapEntry( final int index ) {
   this.index = index;
  }
  public Short getKey() {
   return (Short.valueOf(key[ index ]));
  }
  public short getShortKey() {
      return key[ index ];
  }
  public Double getValue() {
   return (Double.valueOf(value[ index ]));
  }

  public double getDoubleValue() {
   return value[ index ];
  }


  public double setValue( final double v ) {
   final double oldValue = value[ index ];
   value[ index ] = v;
   total = total - oldValue + v;
   return oldValue;
  }



  public Double setValue( final Double v ) {
   return (Double.valueOf(setValue( ((v).doubleValue()) )));
  }



  @SuppressWarnings("unchecked")
  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<Short, Double> e = (Map.Entry<Short, Double>)o;

   return ( (key[ index ]) == (((e.getKey()).shortValue())) ) && ( (value[ index ]) == (((e.getValue()).doubleValue())) );
  }

  public int hashCode() {
   return (key[ index ]) ^ it.unimi.dsi.fastutil.HashCommon.double2int(value[ index ]);
  }


  public String toString() {
   return key[ index ] + "->" + value[ index ];
  }
 }

 /** An iterator over a hash map. */

 private class MapIterator {
  /** The index of the next entry to be returned. */
  int pos = 0;
  /** The index of the last entry that has been returned. */
  int last = -1;
  /** A downward counter measuring how many entries have been returned. */
  int c = count;

  {
   final byte state[] = Short2DoubleOpenHashCounter.this.state;
   final int n = state.length;

   if ( c != 0 ) while( pos < n && state[ pos ] != OCCUPIED ) pos++;
  }

  public boolean hasNext() {
   return c != 0 && pos < Short2DoubleOpenHashCounter.this.state.length;
  }

  public int nextEntry() {
   final byte state[] = Short2DoubleOpenHashCounter.this.state;
   final int n = state.length;

   if ( ! hasNext() ) throw new NoSuchElementException();
   last = pos;
   if ( --c != 0 ) do pos++; while( pos < n && state[ pos ] != OCCUPIED );

   return last;
  }

  @SuppressWarnings("unchecked")
  public void remove() {
   if (last == -1) throw new IllegalStateException();
   if (state[last] == OCCUPIED) {
    total -= value[last];
   }

   state[last] = REMOVED;







   count--;
  }

  public int skip( final int n ) {
   int i = n;
   while( i-- != 0 && hasNext() ) nextEntry();
   return n - i - 1;
  }
 }


 private class EntryIterator extends MapIterator implements ObjectIterator<Short2DoubleMap.Entry > {
  public Short2DoubleMap.Entry next() {
   return new MapEntry( nextEntry() );
  }
 }

 public static class BasicEntry implements Short2DoubleMap.Entry {
  protected short key;
  protected double value;

  public BasicEntry( final Short key, final Double value ) {
   this.key = ((key).shortValue());
   this.value = ((value).doubleValue());
  }



  public BasicEntry( final short key, final double value ) {
   this.key = key;
   this.value = value;
  }



  public Short getKey() {
   return (Short.valueOf(key));
  }


  public short getShortKey() {
   return key;
  }


  public Double getValue() {
   return (Double.valueOf(value));
  }


  public double getDoubleValue() {
   return value;
  }


  public double setValue( final double value ) {
   throw new UnsupportedOperationException();
  }



  public Double setValue( final Double value ) {
   return Double.valueOf(setValue(value.doubleValue()));
  }



  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<?,?> e = (Map.Entry<?,?>)o;

   return ( (key) == (((((Short)(e.getKey())).shortValue()))) ) && ( (value) == (((((Double)(e.getValue())).doubleValue()))) );
  }

  public int hashCode() {
   return (key) ^ it.unimi.dsi.fastutil.HashCommon.double2int(value);
  }


  public String toString() {
   return key + "->" + value;
  }
 }


 private class FastEntryIterator extends MapIterator implements ObjectIterator<Short2DoubleMap.Entry > {
  final BasicEntry entry = new BasicEntry ( ((short)0), (0) );
  public BasicEntry next() {
   final int e = nextEntry();
   entry.key = key[ e ];
   entry.value = value[ e ];
   return entry;
  }
 }

 @Override
 public Double remove( final Object ok ) {
  final Double rv = super.remove(ok);
  if (rv != null) {
   total -= rv;
  }
  return rv;
 }

 @Override
 public double remove(final short k) {
  final int oldcount = count;
  final double rv = super.remove(k);
  if (oldcount < count) {
   total -= rv;
  }
  return rv;
 }

 @SuppressWarnings("unchecked")
 @Override
 public Object clone() {
  Short2DoubleOpenHashCounter c = (Short2DoubleOpenHashCounter)super.clone();
  c.total = this.total;
  return c;
 }


 private final class MapEntrySet extends AbstractObjectSet<Short2DoubleMap.Entry > implements Short2DoubleMap.FastEntrySet {

  public ObjectIterator<Short2DoubleMap.Entry > iterator() {
   return new EntryIterator();
  }

  public ObjectIterator<Short2DoubleMap.Entry > fastIterator() {
   return new FastEntryIterator();
  }

  @SuppressWarnings("unchecked")
  public boolean contains( final Object o ) {
   if (!(o instanceof Short2DoubleMap.Entry)) return false;
   final Short2DoubleMap.Entry e = (Short2DoubleMap.Entry )o;
   final int i = findKey( ((e.getKey()).shortValue()) );
   return i >= 0 && ( (value[ i ]) == (((e.getValue()).doubleValue())) );
  }

  @SuppressWarnings("unchecked")
  public boolean remove( final Object o ) {
   if (!(o instanceof Short2DoubleMap.Entry)) return false;
   final Short2DoubleMap.Entry e = (Short2DoubleMap.Entry )o;
   final int i = findKey( ((e.getKey()).shortValue()) );
   if ( i >= 0 ) Short2DoubleOpenHashCounter.this.remove( e.getKey() );
   return i >= 0;
  }

  public int size() {
   return count;
  }

  public void clear() {
   Short2DoubleOpenHashCounter.this.clear();
  }

 }

 public Short2DoubleMap.FastEntrySet short2DoubleEntrySet() {
  if ( entries == null ) entries = new MapEntrySet();
  return entries;
 }

 /**
	 * Increments the value associated with the given key by <code>+adjustAmount</code>,
 	 * returning the value in the map before the increment.  This method is faster than
 	 * incrementing a value in the map with two calls - once to get and once to put -
	 * because it caches the correct insertion point into the hashmap.
	 */
 protected double adjust(final short k, final double adjustAmount) {
  final int i = findInsertionPoint( k );

  total += adjustAmount;

  if (i < 0) {
   final double oldValue = value[-i-1];
   value[-i-1] += adjustAmount;
   return oldValue;
  }

  if ( state[i] == FREE ) free--;
  state[i] = OCCUPIED;
  key[i] = k;
  value[i] = adjustAmount;
  if ( ++count >= maxFill ) {
   int newP = Math.min( p + growthFactor, PRIMES.length - 1 );
   // Just to be sure that size changes when p is very small.
   while( PRIMES[ newP ] == PRIMES[ p ] ) newP++;
   rehash( newP ); // Table too filled, let's rehash
  }
  if ( free == 0 ) rehash( p );
  return defRetValue;
 }
 /** {@inheritDoc} */
 public void incrementAll( Short2DoubleMap counter ) {
  for (Short2DoubleMap.Entry entry : counter.short2DoubleEntrySet()) {
   this.increment(entry.getShortKey(), entry.getDoubleValue());
  }
 }
 /** {@inheritDoc} */
 public double increment( short key, double amount ) {
  return adjust(key, amount) + amount;
 }
 /** {@inheritDoc} */
 public double increment( short key ) {
  return adjust(key, 1.0) + 1.0;
 }
 /** {@inheritDoc} */
 public double decrement( short key, double amount ) {
  return adjust(key, -amount) - amount;
 }
 /** {@inheritDoc} */
 public double decrement( short key ) {
  return adjust(key, -1.0) - 1.0;
 }
 /** {@inheritDoc} */
 public double total() {
  return total;
 }
}
