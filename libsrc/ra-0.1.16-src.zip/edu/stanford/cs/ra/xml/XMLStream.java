/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.util.List;

/**
 * Builds a String from convenient XML fragments.
 * 
 * @author dramage
 */
public interface XMLStream {
	/**
	 * Single-line XML fragment.  Body is inserted as a direct
	 * text child (and all non-XML elements are escaped).  The
	 * given list of arguments must be even and consists of key,value
	 * pairs in order, e.g:
	 * 
	 * <pre>
	 * line("tag", "body text");
	 * &lt;tag&gt;body text&lt;/tag&gt;
	 * 
	 * line("tag", "", "key", "value")
	 * &lt;tag key="value" /&gt;
	 * 
	 * line("tag", "body text", "a", "1", "b", "2")
	 * &lt;tag key="value" a="1" b="2"&gt;body text&lt;/tag&gt;
	 * </pre>
	 * 
	 * @param tag Tag of XML fragment.
	 * @param body Text to be escaped and inserted as the body of the line.
	 *   Whitespace may be reformatted on multi-line bodies (i.e. bodies
	 *   containing \n).  If body is an instance of {@link EscapedXML}, then
	 *   the contents are inserted directly without escaping.
	 * @param args List of key,value pairs as arguments to the fragment.
	 *   Should be even length.  The key,value pair is output if and only
	 *   if value is non-null.
	 *   
	 * @throws XMLException if the length of the given args is
	 * non-even.
	 * 
	 * @return this, for convenience
	 */
	public XMLStream line(String tag, Object body, Object ... args);

	/**
	 * Opens XML fragment with the given tag and arguments.
	 * 
	 * <pre>
	 * e.g. begin("result","ntests","5","color","red")
	 * will eventually output
	 *   &lt;result ntests="5" color="red"&gt;
	 *     ...
	 *   &lt;/result&gt;
	 * when end("result") is called.
	 * </pre>
	 * 
	 * @param tag Tag of XML fragment.
	 * @param args List of key,value pairs as arguments to the fragment.
	 *   Should be even length.  The key,value pair is output if and only
	 *   if value is non-null.
	 *   
	 * @throws XMLException if the length of the given args is
	 * non-even.
	 * 
	 * @return this, for convenience
	 */
	public XMLStream begin(String tag, Object ... args);
	
	/**
	 * Closes an XML fragment.
	 * 
	 * @param tag The tag to close - must match the expected tag
	 *   (most recent tag sent to begin that has not been closed).
	 *   
	 * @throws XMLException if attempting to end a tag other than
	 *   the most recent open tag that has not yet been closed.
	 * 
	 * @return this, for convenience
	 */
	public XMLStream end(String tag);

	/**
	 * Inserts a pre-escaped XML fragrment.
	 */
	public XMLStream xml(EscapedXML xml);
	
	/**
	 * Closes any open tags and marks the stream as closed.  Further
	 * method calls have no effect.
	 */
	public void close();
	
	/**
	 * Returns an immutable view of the current tag stack.
	 */
	public List<String> getTagStack();
}
