/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * A ResourceSet backed by multiple underlying ResourceSets.
 * 
 * @author dramage
 */
public class PooledResourceSet implements ResourceSet {
	private static final long serialVersionUID = 1L;
	
	/** Underlying resources */
	private final List<ResourceSet> resources;

	/**
	 * Initializes this pooled resource set to search all of the
	 * underlying ResourceSets when looking to open a path.  The first
	 * resource in the set is used for writing new resources.
	 */
	public PooledResourceSet(List<ResourceSet> resources) {
		this.resources = new LinkedList<ResourceSet>(resources);
	}
	
	/**
	 * Returns an InputStream based on the first underlying ResourceSet
	 * that has a resource for the given path.
	 */
	public InputStream getInputStream(String path) throws QuietIOException {
		for (ResourceSet resource : resources) {
			if (resource.hasResource(path)) {
				return resource.getInputStream(path);
			}
		}
		throw new QuietIOException(new FileNotFoundException(
			"No underlying resource set provides a resource for "+path));
	}

	/**
	 * Returns an OutputStream based that writes the given path into
	 * the first resource in the ResourceSet.
	 */
	public OutputStream getOutputStream(String path) throws QuietIOException {
		if (resources.size() == 0) {
			throw new QuietIOException(new FileNotFoundException(
				"No valid path for writing "+path));
		}
		return resources.get(0).getOutputStream(path);
	}

	/**
	 * Returns true if any underlying ResourceSet provides for the
	 * given path.
	 */
	public boolean hasResource(String path) {
		for (ResourceSet resource : resources) {
			if (resource.hasResource(path)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns the union of all resources listed by the resources
	 * in the underlying resource set.
	 */
	public String[] listResources() {
		return listResources("");
	}
	
	/**
	 * Returns the union of all resources listed by the resources
	 * in the underlying resource set.
	 */
	public String[] listResources(String path) {
		LinkedHashSet<String> all = new LinkedHashSet<String>();
		for (ResourceSet resource : resources) {
			if (resource.listResources(path) == null) {
				throw new QuietIOException("Invalid resource "+resource);
			}
			for (String subpath : resource.listResources(path)) {
				all.add(subpath);
			}
		}
		return all.toArray(new String[0]);
	}

	public URI getInputURI(String path) {
		for (ResourceSet resource : resources) {
			if (resource.hasResource(path)) {
				return resource.getInputURI(path);
			}
		}
		throw new QuietIOException(new FileNotFoundException(
				"No underlying resource set provides a resource for "+path));
	}

	public URI getOutputURI(String path) {
		if (resources.size() == 0) {
			throw new QuietIOException(new FileNotFoundException(
				"No valid path for writing "+path));
		}
		return resources.get(0).getOutputURI(path);
	}
	
	@Override
	public String toString() {
		if (resources.size() == 0) {
			return "";
		}
		
		StringBuilder builder = new StringBuilder();
		for (ResourceSet resource : resources) {
			builder.append(Stringify.toString(resource)).append(File.pathSeparatorChar);
		}
		return builder.toString().substring(0, builder.length()-1);
	}
}