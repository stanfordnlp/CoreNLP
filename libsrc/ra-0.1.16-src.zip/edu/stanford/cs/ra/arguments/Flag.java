/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.io.Serializable;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.stringify.Stringify.StaticFromString;

/**
 * Type for marking a command line flag: ie a boolean that does not
 * require a following "true" or "false" argument.
 * 
 * @author dramage
 */
public class Flag implements Serializable {
	private static final long serialVersionUID = 1L;
	
	/** True if the flag is set */
	public final boolean isSet;
	
	public Flag(boolean present) {
		this.isSet = present;
	}
	
	@Override
	public String toString() {
		return Boolean.toString(isSet);
	}
	
	@StaticFromString
	public static Flag fromString(String string) {
		return new Flag(Stringify.fromString(Boolean.class, string));
	}
}