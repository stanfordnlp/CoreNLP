/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;


/**
 * Utilities for things that can populate a set of ArgumentBoxes. The primary
 * usage of this class is calling populate and usage. {@link ArgumentPopulator}
 * instances can be created using the <code>from*</code> methods.
 * 
 * @author dramage
 */
public class ArgumentPopulators {

	static {
		// make sure flags are loaded
		new Flag(true);
	}

	/**
	 * Private meta-class for querying additional command line arguments.
	 * 
	 * @author dramage
	 */
	@Argument.BoxName("CommandLine")
	private static class ArgumentCommandLineArgs {
		@Argument("Auxiliary (.props) files for reading default arguments")
		@Argument.Switch("--arguments")
		@Argument.Policy(ArgumentPolicy.OPTIONAL)
		File[] argFiles;
	}
	
	/**
	 * Returns an argument populator that works off the given command line
	 * arguments, additionally loading any argument props files flagged with
	 * --arguments.
	 */
	public static ArgumentPopulator fromCommandLineWithProps(final String ... argv) {
		ArgumentCommandLineArgs box = new ArgumentCommandLineArgs();
		
		ArgumentPopulator commandLine = fromCommandLine(argv);
		
		// first see if we need to do help or load additional files
		commandLine.populate(box);
		
		if (box.argFiles == null) {
			// no additional .props files, return command line
			return commandLine;
		} else {
			// read additional .props files
			List<ArgumentPopulator> populators = new LinkedList<ArgumentPopulator>();

			// add each properties file
			for (File file : box.argFiles) {
				InputStream stream = IOUtils.openFile(file);
				populators.add(ArgumentPopulators.fromProperties(stream));
				IOUtils.close(stream);
			}
			
			// add command line arguments last so they take precedence
			populators.add(commandLine);
			
			// return merged populators
			return ArgumentPopulators.fromPopulators(populators);
		}
	}
	
	/**
	 * Returns a default, empty populator that doesn nothing.
	 */
	public static ArgumentPopulator emptyPopulator() {
		return new ArgumentPopulator() {
			public void populate(ArgumentPopulatorResult result) {
				// do nothing
			}
			
			@Override
			public String toString() {
				return "EmptyPopulator";
			}
		};
	}
	
	/**
	 * Returns an argument populator that works off the given command line
	 * arguments.  See also {@link #fromCommandLineWithProps(String[])}
	 * for a  similar method whose returned {@link ArgumentPopulator} also
	 * includes the contents of properties files listed on the command line.
	 */
	public static ArgumentPopulator fromCommandLine(final String ... argv) {
		
		return new ArgumentPopulator() {
			public void populate(ArgumentPopulatorResult result) {
				// which argument at which string
				Map<Integer,ArgumentInfo> processedStrings =
					new HashMap<Integer, ArgumentInfo>();

				// map from argument to box requesting it
				Map<ArgumentInfo,ArgumentBox> argToBox =
					ArgumentBoxes.getInfoToBoxMap(result.getArgumentBoxes());
				
				// map from switch string to all arguments 
				Map<String, Set<ArgumentInfo>> switchToArgs =
					getSwitchToArgs(argToBox.keySet());
				
				// populate from args
				for (int i = 0; i < argv.length; i++) {
					if (processedStrings.containsKey(i)) {
						// only look at unprocessed arguments
						continue;
					}

					String swtch = argv[i];
					if (switchToArgs.containsKey(swtch)) {
						for (ArgumentInfo arg : switchToArgs.get(swtch)) {
							if (arg.getType().isAssignableFrom(Flag.class)) {
								// Flags do not take an argument; if present,
								// assume "true"
								
								result.setPopulated(arg);
								argToBox.get(arg).setValue(arg, "true");
								processedStrings.put(i, arg);
							} else {
								// other types of arguments, consume one
								for (int argOffset = 1; argOffset <= arg.getCommandStringsConsumed(); argOffset++) {
									if (processedStrings.containsKey(i+argOffset)) {
										result.addError("Argument "+(i+argOffset)+" should be argument for "+swtch+" but is already used by "+processedStrings.get(i+argOffset));
									} else if (argv.length <= i+argOffset) {
										result.addError("Expected next an argument for switch "+swtch);
									} else {
										argToBox.get(arg).setValue(arg, argv[i+argOffset]);
										processedStrings.put(i, arg);
										processedStrings.put(i+argOffset, arg);
										result.setPopulated(arg);
									}
								}
							}
						}
					}
				}

				// inform result of which arguments were used
				boolean[] used = new boolean[argv.length];
				for (int i = 0; i < argv.length; i++) {
					used[i] = processedStrings.containsKey(i);
				}
				result.addCommandLineArguments(argv, used);
			}
			
			@Override
			public String toString() {
				return "CommandLinePopulator:["+Arrays.asList(argv)+"]";
			}
			
		};
	}
	
	/**
	 * Returns an ArgumentPopulator based on the properties listed in the given
	 * stream.
	 */
	public static ArgumentPopulator fromProperties(InputStream propsStream) {
		Properties props = new Properties();
		try {
			props.load(propsStream);
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
		return fromProperties(props);
	}
	
	/**
	 * Returns an ArgumentPopulator based on the properties listed in the given
	 * Properties instances.
	 */
	@SuppressWarnings("unchecked")
	public static ArgumentPopulator fromProperties(Properties properties) {
		return fromStrings((Map)properties);
	}
	
	/**
	 * Returns an ArgumentPopulator that maps from the given named arguments
	 * to stringified values.
	 */
	public static ArgumentPopulator fromStrings(final Map<String,String> props) {
		return new ArgumentPopulator() {
			public void populate(ArgumentPopulatorResult result) {
				Map<ArgumentInfo,ArgumentBox> argToBox =
					ArgumentBoxes.getInfoToBoxMap(result.getArgumentBoxes());
				
				for (ArgumentInfo arg : argToBox.keySet()) {
					if (props.containsKey(arg.getQualifiedName())) {
						// try fully qualified name first
						argToBox.get(arg).setValue(arg, props.get(arg.getQualifiedName()));
						result.setPopulated(arg);
					} else if (props.containsKey(arg.getArgName())) {
						// then try unqualified name
						argToBox.get(arg).setValue(arg, props.get(arg.getArgName()));
						result.setPopulated(arg);
					}
				}
			}
			
			@Override
			public String toString() {
				return "StringsPopulator:["+props.toString()+"]";
			}
		};
	}
	
	/**
	 * Returns an ArgumentPopulator that maps from key,value pairs provided
	 * as arguments, e.g. fromString("key1","value1", "key2","value2", ...).
	 */
	public static ArgumentPopulator fromStrings(final String ... pairs) {
		if (pairs.length % 2 == 1) {
			throw new IllegalArgumentException("Expected even number of arguments (key,value pairs)");
		}
		
		Map<String,String> map = new HashMap<String,String>();
		for (int i = 0; i < pairs.length; i += 2) {
			map.put(pairs[i], pairs[i+1]);
		}
		
		return fromStrings(map);
	}
	
	/**
	 * Returns a single populator that populates based on all the underlying
	 * populators.
	 */
	public static ArgumentPopulator fromPopulators(final List<ArgumentPopulator> populators) {
		return new ArgumentPopulator() {
			public void populate(ArgumentPopulatorResult result) {
				// call each populator
				for (ArgumentPopulator populator : populators) {
					if (populator == null) {
						continue;
					}
					try {
						populator.populate(result);
					} catch (ArgumentException e) {
						if (e.result == null) {
							result.addError(e.getMessage());
						}
					}
				}
			}
			
			@Override
			public String toString() {
				return "PopulatorsPopulator["+populators+"]";
			}
		};
	}
	
	/**
	 * Returns a single populator that populates based on all the underlying
	 * populators.
	 */
	public static ArgumentPopulator fromPopulators(ArgumentPopulator ... populators) {
		return fromPopulators(Arrays.asList(populators));
	}
	
	/**
	 * Returns a map from a String switch to every ArgumentInfo instance
	 * expecting it.
	 */
	private static Map<String, Set<ArgumentInfo>> getSwitchToArgs(Collection<ArgumentInfo> args) {
		Map<String, Set<ArgumentInfo>> switchToArgs = new HashMap<String,Set<ArgumentInfo>>();
		
		for (ArgumentInfo arg : args) {
			for (String swtch : arg.getSwitches()) {
				if (!switchToArgs.containsKey(swtch)) {
					switchToArgs.put(swtch, new HashSet<ArgumentInfo>());
				}
				
				switchToArgs.get(swtch).add(arg);
			}
		}

		return switchToArgs;
	}
}
