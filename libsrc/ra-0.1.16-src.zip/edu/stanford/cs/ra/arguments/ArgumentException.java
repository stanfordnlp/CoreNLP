/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;


/**
 * Exception thrown when parsing arguments.  Includes a list of errors
 * and warnings.
 * 
 * @author dramage
 */
public class ArgumentException extends RuntimeException {
	public final ArgumentPopulatorResult result;
	
	/** Initializes with the given error message. */
	public ArgumentException(String s) {
		super(s);
		this.result = null;
	}

	/** Initializes with the given error message and cause. */
	public ArgumentException(String s, Throwable cause) {
		super(s, cause);
		this.result = null;
	}

	/** Initializes with the given usage string and list of errors and warnings. */
	public ArgumentException(ArgumentPopulatorResult result) {
		super(result.toString());
		this.result = result;
	}
	
	private static final long serialVersionUID = 2L;
}
