/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.IOUtils.MD5Listener;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;
import edu.stanford.cs.ra.xml.XMLStream;

/**
 * A ResourceSet that wraps an underlying resource set with MD5 sums.
 */
public class MD5ResourceSet implements ResourceSet {
	private static final long serialVersionUID = 1L;
	
	/** Wrapped ResourceSet */
	private final ResourceSet wrapped;
	
	/** Type to output */
	private final String type;
	
	/** Stream to write status messages to */
	private final XMLStream stream;
	
	/**
	 * Initializes this ResourceSet to wrap the given ResourceSet and
	 * to output status lines "IORead" and "IOWrite" to the given XMLStream
	 * with the given type argument set in the "type" argument of
	 * the generated line.
	 */
	public MD5ResourceSet(ResourceSet resources, String type, XMLStream stream) {
		this.wrapped = resources;
		this.stream = stream;
		this.type = type;
	}
	
	public InputStream getInputStream(final String path) throws QuietIOException {
		return IOUtils.wrapWithMD5(wrapped.getInputStream(path),
				new MD5Listener() {

			public void closed(long bytesRead, String hash) {
				stream.line("IORead", "", "resource", path, "type", type, "read", bytesRead, "hash", hash);
			}
		});
	}

	public OutputStream getOutputStream(final String path) throws QuietIOException {
		return IOUtils.wrapWithMD5(wrapped.getOutputStream(path),
				new MD5Listener() {

			public void closed(long bytesWritten, String hash) {
				stream.line("IOWrite", "", "resource", path, "type", type, "written", bytesWritten, "hash", hash);
			}
		});
	}

	public boolean hasResource(String path) {
		return wrapped.hasResource(path);
	}

	public String[] listResources() {
		return wrapped.listResources();
	}
	
	public String[] listResources(String path) {
		return wrapped.listResources(path);
	}

	public URI getInputURI(String path) {
		return wrapped.getInputURI(path);
	}

	public URI getOutputURI(String path) {
		return wrapped.getOutputURI(path);
	}
	
	@Override
	public String toString() {
		return wrapped.toString();
	}
}