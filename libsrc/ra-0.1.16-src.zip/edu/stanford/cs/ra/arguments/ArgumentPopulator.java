/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.util.Collection;
import java.util.Collections;

/**
 * An ArgumentPopulator populates pushes arguments into an {@link ArgumentBox}.
 * Most common convenience populators can be obtained through calls to
 * {@link ArgumentPopulators}.
 * 
 * @author dramage
 */
public abstract class ArgumentPopulator {
	/**
	 * Instantiates and populates arguments on the given target box. Equivalent
	 * to calling populator.populate(Arguments.instantiate(type)). If access to
	 * the ArgumentPopulatorResult is required, call
	 * {@link Arguments#instantiate(Class)} directly.
	 * 
	 * @throws ArgumentException
	 *             upon encountering an exception while populating
	 */
	public <E> E instantiate(Class<E> type) throws ArgumentException {
		E instance = Arguments.instantiate(type);
		populate(instance);
		return instance;
	}
	
	/**
	 * Populates arguments on the given target object.  Equivalent to calling
	 * <code>populate(ArgumentBoxes.fromInstance(target));</code>
	 * 
	 * @throws ArgumentException upon encountering an exception while populating
	 */
	public ArgumentPopulatorResult populate(Object target) throws ArgumentException {
		return this.populate(ArgumentBoxes.fromInstance(target));
	}
	
	/**
	 * Populates arguments on the given objects.  Equivalent to calling
	 * <code>populate(ArgumentBoxes.fromInstances(targets));</code> 
	 * 
	 * @throws ArgumentException upon encountering an exception while populating
	 */
	public ArgumentPopulatorResult populate(Object ... targets) throws ArgumentException {
		return this.populate(ArgumentBoxes.fromInstances(targets));
	}
	
	/**
	 * Populates arguments on the given single ArgumentBox.  Equivalent to
	 * calling <code>populate(Collections.singleton(box)</code>.
	 * 
	 * @throws ArgumentException upon encountering an exception while populating
	 */
	public ArgumentPopulatorResult populate(ArgumentBox box) throws ArgumentException {
		return this.populate(Collections.singleton(box));
	}
	
	/**
	 * Populates arguments contained in the given argument boxes, returning
	 * the set of arguments actually populated and any warnings encountered.
	 * 
	 * @throws ArgumentException upon encountering an exception while populating
	 */
	public ArgumentPopulatorResult populate(Collection<ArgumentBox> boxes) {
		for (ArgumentBox box : boxes) {
			ArgumentBoxes.setDefaultValues(box);
		}
		ArgumentPopulatorResult result = new ArgumentPopulatorResult(boxes);
		populate(result);
		result.check();
		return result;
	}
	
	/**
	 * Populates arguments contained in the given argument box into the given
	 * result object.
	 */
	abstract void populate(ArgumentPopulatorResult result)
		throws ArgumentException;
}
