/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.security.Permission;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TreeSet;
import java.util.zip.ZipEntry;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;

import sun.misc.Signal;
import sun.misc.SignalHandler;
import edu.stanford.cs.ra.arguments.Argument;
import edu.stanford.cs.ra.arguments.ArgumentBox;
import edu.stanford.cs.ra.arguments.ArgumentBoxes;
import edu.stanford.cs.ra.arguments.ArgumentException;
import edu.stanford.cs.ra.arguments.ArgumentPolicy;
import edu.stanford.cs.ra.arguments.ArgumentPopulator;
import edu.stanford.cs.ra.arguments.ArgumentPopulators;
import edu.stanford.cs.ra.arguments.Flag;
import edu.stanford.cs.ra.stage.StageWiseException;
import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.ReflectionUtils;
import edu.stanford.cs.ra.util.IOUtils.MD5Listener;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;
import edu.stanford.cs.ra.workbook.JarBuilder;
import edu.stanford.cs.ra.workbook.MD5ResourceSet;
import edu.stanford.cs.ra.workbook.ResourceSet;
import edu.stanford.cs.ra.workbook.VersionControl;
import edu.stanford.cs.ra.workbook.Workbook;
import edu.stanford.cs.ra.xml.BranchedXMLStream;
import edu.stanford.cs.ra.xml.EscapedXML;
import edu.stanford.cs.ra.xml.NullXMLStream;
import edu.stanford.cs.ra.xml.SynchronizedXMLStream;
import edu.stanford.cs.ra.xml.TracedXMLStream;
import edu.stanford.cs.ra.xml.XMLOutputStream;
import edu.stanford.cs.ra.xml.XMLPrintStreamWrapper;
import edu.stanford.cs.ra.xml.XMLStream;
import edu.stanford.cs.ra.xml.XMLStringBuilder;
import edu.stanford.cs.ra.xml.TracedXMLStream.ActionType;
import edu.stanford.cs.ra.xml.TracedXMLStream.FixedTagAction;

/**
 * Global module initialization for ResearchAssistant.  Applications wishing
 * to use RA should call {@link #begin(String[], Object...)} at the start of
 * the program.
 * 
 * @author dramage
 */
@Argument.BoxName("RA")
public class RA {
	
	/** RA Version info */
	public static final String VERSION = "0.1.16";
	
	/** Global argument populator instances for getting argument values */
	private static ArgumentPopulator arguments = ArgumentPopulators.emptyPopulator();

	/** Global workbook instance for getting resources and writing checkpoints */
	private static Workbook workbook = new Workbook(null, null, null);
	
	/**
	 * Container that holds different output streams provided by RA.
	 * 
	 * @author dramage
	 */
	public static final class RAStreams {
		/** Goes only to the console and not to the the log */
		private final XMLStream consoleOnly =
			new SynchronizedXMLStream(new XMLOutputStream(System.out));

		/** An XMLStream that goes to the console and to the log. */
		public final SynchronizedXMLStream console =
			new SynchronizedXMLStream(consoleOnly);

		/** An XMLStream that goes to only the log. */
		public final SynchronizedXMLStream log =
			new SynchronizedXMLStream(new NullXMLStream());

		/** Default System.out (not-intercepted) */
		public final PrintStream systemOut = System.out;

		/** Default System.err (not-intercepted) */
		public final PrintStream systemErr = System.err;

		private RAStreams() { }
	}
	
	/** Container for standard output streams */
	public final static RAStreams streams = new RAStreams();
	
	/** Global XML output stream for reporting results. */
	public static final XMLStream stream =
		new SynchronizedXMLStream(streams.console);

	
	//
	// command line arguments
	//
	
	/**
	 * RA command line arguments.
	 */
	@Argument("Print version information and exit.")
	@Argument.Switch("--ra-version")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("DisplayVersion")
	private static Flag argDoVersion;
	
	@Argument("Print RA usage information and exit.")
	@Argument.Switch("--ra-help")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("DisplayHelp")
	private static Flag argDoHelp;
	
	/** Seed for the random number generator. */
	@Argument("Seed for RA.random and Math.random")
	@Argument.Switch("--ra-seed")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	private static long seed = 8682522807148013L + System.nanoTime();
	
	@Argument("Workbook path for writing new run logs and finding checkpoints,\n" +
			"specified as a path-separator (usually \":\") delimited list of paths,\n" +
			"where the first path in the list is taken as the default write path\n" +
			"for new files.  The --ra-save switch controls what gets written to the\n" +
			"run folder in a new subfolder named as per --ra-run-pattern.")
	@Argument.Switch("--ra-workbook")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("Workbook")
	private static ResourceSet argWorkbook;

	@Argument("Workbook path for locating additional static resources.")
	@Argument.Switch("--ra-resources")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("WorkbookResources")
	private static ResourceSet argResources;
	
	@Argument("Pattern used for naming the generated run folder in this workbook.\n"
			+ "Use \"\" to prevent this run from generating a log.")
	@Argument.Switch("--ra-run-pattern")
	@Argument.Default("{CLASS}-{YEAR}{MONTH}{DAY}-{ID}")
	@Argument.Name("WorkbookRun")
	private static String argRunPattern;
	
	@Argument("Additional output file to contain XML run log;"
			+ "\"-\" to send to stdout.")
	@Argument.Switch("--ra-xml")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("XMLFile")
	private static File argXMLFile;
	
	@Argument("JAR file in which to save re-runnable experiment.")
	@Argument.Switch("--ra-jar")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("JarFile")
	private static File argJarPath;
	
	@Argument("Root of (subversion) source tree checkout.")
	@Argument.Switch("--ra-source")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Name("SourcePath")
	private static File[] argSourcePaths;
	
	@Argument("Write the current time to the xml log every --ra-clock minutes.\n"
			+ "Use 0 to disable the clock.")
	@Argument.Switch("--ra-clock")
	@Argument.Default("5")
	private static double argClock;
	
	enum ToSave {
		log, src, stdin;
	}
	
	@Argument("Comma-delimited list of what to save into workbook run folder.")
	@Argument.Switch("--ra-save")
	@Argument.Policy(ArgumentPolicy.OPTIONAL)
	@Argument.Default("")
	@Argument.Name("Save")
	private static ToSave[] argToSave;
	
	@Argument.Check
	static void argCheck() {
		if (argSourcePaths != null) {
			for (File argSourcePath : argSourcePaths) {
				if (argSourcePath != null && !(argSourcePath.canRead() && argSourcePath.isDirectory())) {
					throw new ArgumentException("--ra-source must readable source directory");
				}
			}
		}
		
		if (argJarPath != null && (argJarPath.exists() && (argJarPath.isDirectory() || !argJarPath.canWrite()))) {
			throw new ArgumentException("--ra-jar must be a (new) writable file");
		}
	}
	
	//
	// random number generator utility methods
	//
	
	/**
	 * Global random number generator with reproducible seed.  To be used
	 * instead of Math.random
	 */
	public static final Random random = new Random(seed);

	/** Returns RA.random.nextDouble() */
	public static double random() {
		return random.nextDouble();
	}

	/** Incrementing counts of number of seed requests per calling class. */
	private static final Map<String,Integer> seedRequests =
		new HashMap<String,Integer>();
	
	/** Returns the next instance of Random for the given  */
	public static Random newRandom() {
		// returns the 
		StackTraceElement top = ReflectionUtils.getTraceTop();
		
		String name = (top == null) ? RA.class.getName() : top.getClassName();
		
		if (seedRequests.containsKey(name)) {
			seedRequests.put(name, seedRequests.get(name)+1);
		} else {
			seedRequests.put(name, 0);
		}

		return new Random(seedRequests.get(name) + seed);
	}


	//
	// private variables
	//
	
	/** Reason for exit */
	private static String exitcode = "0";
	
	/** (Possibly empty) stack trace of exit */
	private static Object exitbody = "";
	
	/** Time since call to RA.begin */
	private static long startTime;
	
	/** main class */
	private static Class<?> startClass;
	
	/** Arguments to program start */
	private static String[] argv;
	
	/** If RA.begin has already been called */
	private static boolean active = false;
	
	/** Jar we are generating or null if no jar is to be saved */
	private static JarBuilder jar = null;
	
	//
	// methods
	// 
	
	/**
	 * Installs RA into the current running Java environment.
	 * 
	 * Replaces the System.out and System.err with well-formed XML output
	 * streams.  Sets Math.random's random seed.  Registers shutdown hooks
	 * and signal listeners to capture end conditions.  Adds the given
	 * argv as strings for the RA.parser, the global arguments parser.
	 * 
	 * Upon encountering an arguments parsing error, may print a usage message
	 * and exit.
	 * 
	 * Has no effect if RA.begin has previously been called.
	 */
	public static void begin(String[] argv) {
		begin(argv, new Object[0]);
	}
	
	/**
	 * Installs RA into the current running Java environment as per
	 * RA.begin(String[] argv), but also populates all {@link Argument} fields
	 * in the given instances (or classes for static fields).
	 */
	public static void begin(String[] argv, Object ... toPopulate) {
		if (active) { return; }
		active = true;
		
		try {
		  // make sure IOUtils has been loaded for the shutdown hook to work ok
		  Class.forName(IOUtils.class.getName());
		} catch (Exception e) {
		  // ignore
		}
		
		RA.argv = argv;
		
		// find start class
		StackTraceElement top = ReflectionUtils.getTraceTop();
		if (top == null) { top = Thread.currentThread().getStackTrace()[0]; }
		try {
			startClass = Class.forName(top.getClassName());
		} catch (ClassNotFoundException e1) {
			startClass = RA.class;
		}
		startTime = System.currentTimeMillis();
		
		// get ArgumentPopulators based on the initial command line
		arguments = ArgumentPopulators.fromPopulators(
				ArgumentPopulators.fromCommandLineWithProps(argv),
				arguments);
		
		try {
			List<ArgumentBox> boxes = ArgumentBoxes.fromInstances(toPopulate);
			boxes.addAll(ArgumentBoxes.fromInstances(RA.class));
			
			List<String> warnings = arguments.populate(boxes).getWarnings();
			for (String warning : warnings) {
				System.out.println("Warning: "+warning);
			}
		} catch (ArgumentException e) {
			System.err.println(e);
			System.exit(-1);
		}
		
		if (argDoVersion.isSet || argDoHelp.isSet) {
			System.out.println("ResearchAssistant "+VERSION);
			System.out.println("  A library for scientific research tools.");
			System.out.println("");
			System.out.println("http://www.stanford.edu/~dramage/ra/");
			System.out.println("(c) Daniel Ramage 2007");
			
			if (argDoHelp.isSet) {
				System.out.println(ArgumentBoxes.usage(Collections.singletonList(
						ArgumentBoxes.fromInstance(RA.class))));
			}

			System.exit(0);
		}
		
		if (argWorkbook != null || argResources != null) {
			if (argWorkbook != null) {
				argWorkbook = new MD5ResourceSet(argWorkbook, "workbook", streams.log);
			}
			if (argResources != null) {
				argResources = new MD5ResourceSet(argResources, "resource", streams.log);
			}
			
			workbook = new Workbook(
					argRunPattern.length() > 0 ? interpolate(argRunPattern) : null,
					argWorkbook, argResources);
		}

		//
		// set up RA runtime
		//
		
		setupLogging();
		
		//
		// begin the log stream
		//

		streams.log.begin(
				"invoke", "class", startClass,
				"starttime", new Date(), "seed", seed);
		streams.log.begin("environment");
		streams.log.line("cwd", new File("").getAbsolutePath());
		
		StringBuilder commandLine = new StringBuilder();
		for (int i = 0; i < argv.length; i++) {
			final String arg = argv[i];
			if (arg.contains(" ") || arg.length() == 0 || arg.startsWith("\"")) {
				commandLine.append('"').append(Stringify.escape(arg,"\"")).append('"');
			} else {
				commandLine.append(arg);
			}
			if (i < argv.length - 1) {
				commandLine.append(" ");
			}
		}
		streams.log.line("argv", commandLine);
		streams.log.begin("arguments");
		for (String arg : argv) {
			streams.log.line("arg", arg);
		}
		streams.log.end("arguments");
		streams.log.line("workbook", "",
				"run", workbook.canWrite() ? workbook.getOutputPath("") : null,
				"base", argWorkbook, "resources", argResources);
		streams.log.begin("env");
		for (String key : System.getenv().keySet()) {
			streams.log.line("entry", System.getenv(key), "key", key);
		}
		streams.log.end("env");
		streams.log.begin("properties");
		for (Object key : new TreeSet<Object>(System.getProperties().keySet())) {
			streams.log.line("entry",
					System.getProperties().getProperty((String)key),
					"key", key);
		}
		streams.log.end("properties");
		streams.log.end("environment");

		// set up clock
		Thread clock = new Thread(new Runnable() {
			public void run() {
				while(true) {
					try {
						Thread.sleep((long)(argClock * 60 * 1000));
					} catch (InterruptedException e) {
						// safe to ignore;
					}
					streams.log.line("clock", new Date());
				}
			}
		});
		clock.setDaemon(true);
		clock.setName("ra:clock");
		clock.start();
		
		setupRandom();
		setupListeners();
		setupShutdownHook();
	}

	/**
	 * Sets up logging to any combination of workbook, console/extra file, or
	 * jar.
	 */
	private static void setupLogging() {
		boolean logToConsole = false;
		List<OutputStream> logStreams = new LinkedList<OutputStream>();
		
		// set up workbook logging
		if (Arrays.asList(argToSave).contains(ToSave.log)) {
			if (!workbook.canWrite()) {
				throw new ArgumentException("Cannot save log - no writeable workbook specified");
			}
			logStreams.add(workbook.getOutputStream("run.xml"));
		}
		
		// set up logging request via --ra-xml
		if (argXMLFile != null) {
			if (argXMLFile.getPath().equals("-") || argXMLFile.getPath().equals("--")) {
				logToConsole = true;
				logStreams.add(streams.systemOut);
			} else {
				// create the file for logging
				OutputStream log;
				try {
					log = new FileOutputStream(argXMLFile);
				} catch (FileNotFoundException e) {
					throw new QuietIOException(e);
				}
				logStreams.add(log);
			}
		}
		
		// set up jar stream
		if (argJarPath != null) {
			OutputStream jarOutputStream;
			try {
				jarOutputStream = new FileOutputStream(argJarPath);
			} catch (FileNotFoundException e) {
				throw new QuietIOException(e);
			}
			jar = new JarBuilder(jarOutputStream, startClass.getName(), Arrays.asList(argv));
			
			// save sources
			if (argSourcePaths != null) {
				VersionControl.createPacks(argSourcePaths, jar.stream, "META-RA/source/");
			}
			
			// start invocation.xml
			try {
				jar.stream.putNextEntry(new ZipEntry("META-RA/invocation.xml"));
			} catch (IOException e) {
				throw new QuietIOException(e);
			}
			
			// set up new XMLStream for jar
			logStreams.add(jar.stream);
		} else {
			jar = null;
		}
		
		// install log to System.out and System.err and add tracing if logging
		if (!logStreams.isEmpty()) {
			OutputStream logStream =
				new BranchedOutputStream(logStreams.toArray(new OutputStream[0]));
			TracedXMLStream traced =
				new TracedXMLStream(new XMLOutputStream(logStream));
			
			traced.addTagAction(new FixedTagAction("stdout", ActionType.TRACE));
			traced.addTagAction(new FixedTagAction("stderr", ActionType.TRACE));
			
			streams.log.setWrappedStream(traced);
			if (logToConsole) {
				streams.console.setWrappedStream(streams.log);
			} else {
				streams.console.setWrappedStream(
						new BranchedXMLStream(streams.consoleOnly, streams.log));
			}
			
			PrintStream out = new XMLPrintStreamWrapper("stdout", streams.log);
			PrintStream err = new XMLPrintStreamWrapper("stderr", streams.log);
			if (!logToConsole) {
				out = new BranchedPrintStream(streams.systemOut, out);
				err = new BranchedPrintStream(streams.systemErr, err);
			}
			System.setOut(out);
			System.setErr(err);

			// intercept stdin
			InputStream newIn = IOUtils.wrapWithMD5(System.in, new MD5Listener() {
				public void closed(long bytesRead, String hash) {
					streams.log.line("stdin", "", "read", bytesRead, "hash", hash);
				}
			});
			// System.setIn(new XMLInputStreamLogger(System.in, streams.log, "stdin"));
			System.setIn(newIn);
			IOUtils.closeOnExit(System.in);
		}
	}

	/** Set up our random instance and reset the system rng. */
	private static void setupRandom() {
		try {
			for (Field field : Math.class.getDeclaredFields()) {
				if (field.getName().equals("randomNumberGenerator")) {
					boolean accessible = field.isAccessible();
					field.setAccessible(true);
					if (field.get(null) != null) {
						streams.console.line("warning",
								"Math.random called before RA.begin");
					}
					field.set(null, random);
					field.setAccessible(accessible);
					break;
				}
			}
		} catch (Exception e) {
			streams.console.line("warning", "RA unable to reset Math.random seed");
		}
		random.setSeed(seed);
	}
	
	/**
	 * Installs listeners for System.exit, unix signals, and uncaught
	 * exceptions.
	 */
	private static void setupListeners() {
		// log System.exit()
		new ExitLogger().register();
		
		// log POSIX signals
		for (String signal : new String[]{"ABRT", "INT", "TERM", "HUP", "KILL", "QUIT", "ALRM", "CHLD"}) {
			try {
				new SignalLogger(signal).register();
			} catch (Exception e) {
				// ignore exceptions while trying to register signal handler
			}
		}
		
		// log uncaught exceptions
		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
			public void uncaughtException(Thread thread, Throwable exception) {
				if (exception instanceof StageWiseException && exception.getCause() instanceof ArgumentException) {
					exception = exception.getCause();
				}
				
				System.setErr(RA.streams.systemErr);
				exception.printStackTrace();
				
				if (exception instanceof ArgumentException) {
					
					exitcode = ArgumentException.class.getSimpleName();
					exitbody = exception.toString();
				} else {
					XMLStringBuilder builder = new XMLStringBuilder();
					
					StringWriter w = new StringWriter();
					exception.printStackTrace(new PrintWriter(w));
					builder.line("cause",w.toString());
					
					exitcode = "Exception";
					exitbody = new EscapedXML(builder.toString());
				}
			}
		});
	}

	/**
	 * Adds a JVM shutdown hook to record the exit code as recorded by
	 * one of our listeners and to finish up leftover computations needed
	 * for jar construction, etc.
	 */
	private static void setupShutdownHook() {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			public void run() {
				IOUtils.closeRegisteredStreams();
				
				streams.log.closeWith("exit", exitbody,
						"code", exitcode,
						"endtime", new Date(),
						"runtime", getRunningTimeString());
				streams.console.close();
				
				if (jar != null) {
					if (exitcode.equals("0")) {
						jar.slurpClasses(ReflectionUtils.getLoadedClasses());
					}
					jar.finish();
				}
			}
		}));
	}
	
	//
	// Query methods for asking about the state of the runtime.
	//
	
	/**
	 * Returns true if RA.begin has already been called
	 */
	public static boolean isActive() {
		return active;
	}
	
	/**
	 * Returns the current running time of the application (since
	 * call to RA.begin) in milliseconds.
	 */
	public static long getRunningTimeMS() {
		if (!isActive()) {
			throw new RuntimeException("RA.begin has not been called");
		}
		
		return System.currentTimeMillis() - startTime;
	}
	
	/**
	 * Returns the runtime of the program as per the duration definition
	 * in W3C XML Schema 1.0.
	 */
	public static String getRunningTimeString() {
		if (!isActive()) {
			throw new RuntimeException("RA.begin has not been called");
		}

		try {
			Duration duration = DatatypeFactory.newInstance()
				.newDuration(getRunningTimeMS());
			return duration.toString();
		} catch (DatatypeConfigurationException e) {
			return (getRunningTimeMS()/1000.)+"s";
		}
	}
	
	/** Global argument populator instances for getting argument values */
	public static ArgumentPopulator getArgumentPopulator() {
		return arguments;
	}
	
	/**
	 * Sets the global ArgumentPopulator to be the given populator.
	 */
	public static void setArgumentPopulator(ArgumentPopulator populator) {
		arguments = populator;
	}
	
	/**
	 * Returns a RsourceSet suitable for accessing all resources in the
	 * workbook folder.
	 */
	public static Workbook getWorkbook() {
		// WorkbookURLs.init();
		return workbook;
	}
	
	//
	// Utility methods
	//
	
	/**
	 * Interpolates values into the given string.
	 */
	private static String interpolate(String var) {
		var = var.replaceAll("\\{CLASS\\}",
				startClass.getSimpleName());
		
		var = var.replaceAll("\\{CLASS_HASH\\}",
				String.format("%08X", startClass.hashCode()));
		
		var = var.replaceAll("\\{TIME_HASH\\}",
				String.format("%08X", Long.valueOf(startTime).hashCode()));

		Calendar calendar = Calendar.getInstance();
		
		var = var.replaceAll("\\{YEAR\\}",
				String.format("%04d",calendar.get(Calendar.YEAR)));
		var = var.replaceAll("\\{MONTH\\}",
				String.format("%02d",calendar.get(Calendar.MONTH)+1));
		var = var.replaceAll("\\{DAY\\}",
				String.format("%02d",calendar.get(Calendar.DATE)));
		var = var.replaceAll("\\{HOUR\\}",
				String.format("%02d",calendar.get(Calendar.HOUR_OF_DAY)));
		var = var.replaceAll("\\{MINUTE\\}",
				String.format("%02d",calendar.get(Calendar.MINUTE)));
		var = var.replaceAll("\\{SECOND\\}",
				String.format("%02d",calendar.get(Calendar.SECOND)));
		
		int id = 0;
		if (var.contains("{ID}")) {
			String instance = null;
			while (instance == null || (argWorkbook != null && argWorkbook.hasResource(instance))) {
				instance = var.replaceAll("\\{ID\\}",
						String.format("%04d",id++));
			}
			var = instance;
		}
		
		return var;
	}
	
//	/**
//	 * A ClassLoader that records all classes successfully loaded
//	 * during the running of the program.
//	 * 
//	 * @author dramage
//	 */
//	private static class RecordingClassLoader extends ClassLoader {
//		/** The real classloader that actually does work */
//		private final ClassLoader wrapped;
//		
//		/** The ordered set of loaded classes */
//		private final Set<String> loaded = new LinkedHashSet<String>();
//		
//		public RecordingClassLoader(ClassLoader wrapped) {
//			this.wrapped = wrapped;
//		}
//		
//		@Override
//		public Class<?> loadClass(String name) throws ClassNotFoundException {
//			Class<?> c;
//			try {
//				c = wrapped.loadClass(name);
//			} catch(ClassNotFoundException e) {
//				throw e;
//			}
//			loaded.add(name);
//			return c;
//		}
//		
//		/** Global singleton instance */
//		public static final RecordingClassLoader instance =
//		  new RecordingClassLoader(ClassLoader.getSystemClassLoader());
//
//		/** Install our classloader as the system default */
//		public static void install() throws IllegalAccessException {
//			Field parent;
//			try {
//				parent = ClassLoader.class.getDeclaredField("scl");
//			} catch (Exception e) {
//				throw new IllegalAccessException("Cannot set system ClassLoader field");
//			}
//			parent.setAccessible(true);
//			parent.set(null, instance);
//		}
//	}
	
	//
	// Helper classes
	//
	
	/**
	 * Log signals
	 */
	private static class SignalLogger implements SignalHandler {
		private final String name;
		private SignalHandler oldHandler;
		
		public SignalLogger(String name) {
			this.name = name;
		}
		
		public void register() {
			oldHandler = Signal.handle(new Signal(name), this);
		}
		
		public void handle(Signal signal) {
			if (signal.getName().equals("INT") || signal.getName().equals("TERM")) {
				exitcode = "SIG"+signal.getName();
			} else {
				streams.log.line("signal", "", "name", signal.getName());
			}
			
			if (oldHandler != null) {
				oldHandler.handle(signal);
			}
		}
	}
	
	/**
	 * Log the program exit signal.
	 */
	private static class ExitLogger extends SecurityManager {
		private SecurityManager original;
		
		public void register() {
			this.original = System.getSecurityManager();
			System.setSecurityManager(this);
		}
		
	    /**
	     * Delegates security check to existing manager.
	     */
		@Override
	    public void checkPermission(Permission permission) {
	        if (original != null) {
	            original.checkPermission(permission);
	        }
	    }
		
		@Override
		public void checkExit(int status) {
			// record the exit code
			StringBuilder builder = new StringBuilder();
			for (StackTraceElement trace : ReflectionUtils.getTrace()) {
				builder.append(trace).append("\n");
			}
			exitcode = Integer.toString(status);
			exitbody = builder.toString();
			
			// this line must be here or our exit handler doesn't run
			super.checkExit(status);

			// these lines cannot be here or the program won't terminate
			// if (original != null) {
			// 	original.checkExit(status);
			// }
		}
	}

	/**
	 * Output stream that branches by sending bytes to N inner OutputStreams.
	 */
	private static class BranchedOutputStream extends OutputStream {

		private final OutputStream[] streams;
		
		public BranchedOutputStream(OutputStream ... streams) {
			this.streams = streams;
		}
		
		@Override
		public void write(int b) throws IOException {
			for (OutputStream stream : streams) {
				stream.write(b);
			}
		}
		
		@Override
		public void write(byte[] buf) throws IOException {
			for (OutputStream stream : streams) {
				stream.write(buf);
			}
		}
		
		@Override
		public void write(byte[] buf, int off, int len) throws IOException {
			for (OutputStream stream : streams) {
				stream.write(buf, off, len);
			}
		}
		
		@Override
		public void flush() throws IOException {
			for (OutputStream stream : streams) {
				stream.flush();
			}
		}
		
		@Override
		public void close() throws IOException {
			for (OutputStream stream : streams) {
				stream.close();
			}
		}
	}
	
	/** Print stream that sends output to a bunch of other PrintStreams */
	private static class BranchedPrintStream extends PrintStream {

		private final PrintStream[] streams;
		
		public BranchedPrintStream(PrintStream ... streams) {
			super(new BranchedOutputStream(streams));
			this.streams = streams;
		}
		
		@Override public void flush() {
			for (PrintStream stream : streams) stream.flush();
		}
		
		@Override public void close() {
			for (PrintStream stream : streams) stream.close();
		}
		
		@Override public boolean checkError() {
			boolean check = false;
			for (PrintStream stream : streams) check |= stream.checkError();
			return check;
		}
		
		@Override public void write(int b) {
			for (PrintStream stream : streams) stream.write(b);
		}
		
		@Override public void write(byte buf[], int off, int len) {
			for (PrintStream stream : streams) stream.write(buf, off, len);
		}
		
		@Override public void print(boolean b) {
			for (PrintStream stream : streams) stream.print(b);
		}
		
		@Override public void print(char c) {
			for (PrintStream stream : streams) stream.print(c);
		}
		
		@Override public void print(int i) {
			for (PrintStream stream : streams) stream.print(i);
		}
		
		@Override public void print(long l) {
			for (PrintStream stream : streams) stream.print(l);
		}
		
		@Override public void print(float f) {
			for (PrintStream stream : streams) stream.print(f);
		}
		
		@Override public void print(double d) {
			for (PrintStream stream : streams) stream.print(d);
		}
		
		@Override public void print(char s[]) {
			for (PrintStream stream : streams) stream.print(s);
		}
		
		@Override public void print(String s) {
			for (PrintStream stream : streams) stream.print(s);
		}
		
		@Override public void print(Object obj) {
			for (PrintStream stream : streams) stream.print(obj);
		}
		
		@Override public void println() {
			for (PrintStream stream : streams) stream.println();
		}
		
		@Override public void println(boolean x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(char x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(int x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(long x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(float x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(double x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(char x[]) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(String x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public void println(Object x) {
			for (PrintStream stream : streams) stream.println(x);
		}
		
		@Override public PrintStream format(String format, Object ... args) {
			for (PrintStream stream : streams) stream.format(format, args);
			return this;
		}
		
		@Override public PrintStream format(Locale l, String format, Object ... args) {
			for (PrintStream stream : streams) stream.format(l, format, args);
			return this;
		}
		
		@Override public PrintStream append(CharSequence csq) {
			for (PrintStream stream : streams) stream.append(csq);
			return this;
		}
		
		@Override public PrintStream append(CharSequence csq, int start, int end) {
			for (PrintStream stream : streams) stream.append(csq, start, end);
			return this;
		}
		
		@Override public PrintStream append(char c) {
			for (PrintStream stream : streams) stream.append(c);
			return this;
		}
	}
}
