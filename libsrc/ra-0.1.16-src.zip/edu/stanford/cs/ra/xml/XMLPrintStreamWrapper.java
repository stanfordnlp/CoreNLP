/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Locale;

import edu.stanford.cs.ra.RA;


/**
 * A faux PrintStream that actually redirects contents to lines in a given
 * {@link XMLStream} marked with a given tag.  Used, e.g. to create stdout and
 * stderr lines by RA.
 * 
 * @author dramage
 */
public class XMLPrintStreamWrapper extends PrintStream {
	/** Tag to use when flushing a line to the XMLBuilder */
	private final String tag;

	/** XML sink */
	private final XMLStream out;

	/** Queue */
	private final StringBuilder queue;
	
	/** Are we open */
	private boolean isOpen = true;
	
	/**
	 * Initializes a PrintStream whose contents will be lines sent to
	 * the given XMLBuilder with the given tag.
	 */
	public XMLPrintStreamWrapper(String tag, XMLStream out) {
		super(new OutputStream() {
			@Override
			public void write(int b) throws IOException {
				throw new RuntimeException("Unexpected acccess to underlying OutputStream.  This is a bug!  Please report it to the authors of RA.");
			}
		});
		this.tag = tag;
		this.out = out;
		this.queue = new StringBuilder();
	}

	/** Writes the given char without calling trace() */
	private final void writeNoTrace(char c) {
		if (isOpen) {
			if (c == '\n') {
				flush();
			} else if (c != '\r') {
				queue.append(c);
			}
		}
	}

	/** Writes the given char array without calling trace(), handling unicode */
	private final void writeNoTrace(char[] c) {
		if (isOpen) {
			for (int i = 0; i < c.length; ) {
				int codePoint = Character.codePointAt(c, i);
				if (codePoint == '\n') {
					flush();
				} else if (codePoint != '\r') {
					queue.appendCodePoint(codePoint);
				}
				i += Character.charCount(codePoint);
			}
		}
	}
	
	/** Writes the given byte without calling trace() */
	private final void writeNoTrace(int b) {
		writeNoTrace((char)b);
	}

	@Override
	public void write(int b) {
		synchronized (this) {
			writeNoTrace(b);
		}
	}

	@Override
	public void write(byte[] buf) {
		synchronized (this) {
			for (byte b : buf) {
				writeNoTrace(b);
			}
		}
	}

	@Override
	public void write(byte[] buf, int off, int len) {
		synchronized (this) {
			for (int i = off; i < len; i++) {
				writeNoTrace(buf[i]);
			}
		}
	}

	@Override
	public void print(char c) {
		if (isOpen) {
			synchronized (this) {
				if (c == '\n') {
					flush();
				} else {
					queue.append(c);
				}
			}
		}
	}

	@Override
	public void print(boolean b) {
		if (isOpen) {
			synchronized (this) {
				queue.append(b);
			}
		}
	}

	@Override
	public void print(int i) {
		if (isOpen) {
			synchronized (this) {
				queue.append(i);
			}
		}
	}

	@Override
	public void print(long l) {
		if (isOpen) {
			synchronized (this) {
				queue.append(l);
			}
		}
	}

	@Override
	public void print(float f) {
		if (isOpen) {
			synchronized (this) {
				queue.append(f);
			}
		}
	}

	@Override
	public void print(double d) {
		if (isOpen) {
			synchronized (this) {
				queue.append(d);
			}
		}
	}

	@Override
	public void print(char s[]) {
		synchronized (this) { writeNoTrace(s); }
	}

	@Override
	public void print(String s) {
		print(s.toCharArray());
	}

	@Override
	public void print(Object obj) {
		print(obj.toString());
	}
	
	@Override
	public void println() {
		synchronized (this) {
			flush();
		}
	}
	
	@Override
	public void println(boolean x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(char x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(int x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(long x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(float x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(double x) {
		synchronized (this) {
			queue.append(x);
			flush();
		}
	}
	
	@Override
	public void println(char x[]) {
		synchronized (this) {
			print(x);
			flush();
		}
	}
	
	@Override
	public void println(String x) {
		synchronized (this) {
			print(x);
			flush();
		}
	}
	
	@Override
	public void println(Object x) {
		synchronized (this) {
			print(x);
			flush();
		}
	}
	
	@Override
	public PrintStream printf(String format, Object ... args) {
		print(String.format(format, args));
		return this;
	}
	
	@Override
	public PrintStream printf(Locale l, String format, Object ... args) {
		print(String.format(l, format, args));
		return this;
	}
	
	@Override
	public PrintStream format(String format, Object ... args) {
		print(String.format(format, args));
		return this;
	}
	
	@Override
	public PrintStream format(Locale l, String format, Object ... args) {
		print(String.format(l, format, args));
		return this;
	}
	
	@Override
	public PrintStream append(CharSequence csq) {
		print(csq.toString());
		return this;
	}
	
	@Override
	public PrintStream append(CharSequence csq, int start, int end) {
		print(csq.subSequence(start, end));
		return this;
	}
	
	@Override
	public PrintStream append(char c) {
		print(c);
		return this;
	}
	
	@Override
	public void close() {
		isOpen = false;
		super.close();
	}
	
	/**
	 * Flush the queue to the XMLBuilder as a single line.
	 */
	@Override
	public void flush() {
		if (queue.length() > 0) {
			out.line(tag, queue.toString());
			queue.setLength(0);
		}
	}
}