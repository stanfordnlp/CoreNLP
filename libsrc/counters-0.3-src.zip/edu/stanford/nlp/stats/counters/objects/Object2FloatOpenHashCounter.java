

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/* 
 * Counters: Fast & compact NLP data structures for Java
 * Based on fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2007 Daniel Ramage
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.objects;
import it.unimi.dsi.fastutil.objects.*;
import java.util.Map;
import java.util.NoSuchElementException;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.AbstractObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
/**
 * A type-specific counter; provides a {@link Map} from key to numeric values that can be incremented and decremented, along with a running total.
 *
 * @see Map
 * @author dramage
 */
/**
 * A Counter implementation backed by an OpenHashMap.
 * 
 * TODO: worry about readObject
 */
public class Object2FloatOpenHashCounter <K> extends Object2FloatOpenHashMap <K> implements Object2FloatCounter <K> {
 public Object2FloatOpenHashCounter() {
  super();
 }
 /** Constructor for given expected number of entries */
 public Object2FloatOpenHashCounter(int n) {
  super(n);
 }
 /** Constructor for given expected number of entries, load factor */
 public Object2FloatOpenHashCounter(int n, float f) {
  super(n,f);
 }
 /** Copy constructor */
 public Object2FloatOpenHashCounter(Object2FloatCounter <K> counter) {
  super(counter);
  this.total = counter.total();
 }
 /** Copy constructor */
 public Object2FloatOpenHashCounter(Map<K,? extends Number> map) {
  super(map.size());
  for (Map.Entry<K,? extends Number> entry : map.entrySet()) {
   put((K)entry.getKey(), entry.getValue().floatValue());
  }
 }
 protected float total;
 @Override
 public float put(final K k, final float v) {
  final float rv = super.put(k,v);
  total = total - rv + v;
  return rv;
 }
 @Override
 public Float put(final K ok, final Float ov) {
  final Float rv = super.put(ok,ov);
  total = total - rv + ov;
  return rv;
 }
 @Override
 public void clear() {
  super.clear();
  total = 0;
 }
 /** The entry class for a hash map does not record key and value, but
	 * rather the position in the hash table of the corresponding entry. This
	 * is necessary so that calls to {@link java.util.Map.Entry#setValue(Object)} are reflected in
	 * the map */
 private final class MapEntry implements Object2FloatMap.Entry <K>, Map.Entry<K, Float> {
  private int index;
  MapEntry( final int index ) {
   this.index = index;
  }
  public K getKey() {
   return (key[ index ]);
  }




  public Float getValue() {
   return (Float.valueOf(value[ index ]));
  }


  public float getFloatValue() {
   return value[ index ];
  }


  public float setValue( final float v ) {
   final float oldValue = value[ index ];
   value[ index ] = v;
   total = total - oldValue + v;
   return oldValue;
  }



  public Float setValue( final Float v ) {
   return (Float.valueOf(setValue( ((v).floatValue()) )));
  }



  @SuppressWarnings("unchecked")
  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<K, Float> e = (Map.Entry<K, Float>)o;

   return ( (key[ index ]) == null ? ((e.getKey())) == null : (key[ index ]).equals((e.getKey())) ) && ( (value[ index ]) == (((e.getValue()).floatValue())) );
  }

  public int hashCode() {
   return ( (key[ index ]) == null ? 0 : (key[ index ]).hashCode() ) ^ it.unimi.dsi.fastutil.HashCommon.float2int(value[ index ]);
  }


  public String toString() {
   return key[ index ] + "->" + value[ index ];
  }
 }

 /** An iterator over a hash map. */

 private class MapIterator {
  /** The index of the next entry to be returned. */
  int pos = 0;
  /** The index of the last entry that has been returned. */
  int last = -1;
  /** A downward counter measuring how many entries have been returned. */
  int c = count;

  {
   final byte state[] = Object2FloatOpenHashCounter.this.state;
   final int n = state.length;

   if ( c != 0 ) while( pos < n && state[ pos ] != OCCUPIED ) pos++;
  }

  public boolean hasNext() {
   return c != 0 && pos < Object2FloatOpenHashCounter.this.state.length;
  }

  public int nextEntry() {
   final byte state[] = Object2FloatOpenHashCounter.this.state;
   final int n = state.length;

   if ( ! hasNext() ) throw new NoSuchElementException();
   last = pos;
   if ( --c != 0 ) do pos++; while( pos < n && state[ pos ] != OCCUPIED );

   return last;
  }

  @SuppressWarnings("unchecked")
  public void remove() {
   if (last == -1) throw new IllegalStateException();
   if (state[last] == OCCUPIED) {
    total -= value[last];
   }

   state[last] = REMOVED;

   key[last] = (K) HashCommon.REMOVED;





   count--;
  }

  public int skip( final int n ) {
   int i = n;
   while( i-- != 0 && hasNext() ) nextEntry();
   return n - i - 1;
  }
 }


 private class EntryIterator extends MapIterator implements ObjectIterator<Object2FloatMap.Entry <K> > {
  public Object2FloatMap.Entry <K> next() {
   return new MapEntry( nextEntry() );
  }
 }

 public static class BasicEntry <K> implements Object2FloatMap.Entry <K> {
  protected K key;
  protected float value;

  public BasicEntry( final K key, final Float value ) {
   this.key = (key);
   this.value = ((value).floatValue());
  }



  public BasicEntry( final K key, final float value ) {
   this.key = key;
   this.value = value;
  }



  public K getKey() {
   return (key);
  }







  public Float getValue() {
   return (Float.valueOf(value));
  }


  public float getFloatValue() {
   return value;
  }


  public float setValue( final float value ) {
   throw new UnsupportedOperationException();
  }



  public Float setValue( final Float value ) {
   return Float.valueOf(setValue(value.floatValue()));
  }



  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<?,?> e = (Map.Entry<?,?>)o;

   return ( (key) == null ? ((e.getKey())) == null : (key).equals((e.getKey())) ) && ( (value) == (((((Float)(e.getValue())).floatValue()))) );
  }

  public int hashCode() {
   return ( (key) == null ? 0 : (key).hashCode() ) ^ it.unimi.dsi.fastutil.HashCommon.float2int(value);
  }


  public String toString() {
   return key + "->" + value;
  }
 }


 private class FastEntryIterator extends MapIterator implements ObjectIterator<Object2FloatMap.Entry <K> > {
  final BasicEntry <K> entry = new BasicEntry <K> ( (null), (0) );
  public BasicEntry <K> next() {
   final int e = nextEntry();
   entry.key = key[ e ];
   entry.value = value[ e ];
   return entry;
  }
 }

 @Override
 public Float remove( final Object ok ) {
  final Float rv = super.remove(ok);
  if (rv != null) {
   total -= rv;
  }
  return rv;
 }

 @Override
 public float removeFloat(final Object k) {
  final int oldcount = count;
  final float rv = super.removeFloat(k);
  if (oldcount < count) {
   total -= rv;
  }
  return rv;
 }

 @SuppressWarnings("unchecked")
 @Override
 public Object clone() {
  Object2FloatOpenHashCounter c = (Object2FloatOpenHashCounter)super.clone();
  c.total = this.total;
  return c;
 }


 private final class MapEntrySet extends AbstractObjectSet<Object2FloatMap.Entry <K> > implements Object2FloatMap.FastEntrySet <K> {

  public ObjectIterator<Object2FloatMap.Entry <K> > iterator() {
   return new EntryIterator();
  }

  public ObjectIterator<Object2FloatMap.Entry <K> > fastIterator() {
   return new FastEntryIterator();
  }

  @SuppressWarnings("unchecked")
  public boolean contains( final Object o ) {
   if (!(o instanceof Object2FloatMap.Entry)) return false;
   final Object2FloatMap.Entry <K> e = (Object2FloatMap.Entry <K>)o;
   final int i = findKey( (e.getKey()) );
   return i >= 0 && ( (value[ i ]) == (((e.getValue()).floatValue())) );
  }

  @SuppressWarnings("unchecked")
  public boolean remove( final Object o ) {
   if (!(o instanceof Object2FloatMap.Entry)) return false;
   final Object2FloatMap.Entry <K> e = (Object2FloatMap.Entry <K>)o;
   final int i = findKey( (e.getKey()) );
   if ( i >= 0 ) Object2FloatOpenHashCounter.this.remove( e.getKey() );
   return i >= 0;
  }

  public int size() {
   return count;
  }

  public void clear() {
   Object2FloatOpenHashCounter.this.clear();
  }

 }

 public Object2FloatMap.FastEntrySet <K> object2FloatEntrySet() {
  if ( entries == null ) entries = new MapEntrySet();
  return entries;
 }

 /**
	 * Increments the value associated with the given key by <code>+adjustAmount</code>,
 	 * returning the value in the map before the increment.  This method is faster than
 	 * incrementing a value in the map with two calls - once to get and once to put -
	 * because it caches the correct insertion point into the hashmap.
	 */
 protected float adjust(final K k, final float adjustAmount) {
  final int i = findInsertionPoint( k );

  total += adjustAmount;

  if (i < 0) {
   final float oldValue = value[-i-1];
   value[-i-1] += adjustAmount;
   return oldValue;
  }

  if ( state[i] == FREE ) free--;
  state[i] = OCCUPIED;
  key[i] = k;
  value[i] = adjustAmount;
  if ( ++count >= maxFill ) {
   int newP = Math.min( p + growthFactor, PRIMES.length - 1 );
   // Just to be sure that size changes when p is very small.
   while( PRIMES[ newP ] == PRIMES[ p ] ) newP++;
   rehash( newP ); // Table too filled, let's rehash
  }
  if ( free == 0 ) rehash( p );
  return defRetValue;
 }
 /** {@inheritDoc} */
 public void incrementAll( Object2FloatMap <K> counter ) {
  for (Object2FloatMap.Entry <K> entry : counter.object2FloatEntrySet()) {
   this.increment(entry.getKey(), entry.getFloatValue());
  }
 }
 /** {@inheritDoc} */
 public float increment( K key, float amount ) {
  return adjust(key, amount) + amount;
 }
 /** {@inheritDoc} */
 public float increment( K key ) {
  return adjust(key, 1f) + 1f;
 }
 /** {@inheritDoc} */
 public float decrement( K key, float amount ) {
  return adjust(key, -amount) - amount;
 }
 /** {@inheritDoc} */
 public float decrement( K key ) {
  return adjust(key, -1f) - 1f;
 }
 /** {@inheritDoc} */
 public float total() {
  return total;
 }
}
