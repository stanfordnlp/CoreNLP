/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * A ResourceSet backed by a directory on disk.  Path names ending in
 * ".gz" are automatically gzipped or ungzipped as necessary.
 * 
 * @author dramage
 */
public class FileResourceSet implements ResourceSet {
	private static final long serialVersionUID = 1L;
	
	/** Root directory of the resource tree */
	public final File root;
	
	/**
	 * Initializes this resource set to read and write files relative
	 * to the given root.
	 */
	public FileResourceSet(File root) {
		if (root.exists() && !root.isDirectory()) {
			throw new QuietIOException("Existing path "+root+" is not a directory");
		}
		this.root = root;
	}
	
	/** Returns a FileInputStream for the given resource */
	public InputStream getInputStream(String path) throws QuietIOException {
		return IOUtils.openFile(getFile(path, false));
	}

	/** Returns a FileOutputStream for the given resource */
	public OutputStream getOutputStream(String path) throws QuietIOException {
		try {
			getFile(path,true).getParentFile().mkdirs();
			FileOutputStream fis = new FileOutputStream(getFile(path,true));
			if (path.endsWith(".gz")) {
				try {
					return new GZIPOutputStream(fis);
				} catch (IOException e) {
					throw new QuietIOException(e);
				}
			}
			return fis;
		} catch (FileNotFoundException e) {
			throw new QuietIOException(e);
		}
	}

	/** Returns true if the given resource exists */
	public boolean hasResource(String path) {
		return getFile(path,false).exists();
	}

	public String[] listResources() {
		return listResources("");
	}
	
	/** Returns the list of sub-resource names of the given resource */
	public String[] listResources(String path) {
		if (getFile(path,false).isDirectory()) {
			String[] files = getFile(path,false).list();
			if (path.length() > 0 && !path.endsWith("/")) {
				path += "/";
			}
			for (int i = 0; i < files.length; i++) {
				files[i] = path+files[i];
				if (getFile(files[i],false).isDirectory()) {
					files[i] += "/";
				}
			}
			return files;
		} else {
			return new String[0];
		}
	}

	public URI getInputURI(String path) {
		return getFile(path,false).toURI();
	}

	public URI getOutputURI(String path) {
		return getFile(path,false).toURI();
	}

	/**
	 * Returns the File corresponding to the root of this resource set
	 * plus the given path.
	 */
	private File getFile(String path, boolean mkdirs) {
		if (mkdirs && !root.exists()) {
			throw new QuietIOException("FileResourceSet root "+root+" does not exist");
		}
		File file = root;
		List<String> segments = Stringify.escapedSplit(String.class, path, '/');
		for (int i = 0; i < segments.size(); i++) {
			file = new File(file,segments.get(i));
			if (i + 1 < segments.size() && mkdirs) {
				file.mkdir();
			}
		}
		return file;
	}
	
	@Override
	public String toString() {
		return root.toString();
	}
}