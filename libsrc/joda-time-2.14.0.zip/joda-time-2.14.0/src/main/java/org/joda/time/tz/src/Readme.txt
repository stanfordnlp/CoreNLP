The data files in this directory were obtained from global-tz,
https://github.com/JodaOrg/global-tz, see pom.xml for the version.
These files are declared to be in the Public Domain.
