/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.Map;

/**
 * A source of partial computation results indexed by {@link StageLineage}.
 * 
 * @author dramage
 */
public interface CheckpointSet {

	/**
	 * Returns true if the workbook contains a checkpoint with compatible
	 * lineage.
	 */
	public abstract boolean hasCheckpoint(StageLineage lineage);

	/**
	 * Returns the saved context for the given linage.
	 * Assumes hasCheckpoint(lineage) is true.
	 */
	public abstract Map<String, Object> loadCheckpoint(StageLineage lineage);

	/**
	 * Creates a checkpoint for the given set of stages using the given context.
	 */
	public abstract void createCheckpoint(StageLineage lineage,
			Map<String, Object> context);

}
