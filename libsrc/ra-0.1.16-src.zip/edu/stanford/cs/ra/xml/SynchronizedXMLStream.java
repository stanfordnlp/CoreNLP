/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.util.List;

import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * Synchronized wrapper for an XMLStream.
 * 
 * @author dramage
 */
public class SynchronizedXMLStream implements XMLStream {

	/** Wrapped XML stream */
	private XMLStream stream;

	public SynchronizedXMLStream(XMLStream stream) {
		this.stream = stream;
	}
	
	public synchronized XMLStream begin(String tag, Object... args) {
		stream.begin(tag, args);
		return this;
	}

	public synchronized XMLStream end(String tag) {
		stream.end(tag);
		return this;
	}

	public synchronized XMLStream line(String tag, Object body, Object... args) {
		stream.line(tag, body, args);
		return this;
	}

	public synchronized XMLStream xml(EscapedXML xml) {
		stream.xml(xml);
		return this;
	}
	
	public synchronized void close() {
		stream.close();
	}
	
	/**
	 * Calls wrapped stream's line() immediately before closing the stream.
	 */
	public synchronized void closeWith(String tag, Object body, Object... args) {
		stream.line(tag, body, args);
		stream.close();
	}

	public synchronized List<String> getTagStack() {
		return stream.getTagStack();
	}

	/** Returns the wrapped stream */
	public XMLStream getWrappedStream() {
		return stream;
	}
	
	/**
	 * Sets the wrapped stream or throws QuietIOException if the tag
	 * stack is not empty.
	 */
	public void setWrappedStream(XMLStream stream) {
		if (stream != null && stream.getTagStack().size() > 0) {
			throw new QuietIOException("Cannot changed wrapped stream: XML tags are open");
		}
			
		this.stream = stream;
	}
}
