

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/* 
 * Counters: Fast & compact NLP data structures for Java
 * Based on fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2007 Daniel Ramage
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.doubles;
import it.unimi.dsi.fastutil.doubles.*;
import java.util.Map;
import java.util.NoSuchElementException;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.AbstractObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
/**
 * A type-specific counter; provides a {@link Map} from key to numeric values that can be incremented and decremented, along with a running total.
 *
 * @see Map
 * @author dramage
 */
/**
 * A Counter implementation backed by an OpenHashMap.
 * 
 * TODO: worry about readObject
 */
public class Double2FloatOpenHashCounter extends Double2FloatOpenHashMap implements Double2FloatCounter {
 public Double2FloatOpenHashCounter() {
  super();
 }
 /** Constructor for given expected number of entries */
 public Double2FloatOpenHashCounter(int n) {
  super(n);
 }
 /** Constructor for given expected number of entries, load factor */
 public Double2FloatOpenHashCounter(int n, float f) {
  super(n,f);
 }
 /** Copy constructor */
 public Double2FloatOpenHashCounter(Double2FloatCounter counter) {
  super(counter);
  this.total = counter.total();
 }
 /** Copy constructor */
 public Double2FloatOpenHashCounter(Map<Double,? extends Number> map) {
  super(map.size());
  for (Map.Entry<Double,? extends Number> entry : map.entrySet()) {
   put((double)entry.getKey(), entry.getValue().floatValue());
  }
 }
 protected float total;
 @Override
 public float put(final double k, final float v) {
  final float rv = super.put(k,v);
  total = total - rv + v;
  return rv;
 }
 @Override
 public Float put(final Double ok, final Float ov) {
  final Float rv = super.put(ok,ov);
  total = total - rv + ov;
  return rv;
 }
 @Override
 public void clear() {
  super.clear();
  total = 0;
 }
 /** The entry class for a hash map does not record key and value, but
	 * rather the position in the hash table of the corresponding entry. This
	 * is necessary so that calls to {@link java.util.Map.Entry#setValue(Object)} are reflected in
	 * the map */
 private final class MapEntry implements Double2FloatMap.Entry , Map.Entry<Double, Float> {
  private int index;
  MapEntry( final int index ) {
   this.index = index;
  }
  public Double getKey() {
   return (Double.valueOf(key[ index ]));
  }
  public double getDoubleKey() {
      return key[ index ];
  }
  public Float getValue() {
   return (Float.valueOf(value[ index ]));
  }

  public float getFloatValue() {
   return value[ index ];
  }


  public float setValue( final float v ) {
   final float oldValue = value[ index ];
   value[ index ] = v;
   total = total - oldValue + v;
   return oldValue;
  }



  public Float setValue( final Float v ) {
   return (Float.valueOf(setValue( ((v).floatValue()) )));
  }



  @SuppressWarnings("unchecked")
  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<Double, Float> e = (Map.Entry<Double, Float>)o;

   return ( (key[ index ]) == (((e.getKey()).doubleValue())) ) && ( (value[ index ]) == (((e.getValue()).floatValue())) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.double2int(key[ index ]) ^ it.unimi.dsi.fastutil.HashCommon.float2int(value[ index ]);
  }


  public String toString() {
   return key[ index ] + "->" + value[ index ];
  }
 }

 /** An iterator over a hash map. */

 private class MapIterator {
  /** The index of the next entry to be returned. */
  int pos = 0;
  /** The index of the last entry that has been returned. */
  int last = -1;
  /** A downward counter measuring how many entries have been returned. */
  int c = count;

  {
   final byte state[] = Double2FloatOpenHashCounter.this.state;
   final int n = state.length;

   if ( c != 0 ) while( pos < n && state[ pos ] != OCCUPIED ) pos++;
  }

  public boolean hasNext() {
   return c != 0 && pos < Double2FloatOpenHashCounter.this.state.length;
  }

  public int nextEntry() {
   final byte state[] = Double2FloatOpenHashCounter.this.state;
   final int n = state.length;

   if ( ! hasNext() ) throw new NoSuchElementException();
   last = pos;
   if ( --c != 0 ) do pos++; while( pos < n && state[ pos ] != OCCUPIED );

   return last;
  }

  @SuppressWarnings("unchecked")
  public void remove() {
   if (last == -1) throw new IllegalStateException();
   if (state[last] == OCCUPIED) {
    total -= value[last];
   }

   state[last] = REMOVED;







   count--;
  }

  public int skip( final int n ) {
   int i = n;
   while( i-- != 0 && hasNext() ) nextEntry();
   return n - i - 1;
  }
 }


 private class EntryIterator extends MapIterator implements ObjectIterator<Double2FloatMap.Entry > {
  public Double2FloatMap.Entry next() {
   return new MapEntry( nextEntry() );
  }
 }

 public static class BasicEntry implements Double2FloatMap.Entry {
  protected double key;
  protected float value;

  public BasicEntry( final Double key, final Float value ) {
   this.key = ((key).doubleValue());
   this.value = ((value).floatValue());
  }



  public BasicEntry( final double key, final float value ) {
   this.key = key;
   this.value = value;
  }



  public Double getKey() {
   return (Double.valueOf(key));
  }


  public double getDoubleKey() {
   return key;
  }


  public Float getValue() {
   return (Float.valueOf(value));
  }


  public float getFloatValue() {
   return value;
  }


  public float setValue( final float value ) {
   throw new UnsupportedOperationException();
  }



  public Float setValue( final Float value ) {
   return Float.valueOf(setValue(value.floatValue()));
  }



  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<?,?> e = (Map.Entry<?,?>)o;

   return ( (key) == (((((Double)(e.getKey())).doubleValue()))) ) && ( (value) == (((((Float)(e.getValue())).floatValue()))) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.double2int(key) ^ it.unimi.dsi.fastutil.HashCommon.float2int(value);
  }


  public String toString() {
   return key + "->" + value;
  }
 }


 private class FastEntryIterator extends MapIterator implements ObjectIterator<Double2FloatMap.Entry > {
  final BasicEntry entry = new BasicEntry ( (0), (0) );
  public BasicEntry next() {
   final int e = nextEntry();
   entry.key = key[ e ];
   entry.value = value[ e ];
   return entry;
  }
 }

 @Override
 public Float remove( final Object ok ) {
  final Float rv = super.remove(ok);
  if (rv != null) {
   total -= rv;
  }
  return rv;
 }

 @Override
 public float remove(final double k) {
  final int oldcount = count;
  final float rv = super.remove(k);
  if (oldcount < count) {
   total -= rv;
  }
  return rv;
 }

 @SuppressWarnings("unchecked")
 @Override
 public Object clone() {
  Double2FloatOpenHashCounter c = (Double2FloatOpenHashCounter)super.clone();
  c.total = this.total;
  return c;
 }


 private final class MapEntrySet extends AbstractObjectSet<Double2FloatMap.Entry > implements Double2FloatMap.FastEntrySet {

  public ObjectIterator<Double2FloatMap.Entry > iterator() {
   return new EntryIterator();
  }

  public ObjectIterator<Double2FloatMap.Entry > fastIterator() {
   return new FastEntryIterator();
  }

  @SuppressWarnings("unchecked")
  public boolean contains( final Object o ) {
   if (!(o instanceof Double2FloatMap.Entry)) return false;
   final Double2FloatMap.Entry e = (Double2FloatMap.Entry )o;
   final int i = findKey( ((e.getKey()).doubleValue()) );
   return i >= 0 && ( (value[ i ]) == (((e.getValue()).floatValue())) );
  }

  @SuppressWarnings("unchecked")
  public boolean remove( final Object o ) {
   if (!(o instanceof Double2FloatMap.Entry)) return false;
   final Double2FloatMap.Entry e = (Double2FloatMap.Entry )o;
   final int i = findKey( ((e.getKey()).doubleValue()) );
   if ( i >= 0 ) Double2FloatOpenHashCounter.this.remove( e.getKey() );
   return i >= 0;
  }

  public int size() {
   return count;
  }

  public void clear() {
   Double2FloatOpenHashCounter.this.clear();
  }

 }

 public Double2FloatMap.FastEntrySet double2FloatEntrySet() {
  if ( entries == null ) entries = new MapEntrySet();
  return entries;
 }

 /**
	 * Increments the value associated with the given key by <code>+adjustAmount</code>,
 	 * returning the value in the map before the increment.  This method is faster than
 	 * incrementing a value in the map with two calls - once to get and once to put -
	 * because it caches the correct insertion point into the hashmap.
	 */
 protected float adjust(final double k, final float adjustAmount) {
  final int i = findInsertionPoint( k );

  total += adjustAmount;

  if (i < 0) {
   final float oldValue = value[-i-1];
   value[-i-1] += adjustAmount;
   return oldValue;
  }

  if ( state[i] == FREE ) free--;
  state[i] = OCCUPIED;
  key[i] = k;
  value[i] = adjustAmount;
  if ( ++count >= maxFill ) {
   int newP = Math.min( p + growthFactor, PRIMES.length - 1 );
   // Just to be sure that size changes when p is very small.
   while( PRIMES[ newP ] == PRIMES[ p ] ) newP++;
   rehash( newP ); // Table too filled, let's rehash
  }
  if ( free == 0 ) rehash( p );
  return defRetValue;
 }
 /** {@inheritDoc} */
 public void incrementAll( Double2FloatMap counter ) {
  for (Double2FloatMap.Entry entry : counter.double2FloatEntrySet()) {
   this.increment(entry.getDoubleKey(), entry.getFloatValue());
  }
 }
 /** {@inheritDoc} */
 public float increment( double key, float amount ) {
  return adjust(key, amount) + amount;
 }
 /** {@inheritDoc} */
 public float increment( double key ) {
  return adjust(key, 1f) + 1f;
 }
 /** {@inheritDoc} */
 public float decrement( double key, float amount ) {
  return adjust(key, -amount) - amount;
 }
 /** {@inheritDoc} */
 public float decrement( double key ) {
  return adjust(key, -1f) - 1f;
 }
 /** {@inheritDoc} */
 public float total() {
  return total;
 }
}
