/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Result object returned from an ArgumentPopulator.
 * 
 * @author dramage
 */
public class ArgumentPopulatorResult implements Serializable {
	private static final long serialVersionUID = 1L;

	/** Set of ArgumentBoxes populated. */
	private final Collection<ArgumentBox> boxes;
	
	/** Set of arguments actually populated. */
	private final Set<ArgumentInfo> populated =
		new HashSet<ArgumentInfo>();
	
	/** List of errors and warnings generated while populating arguments. */
	private final Collection<String>
		userErrors = new LinkedHashSet<String>(),
		userWarnings = new LinkedHashSet<String>();
	
	/** List of errors generated while populating arguments. */
	private final Collection<String>
		autoErrors = new LinkedHashSet<String>(),
		autoWarnings = new LinkedHashSet<String>();
	
	/** Array(s) of raw command line arguments provided */
	private final List<String[]>  commandLineArgumentsProvided =
		new LinkedList<String[]>();
	
	/**
	 * Array(s) co-indexing elements of {@link #commandLineArgumentsProvided}
	 * that say which of those strings were used.
	 */
	private final List<boolean[]> commandLineArgumentsUsed =
		new LinkedList<boolean[]>();
	
	public ArgumentPopulatorResult(Collection<ArgumentBox> boxes) {
		this.boxes = boxes;
	}
	
	/**
	 * Runs argcheck methods and tests argument policies.  Throws an
	 * ArgumentException upon error.
	 */
	void check() throws ArgumentException {
		// see if all required values provided
		for (ArgumentBox box : boxes) {
			for (ArgumentInfo arg : box.getArguments()) {
				if (!populated.contains(arg)) {
					switch (arg.getPolicy()) {
					case REQUIRED:
						autoErrors.add("Missing required value for "+arg);
						break;
					case RECOMMENDED:
						autoWarnings.add("Missing recommended value for "+arg);
						break;
					default:
						break;
					}
				}
			}
		}
		
		if (userErrors.isEmpty() && autoErrors.isEmpty()) {
			// if no syntax errors or missing arguments, collect ArgCheck
			// exceptions
			for (ArgumentBox box : boxes) {
				try {
					box.check();
				} catch (ArgumentException e) {
					autoErrors.add(box.getName()+": "+e.getMessage());
				}
			}
		}
		
		if (!(autoErrors.isEmpty() && userErrors.isEmpty())) {
			throw new ArgumentException(this);
		}
	}
	
	/** Adds the given error message to the errors set. */
	void addError(String error) {
		userErrors.add(error);
	}
	
	/** Adds the given warning message to the warnings set. */
	void addWarning(String warning) {
		userWarnings.add(warning);
	}
	
	/**
	 * Registers the given arguments as having participated, and which ones were
	 * used.
	 */
	void addCommandLineArguments(String[] arguments, boolean[] used) {
		if (arguments.length != used.length) {
			throw new IllegalArgumentException(
					"Unexpected discrepancy in array sizes.  Report this as a bug");
		}
		commandLineArgumentsProvided.add(arguments);
		commandLineArgumentsUsed.add(used);
	}
	
	/** Records the given ArgumentInfo as having been populated. */
	void setPopulated(ArgumentInfo arg) {
		populated.add(arg);
	}
	
	/** Adds warnings, errors, etc., from the given result. */
	void addFromResult(ArgumentPopulatorResult result) {
		if (result == null) {
			return;
		}
		
		if (!this.boxes.equals(result.boxes)) {
			throw new IllegalArgumentException("Expected same set of boxes");
		}
		
		commandLineArgumentsProvided.addAll(result.commandLineArgumentsProvided);
		commandLineArgumentsUsed.addAll(result.commandLineArgumentsUsed);
		
		populated.addAll(result.populated);
		userErrors.addAll(result.userErrors);
		userWarnings.addAll(result.userWarnings);
		
		// ignores autoErrors and autoWarnings because those will be
		// regenerated next call to check() if they still apply
	}
	
	/** Gets the boxes being populated. */
	public Collection<ArgumentBox> getArgumentBoxes() {
		return Collections.unmodifiableCollection(boxes);
	}
	
	/** Gets the list of warnings encountered while parsing. */
	public List<String> getWarnings() {
		List<String> warnings = new ArrayList<String>(userWarnings.size() + autoWarnings.size());
		for (String warning : userWarnings) {
			if (!warnings.contains(warning)) {
				warnings.add(warning);
			}
		}
		for (String warning : autoWarnings) {
			if (!warnings.contains(warning)) {
				warnings.add(warning);
			}
		}
		return warnings;
	}
	
	/** Gets the list of errors encountered while parsing. */
	public List<String> getErrors() {
		List<String> errors = new ArrayList<String>(userErrors.size() + autoErrors.size());
		for (String error : userErrors) {
			if (!errors.contains(error)) {
				errors.add(error);
			}
		}
		for (String error : autoErrors) {
			if (!errors.contains(error)) {
				errors.add(error);
			}
		}
		return errors;
	}
	
	/**
	 * Returns the lists of command line arguments provided to the populators
	 * that created this result.
	 */
	public List<String[]> getCommandLineArgumentsProvided() {
		return Collections.unmodifiableList(commandLineArgumentsProvided);
	}
	
	/**
	 * Returns arrays co-indexed with result of
	 * {@link #getCommandLineArgumentsProvided()}; each array contains
	 * <code>true</code> in position i if and only if the corresponding String
	 * was used during processing.
	 */
	public List<boolean[]> getCommandLineArgumentsUsed() {
		return Collections.unmodifiableList(commandLineArgumentsUsed);
	}
	
	/**
	 * Returns an array of all elements from
	 * {@link #getCommandLineArgumentsProvided()} for which the corresponding
	 * element of {@link #getCommandLineArgumentsUsed()} is false.
	 */
	public String[] getUnusedCommandLineArguments() {
		List<String> unused = new LinkedList<String>();
		final int numLists = getCommandLineArgumentsProvided().size();
		assert numLists == getCommandLineArgumentsUsed().size();
		for (int i = 0; i < numLists; i++) {
			final String[] args = getCommandLineArgumentsProvided().get(i);
			final boolean[] used = getCommandLineArgumentsUsed().get(i);
			assert args.length == used.length;
			for (int j = 0; j < args.length; j++) {
				if (!used[j]) {
					unused.add(args[j]);
				}
			}
		}
		return unused.toArray(new String[0]);
	}
	
	/**
	 * Returns usage information for the given boxes along with any error
	 * and warning messages if applicable.
	 */
	@Override
	public String toString() {
		StringBuilder usage = new StringBuilder(ArgumentBoxes.usage(boxes));
		usage.append("\n");
		for (String error : userErrors) {
			usage.append("Error: ").append(error).append("\n");
		}
		usage.append("\n");
		for (String error : autoErrors) {
			usage.append("Error: ").append(error).append("\n");
		}
		usage.append("\n");
		for (String warning: userWarnings) {
			usage.append("Warning: ").append(warning).append("\n");
		}
		usage.append("\n");
		for (String warning: autoWarnings) {
			usage.append("Warning: ").append(warning).append("\n");
		}
		return usage.toString();
	}
}
