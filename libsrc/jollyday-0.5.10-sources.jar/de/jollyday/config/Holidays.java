//
// Diese Datei wurde mit der JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.1 generiert 
// Siehe <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Änderungen an dieser Datei gehen bei einer Neukompilierung des Quellschemas verloren. 
// Generiert: 2019.12.18 um 09:41:15 PM CET 
//


package de.jollyday.config;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für Holidays complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="Holidays"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Fixed" type="{http://www.example.org/Holiday}Fixed" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RelativeToFixed" type="{http://www.example.org/Holiday}RelativeToFixed" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RelativeToWeekdayInMonth" type="{http://www.example.org/Holiday}RelativeToWeekdayInMonth" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FixedWeekday" type="{http://www.example.org/Holiday}FixedWeekdayInMonth" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ChristianHoliday" type="{http://www.example.org/Holiday}ChristianHoliday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="IslamicHoliday" type="{http://www.example.org/Holiday}IslamicHoliday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FixedWeekdayBetweenFixed" type="{http://www.example.org/Holiday}FixedWeekdayBetweenFixed" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FixedWeekdayRelativeToFixed" type="{http://www.example.org/Holiday}FixedWeekdayRelativeToFixed" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HinduHoliday" type="{http://www.example.org/Holiday}HinduHoliday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HebrewHoliday" type="{http://www.example.org/Holiday}HebrewHoliday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EthiopianOrthodoxHoliday" type="{http://www.example.org/Holiday}EthiopianOrthodoxHoliday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RelativeToEasterSunday" type="{http://www.example.org/Holiday}RelativeToEasterSunday" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Holidays", propOrder = {
    "fixed",
    "relativeToFixed",
    "relativeToWeekdayInMonth",
    "fixedWeekday",
    "christianHoliday",
    "islamicHoliday",
    "fixedWeekdayBetweenFixed",
    "fixedWeekdayRelativeToFixed",
    "hinduHoliday",
    "hebrewHoliday",
    "ethiopianOrthodoxHoliday",
    "relativeToEasterSunday"
})
public class Holidays {

    @XmlElement(name = "Fixed")
    protected List<Fixed> fixed;
    @XmlElement(name = "RelativeToFixed")
    protected List<RelativeToFixed> relativeToFixed;
    @XmlElement(name = "RelativeToWeekdayInMonth")
    protected List<RelativeToWeekdayInMonth> relativeToWeekdayInMonth;
    @XmlElement(name = "FixedWeekday")
    protected List<FixedWeekdayInMonth> fixedWeekday;
    @XmlElement(name = "ChristianHoliday")
    protected List<ChristianHoliday> christianHoliday;
    @XmlElement(name = "IslamicHoliday")
    protected List<IslamicHoliday> islamicHoliday;
    @XmlElement(name = "FixedWeekdayBetweenFixed")
    protected List<FixedWeekdayBetweenFixed> fixedWeekdayBetweenFixed;
    @XmlElement(name = "FixedWeekdayRelativeToFixed")
    protected List<FixedWeekdayRelativeToFixed> fixedWeekdayRelativeToFixed;
    @XmlElement(name = "HinduHoliday")
    protected List<HinduHoliday> hinduHoliday;
    @XmlElement(name = "HebrewHoliday")
    protected List<HebrewHoliday> hebrewHoliday;
    @XmlElement(name = "EthiopianOrthodoxHoliday")
    protected List<EthiopianOrthodoxHoliday> ethiopianOrthodoxHoliday;
    @XmlElement(name = "RelativeToEasterSunday")
    protected List<RelativeToEasterSunday> relativeToEasterSunday;

    /**
     * Gets the value of the fixed property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixed property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixed().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Fixed }
     * 
     * 
     */
    public List<Fixed> getFixed() {
        if (fixed == null) {
            fixed = new ArrayList<Fixed>();
        }
        return this.fixed;
    }

    /**
     * Gets the value of the relativeToFixed property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relativeToFixed property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelativeToFixed().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelativeToFixed }
     * 
     * 
     */
    public List<RelativeToFixed> getRelativeToFixed() {
        if (relativeToFixed == null) {
            relativeToFixed = new ArrayList<RelativeToFixed>();
        }
        return this.relativeToFixed;
    }

    /**
     * Gets the value of the relativeToWeekdayInMonth property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relativeToWeekdayInMonth property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelativeToWeekdayInMonth().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelativeToWeekdayInMonth }
     * 
     * 
     */
    public List<RelativeToWeekdayInMonth> getRelativeToWeekdayInMonth() {
        if (relativeToWeekdayInMonth == null) {
            relativeToWeekdayInMonth = new ArrayList<RelativeToWeekdayInMonth>();
        }
        return this.relativeToWeekdayInMonth;
    }

    /**
     * Gets the value of the fixedWeekday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixedWeekday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixedWeekday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FixedWeekdayInMonth }
     * 
     * 
     */
    public List<FixedWeekdayInMonth> getFixedWeekday() {
        if (fixedWeekday == null) {
            fixedWeekday = new ArrayList<FixedWeekdayInMonth>();
        }
        return this.fixedWeekday;
    }

    /**
     * Gets the value of the christianHoliday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the christianHoliday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChristianHoliday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ChristianHoliday }
     * 
     * 
     */
    public List<ChristianHoliday> getChristianHoliday() {
        if (christianHoliday == null) {
            christianHoliday = new ArrayList<ChristianHoliday>();
        }
        return this.christianHoliday;
    }

    /**
     * Gets the value of the islamicHoliday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the islamicHoliday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIslamicHoliday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IslamicHoliday }
     * 
     * 
     */
    public List<IslamicHoliday> getIslamicHoliday() {
        if (islamicHoliday == null) {
            islamicHoliday = new ArrayList<IslamicHoliday>();
        }
        return this.islamicHoliday;
    }

    /**
     * Gets the value of the fixedWeekdayBetweenFixed property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixedWeekdayBetweenFixed property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixedWeekdayBetweenFixed().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FixedWeekdayBetweenFixed }
     * 
     * 
     */
    public List<FixedWeekdayBetweenFixed> getFixedWeekdayBetweenFixed() {
        if (fixedWeekdayBetweenFixed == null) {
            fixedWeekdayBetweenFixed = new ArrayList<FixedWeekdayBetweenFixed>();
        }
        return this.fixedWeekdayBetweenFixed;
    }

    /**
     * Gets the value of the fixedWeekdayRelativeToFixed property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fixedWeekdayRelativeToFixed property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFixedWeekdayRelativeToFixed().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FixedWeekdayRelativeToFixed }
     * 
     * 
     */
    public List<FixedWeekdayRelativeToFixed> getFixedWeekdayRelativeToFixed() {
        if (fixedWeekdayRelativeToFixed == null) {
            fixedWeekdayRelativeToFixed = new ArrayList<FixedWeekdayRelativeToFixed>();
        }
        return this.fixedWeekdayRelativeToFixed;
    }

    /**
     * Gets the value of the hinduHoliday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hinduHoliday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHinduHoliday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HinduHoliday }
     * 
     * 
     */
    public List<HinduHoliday> getHinduHoliday() {
        if (hinduHoliday == null) {
            hinduHoliday = new ArrayList<HinduHoliday>();
        }
        return this.hinduHoliday;
    }

    /**
     * Gets the value of the hebrewHoliday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hebrewHoliday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHebrewHoliday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HebrewHoliday }
     * 
     * 
     */
    public List<HebrewHoliday> getHebrewHoliday() {
        if (hebrewHoliday == null) {
            hebrewHoliday = new ArrayList<HebrewHoliday>();
        }
        return this.hebrewHoliday;
    }

    /**
     * Gets the value of the ethiopianOrthodoxHoliday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ethiopianOrthodoxHoliday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEthiopianOrthodoxHoliday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EthiopianOrthodoxHoliday }
     * 
     * 
     */
    public List<EthiopianOrthodoxHoliday> getEthiopianOrthodoxHoliday() {
        if (ethiopianOrthodoxHoliday == null) {
            ethiopianOrthodoxHoliday = new ArrayList<EthiopianOrthodoxHoliday>();
        }
        return this.ethiopianOrthodoxHoliday;
    }

    /**
     * Gets the value of the relativeToEasterSunday property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relativeToEasterSunday property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelativeToEasterSunday().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelativeToEasterSunday }
     * 
     * 
     */
    public List<RelativeToEasterSunday> getRelativeToEasterSunday() {
        if (relativeToEasterSunday == null) {
            relativeToEasterSunday = new ArrayList<RelativeToEasterSunday>();
        }
        return this.relativeToEasterSunday;
    }

}
