/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.stanford.cs.ra.arguments.ArgumentBox;
import edu.stanford.cs.ra.arguments.ArgumentInfo;
import edu.stanford.cs.ra.arguments.ArgumentPolicy;
import edu.stanford.cs.ra.arguments.ArgumentInfo.ArgumentInfoBuilder;
import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;

/**
 * A {@link StageRunner} backed by shell scripts.  Information about arguments,
 * inputs, outputs, and dependencies are specified as additional headers.
 * 
 * Doesn't currently work.
 * 
 * @author dramage
 */
class ShellStageRunner implements StageRunner {

	public static void main(String[] argv) {
		forName("ExtractFeatures", new File[]{new File("test/example/shell")});
	}
	
	//
	// static constructor method
	//
	
	/** Prefixes used for specifying stage fields in the script */
	enum StageKey {
		NAME("#@stage"), INVOKE("#@invoke"), FOREACH("#@foreach"),
		ARGUMENT("#@argument", true), DEPENDS("#@depends", true);
		
		/** Prefix of line when parsing file */
		String prefix;
		
		/** Whether more than one is allowed */
		boolean plural = false;
		
		StageKey(String prefix) {
			this.prefix = prefix;
		}
		
		StageKey(String prefix, boolean plural) {
			this.prefix = prefix;
			this.plural = plural;
		}
	}
	
	/** Keys for describing fields on an #@argument */
	enum ArgumentKey {
		NAME, TYPE, DEFAULT, SWITCH, DESCRIPTION, POLICY;
	}
		
	private static final String ERR_ARG_NAME_NOT_SPECIFIED
		= "%s: Argument definition does not specify a name";
	
	private static final String ERR_INVALID_DEPENDS
	    = "%s: Dependency should be specified as \"PrereqStageName [with arg1=val1 arg2=val2 ...]\"";
	
	private static final String ERR_STAGE_NOT_FOUND
	    = "%s: Prequisite stage \"%s\" not found";
	
	private static final String ERR_STAGE_NAME_DECLARATION
	    = "%s: "+StageKey.NAME.prefix+" must be declared exactly once";
	
	private static final String ERR_DUPLICATE_DECLARATION
		= "Key %s can only be declared once";
	
	public static ShellStageRunner forName(String name, File[] path) {
		
		Map<String,Map<StageKey,String>> stages
			= new HashMap<String,Map<StageKey,String>>();
		
		for (File dir : path) {
			for (File potentialScript : dir.listFiles()) {
				Map<StageKey,String> stage = parseStageFields(potentialScript);
				
				if (!stage.containsKey(StageKey.NAME)) {
					// not a valid script
					continue;
				}
				
				stages.put(stage.get(StageKey.NAME), stage);
			}
		}
		
		System.out.println(stages);
		
		return fromStageFields(name, stages, new LinkedList<String>());
	}
	
	/**
	 * Extracts strings for all prefix fields from the header of the
	 * give file.
	 */
	private static Map<StageKey,String> parseStageFields(File script) {
		Map<StageKey,String> fields
			= new EnumMap<StageKey,String>(StageKey.class);
		
		for (String line : IOUtils.readLines(IOUtils.openFile(script))) {
			if (!line.startsWith("#") && line.trim().length() > 0) {
				// stop once we reach a "real" line
				break;
			}
			
			for (StageKey key : StageKey.values()) {
				if (line.toLowerCase().startsWith(key.prefix)) {
					line = line.substring(key.prefix.length()).trim();
					
					if (!fields.containsKey(key)) {
						fields.put(key, line);
					} else if (key.plural) {
						fields.put(key, fields.get(key) + "\n" + line);
					} else {
						throw new ShellParseException(
								String.format(ERR_DUPLICATE_DECLARATION,
										key.prefix));
					}
					
					break;
				}
			}
		}
		
		return fields;
	}
	
	/**
	 * Returns an instance of StageRunner based on the given StageFields.
	 */
	private static ShellStageRunner fromStageFields(String stageName,
			Map<String,Map<StageKey, String>> stages, List<String> visited) {
		
		if (!stages.containsKey(stageName)) {
			throw new ShellParseException(
					String.format(ERR_STAGE_NOT_FOUND, stageName, stageName));
		}
			
			
		Map<StageKey,String> stage = stages.get(stageName);

		visited = new LinkedList<String>(visited);
		visited.add(stageName);

		List<ShellStageRunner> prereqs = new LinkedList<ShellStageRunner>();
		List<ArgumentInfo> arguments = new LinkedList<ArgumentInfo>();
		String invokeParameters = "";
		String invokeAcross = ".";
		
		
		if (!stage.containsKey(StageKey.INVOKE)) {
			throw new ShellParseException(
					String.format("%s: Must contain %s",
							stageName, StageKey.INVOKE.prefix));
		}
		
		for (Map.Entry<StageKey, String> entry : stage.entrySet()) {
			switch(entry.getKey()) {
			case NAME:
				assert stageName.equals(entry.getValue());
				break;
				
			case ARGUMENT:
				for (String line : entry.getValue().split("\n")) {
					arguments.add(parseArgument(line, stageName));
				}
				break;
				
			case DEPENDS:
				for (String line : entry.getValue().split("\n")) {
					List<String> args = split(line);
					
					if (args.size() > 1) {
						if (!args.get(1).toLowerCase().equals("with")) {
							throw new ShellParseException(
									String.format(ERR_INVALID_DEPENDS, stageName));
						}
					}

					String required = args.get(0);

					StageWise.assertNoCircularDependency(required, visited);
					
					if (!stages.containsKey(required)) {
						throw new ShellParseException(
								String.format(ERR_STAGE_NOT_FOUND, stageName, required));
					}
					
					prereqs.add(fromStageFields(args.get(0), stages, visited));
				}
				break;
				
			case INVOKE:
				invokeParameters = entry.getValue();
				break;
				
			case FOREACH:
				invokeAcross = entry.getValue();
				break;
				
			default:
				throw new ShellParseException("Unexpected StageKey - this is a bug in RA");
			}
		}
		
		// TODO: fixme
		return null;
	}
	
	/** Splits the given line by spaces honoring quoting and escaping. */
	private static List<String> split(String line) {
		List<String> segments = new LinkedList<String>();
		
		for (String segment : Stringify.escapedQuotedSplit(String.class, line, ' ', '"')) {
			if (segment.length() > 0) {
				segments.add(segment);
			}
		}
		
		return segments;
	}

	/** Returns an ArgumentInfo instance from the spec given in line. */
	private static ArgumentInfo parseArgument(String line, String where) {
		Map<ArgumentKey,String> valueMap = parseArgumentValueMap(line);
		if (!valueMap.containsKey(ArgumentKey.NAME)) {
			// require argument name
			throw new ShellParseException(
					String.format(ERR_ARG_NAME_NOT_SPECIFIED, where));
		}
		if (!valueMap.containsKey(ArgumentKey.TYPE)) {
			valueMap.put(ArgumentKey.TYPE, "String");
		}

		Class<?> type = Stringify.fromString(Class.class, valueMap.get(ArgumentKey.TYPE));
		ArgumentInfoBuilder builder = new ArgumentInfoBuilder(type)
				.qualifiedName(valueMap.get(ArgumentKey.NAME));
		
		for (ArgumentKey key : valueMap.keySet()) {
			switch (key) {
			case DEFAULT:
				builder.defaultValue(valueMap.get(key));
				break;
			case SWITCH:
				builder.switches(valueMap.get(key).split(","));
				break;
			case DESCRIPTION:
				builder.description(valueMap.get(key));
				break;
			case POLICY:
				builder.policy(ArgumentPolicy.valueOf(valueMap.get(key)));
				break;
			}
		}
		
		return builder.build();
	}
	
	private static Map<ArgumentKey,String> parseArgumentValueMap(String line) {
		Map<ArgumentKey,String> values
			= new EnumMap<ArgumentKey,String>(ArgumentKey.class);
		
		for (String pair : Stringify.escapedQuotedSplit(String.class,
				line, ' ', '"')) {

			if (pair.trim().length() == 0) {
				// ignore empty entries
				continue;
			}
			
			if (pair.indexOf('=') < 0) {
				throw new ShellParseException("Expected name=value pairs (with no whitespace)");
			}
			
			String[] keyval = pair.split("=", 2);
			if (keyval[1].startsWith("\"") || keyval[1].endsWith("\"")) {
				if (!(keyval[1].startsWith("\"") && keyval[1].endsWith("\""))) {
					throw new ShellParseException("Unmatched quotes in an "+StageKey.ARGUMENT.prefix+" line");
				}
				keyval[1] = keyval[1].substring(1, keyval[1].length()-1);
			}
			
			ArgumentKey key;
			try {
				key = ArgumentKey.valueOf(keyval[0].toUpperCase());
			} catch (IllegalArgumentException e) {
				throw new ShellParseException(
						String.format("Unexpected field %s for %s",
								keyval[0], StageKey.ARGUMENT.prefix));
			}
			
			values.put(key, keyval[1]);
		}
		
		return values;
	}
	
	/**
	 * Exception thrown when encountering an error on parsing a shell
	 * stage descriptor.
	 * 
	 * @author dramage
	 */
	public static class ShellParseException extends RuntimeException {
		private static final long serialVersionUID = 1L;
		public ShellParseException(String message) {
			super(message);
		}
	}
	
	//
	// actual class
	//
	
	private final StageDescriptor descriptor;
	private final ArgumentBox box;
	private final Collection<String> imports;
	private final Collection<String> exports;
	private final List<StageRunner> prereqs;
	private final String invokeString;
	
	private ShellStageRunner(StageDescriptor descriptor, ArgumentBox box,
			Collection<String> imports, Collection<String> exports,
			List<StageRunner> prereqs, String invokeString) {
		
		this.descriptor = descriptor;
		this.box = box;
		this.imports = imports;
		this.exports = exports;
		this.prereqs = prereqs;
		this.invokeString = invokeString;
	}
	
	public ArgumentBox getArgumentBox() {
		return box;
	}

	public Collection<String> getExportFields() {
		return exports;
	}
	
	public Collection<String> getImportFields() {
		return imports;
	}

	public Collection<StageRunner> getRequiredStages() {
		return Collections.unmodifiableList(prereqs);
	}

	public StageDescriptor getStageDescriptor() {
		return descriptor;
	}

	public void run(StageWise context, StageLineage lineage) {
		System.out.println(invokeString);
	}

	public Object getField(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setField(String name, Object value) {
		// TODO Auto-generated method stub
		
	}

	public boolean shouldCheckpoint() {
		// TODO Auto-generated method stub
		return false;
	}

}
