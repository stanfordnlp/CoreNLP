/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Utilities for XML manipulation.
 * 
 * @author dramage
 */
public class XMLUtils {
	
	/**
	 * Escapes &amp; &lt; &gt; &quot; &apos; and all invalid unicode
	 * characters from the given string with XML entity equivalents.
	 */
	public static String escapeForAttribute(String s) {
		return escape(s, true);
	}
	
	/**
	 * Escapes &amp; &lt; &gt; and all invalid unicode characters from
	 * the given string with XML entity equivalents.
	 */
	public static String escapeForTextNode(String s) {
		return escape(s, false);
	}

	private final static String escape(String s, boolean inAttribte) {
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < s.length();) {
			int codePoint = s.codePointAt(i);

			if (inAttribte && (codePoint == '\'' || codePoint == '"')) {
				// must escape apos and quot in attributes only
				result.append(codePoint == '\'' ? "&apos;" : "&quot;");
			} else if (codePoint == '<') {
				// escape basic control char <
				result.append("&lt;");
			} else if (codePoint == '>') {
				// escape basic control char >
				result.append("&gt;");
			} else if (codePoint == '&') {
				// escape basic control char &
				result.append("&amp;");
			} else if (
					(codePoint == 0x09) || (codePoint == 0x0A) || (codePoint == 0x0D) ||
					(codePoint >= 0x20    && codePoint <= 0xD7FF  ) ||
					(codePoint >= 0xE000  && codePoint <= 0xFFFD  ) ||
					(codePoint >= 0x10000 && codePoint <= 0x10FFFF)) {
				// valid character range as defined in xml spec
				// http://www.w3.org/TR/REC-xml/#charsets
				result.appendCodePoint(codePoint);
			} else {
				// any other characters must be escaped
				result.append("&#x").append(Integer.toHexString(codePoint)).append(';');
			}

			// increment by number of chars consumed by codePoint
			i += Character.charCount(codePoint);
		}
		return result.toString();
	}
	
	private final static XPath xpath = XPathFactory.newInstance().newXPath();

	/**
	 * Returns an XML document based on the contents of the given string.
	 */
	public static Document documentFromString(String string) {
		return documentFromStream(new ByteArrayInputStream(string.getBytes()));
	}
	
	/**
	 * Returns an XML document based on the contents of the given InputStream.
	 */
	public static Document documentFromStream(InputStream stream) {
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true); // never forget this!
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			Document doc = builder.parse(stream);
			return doc;
		} catch (Exception e) {
			throw new XMLException(e);
		}
	}
	
	
	/**
	 * Returns the NodeList resulting from running the given XPath query 
	 * on the given document.
	 */
	public static NodeList xpathNodeList(Document doc, String query) {
		try {
			XPathExpression expr = xpath.compile(query);
			return (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
		} catch (Exception e) {
			throw new XMLException(e);
		}
	}
	
	/**
	 * Returns a list of strings on the text content of the nodes
	 * matching the given XPath query.
	 */
	public static List<String> xpathList(Document doc, String query) {
		List<String> values = new LinkedList<String>();
		NodeList nodelist = xpathNodeList(doc, query);
		for (int i = 0; i < nodelist.getLength(); i++) {
			values.add(nodelist.item(i).getTextContent());
		}
		return values;
	}
	
	/**
	 * Returns a map from String to String on the corresponding getTextContent
	 * of each relative query to the given base query.
	 */
	public static Map<String,String> xpathMap(Document doc, String baseQuery, String keyQuery, String valueQuery) {
		try {
			XPathExpression keyExpr = xpath.compile(keyQuery);
			XPathExpression valueExpr = xpath.compile(valueQuery);

			Map<String,String> map = new HashMap<String,String>();
			NodeList nodelist = xpathNodeList(doc, baseQuery);
			for (int i = 0; i < nodelist.getLength(); i++) {
				Node node = nodelist.item(i);
				map.put((String)keyExpr.evaluate(node, XPathConstants.STRING),
						(String)valueExpr.evaluate(node, XPathConstants.STRING));
			}
			return map;
		} catch (Exception e) {
			throw new XMLException(e);
		}
	}
}
