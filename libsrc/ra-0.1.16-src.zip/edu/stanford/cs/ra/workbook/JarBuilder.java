/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;

import edu.stanford.cs.ra.RA;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.PathUtils;
import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * Creates a runnable experiment package based on the classes currently
 * available in the system.
 * 
 * @author dramage
 */
public class JarBuilder {

	/** Folders already added to the JAR */
	private final Set<String> folders = new HashSet<String>();
	
	/** JarOutputStream for holding JAR */
	public final JarOutputStream stream;
	
	/**
	 * Builds a Jar to the given output stream.
	 */
	public JarBuilder(OutputStream out, String mainclass, List<String> argv) {
        String manifestString = new StringBuilder()
        	.append("Manifest-Version: 1.0\n")
        	.append("Created-By: ").append(RA.VERSION).append(" (RA)\n")
        	.append("Main-Class: ").append(JarRunner.class.getCanonicalName()).append("\n")
        	.toString();
        
		Manifest manifest;
		try {
			manifest = new Manifest(new ByteArrayInputStream(manifestString.getBytes()));
		} catch (IOException e) {
			// should always be able to create a manifest this way
			throw new RuntimeException(e);
		}
		
		try {
			stream = new JarOutputStream(out, manifest);
			
			stream.putNextEntry(new ZipEntry("META-RA/"));
			stream.closeEntry();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}

//	/**
//	 * Jars up the contents of the given folder.
//	 */
//	public void jarFolder(File folder) {
//		for (File added : IOUtils.zip(stream, folder, folder, "", true)) {
//			if (added.isDirectory()) {
//				folders.add(PathUtils.relativePath(added, folder));
//			}
//		}
//	}
	
	/**
	 * Jars up the selected classes of the given folder.
	 */
	public void jarFolder(File folder, Set<String> classnames, Set<String> added) {
		try {
			jarFolder(folder, folder, classnames, added);
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Jars up all files corresponding to classes listed in the given set
	 * of class names found in the given folder (relative to the given base
	 * folder).
	 */
	private void jarFolder(File folder, File base, Set<String> classnames, Set<String> added)
		throws IOException {
		
		String pkg = PathUtils.relativePath(folder, base).replace(File.separator, ".");
		if (pkg.equals(".") || pkg.length() == 0) {
			pkg = "";
		}
		
		for (File file : folder.listFiles()) {
			if (file.isDirectory()) {
				jarFolder(file, base, classnames, added);
			} else if (file.getName().endsWith(".class")) {
				String name = pkg+"."+file.getName();
				name = name.substring(0, name.lastIndexOf(".class"));
				if (file.getName().contains("$")) {
					name = name.substring(0, name.lastIndexOf("$"));
				}
				
				//if (classnames == null || classnames.contains(name)) {
					//addFolder(PathUtils.relativePath(folder, base));
					ZipEntry entry = new ZipEntry(PathUtils.relativePath(file, base));
					if (!added.contains(entry.getName())) {
						entry.setTime(file.lastModified());
						stream.putNextEntry(entry);
						IOUtils.drain(new FileInputStream(file), stream);
						stream.closeEntry();
						added.add(entry.getName());
					}
				//}
			}
		}
	}
	
	private void addFolder(String folder) throws IOException {
		// short circuit if we this is the base folder
		if (folder.equals(".") || folder.length() == 0) {
			return;
		}

		// make all
		String name = "";
		for (String segment : folder.split(File.pathSeparator)) {
			name += segment + "/";
			if (!folders.contains(name)) {
				ZipEntry entry = new ZipEntry(name);
				stream.putNextEntry(entry);
				stream.closeEntry();
				folders.add(name);
			}
		}
	}

	/**
	 * Jars up the contents of the given jar.  Mutates the given "added" set
	 * with the classes added so far.
	 */
	public void jarJar(JarFile jar, Set<String> classnames, Set<String> added) {
		Enumeration<JarEntry> entries = jar.entries();
		while (entries.hasMoreElements()) {
			JarEntry entry = entries.nextElement();
			
			if (entry.getName().startsWith("META-INF")) {
				continue;
			}
			
			if (entry.isDirectory()) {
				// move on if a folder
				continue;
			}
			
			// if (classnames == null || classnames.contains(entry.getName())
			
			try {
				if (!added.contains(entry.getName())) {
					stream.putNextEntry(entry);
					IOUtils.drain(jar.getInputStream(entry), stream);
					stream.closeEntry();
					added.add(entry.getName());
				}
			} catch (IOException e) {
				throw new QuietIOException(e);
			}
		}
	}
	
//	/**
//	 * Jars all classes and jars in java.class.path
//	 */
//	public void slurpClassPath() {
//		for (String pathString : System.getProperty("java.class.path").split(System.getProperty("path.separator"))) {
//			File pathFile = new File(pathString);
//			try {
//				if (pathFile.isDirectory()) {
//					jarFolder(pathFile);
//				} else if (pathFile.isFile()) {
//					jarJar(new JarFile(pathFile));
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//				RA.stream.line("warning", "Unable to jar "+pathFile);
//			}
//		}
//	}
	
	/**
	 * Jars all the listed classes from wherever they can be found on the
	 * classpath.  Jars up the containing package of any needed classes
	 * as well.
	 */
	public void slurpClasses(List<Class<?>> classes) {
		Set<String> names = new HashSet<String>();
		for (Class<?> c : classes) {
			String name = c.getName();
			if (name.contains("$")) {
				name = name.substring(0, name.indexOf("$"));
			}
			if (name.length() > 0) {
				names.add(name);
			}
		}
		
		Set<String> added = new LinkedHashSet<String>();
		
		for (String pathString : System.getProperty("java.class.path").split(System.getProperty("path.separator"))) {
			File pathFile = new File(pathString);
			try {
				if (pathFile.isDirectory()) {
					jarFolder(pathFile, names, added);
				} else if (pathFile.isFile()) {
					jarJar(new JarFile(pathFile), names, added);
				}
			} catch (Exception e) {
				e.printStackTrace();
				RA.stream.line("warning", "Unable to jar "+pathFile);
			}
		}
	}
	
	public void finish() {
		try {
			stream.finish();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
}
