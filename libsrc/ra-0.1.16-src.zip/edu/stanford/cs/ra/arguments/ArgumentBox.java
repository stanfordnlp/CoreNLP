/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.util.Collection;

/**
 * A class that holds one or more arguments (instances of {@link ArgumentInfo}).
 * Information about a set of Arguments.  This interface is provided so that
 * you can define your own (dynamic) argument boxes.  Use
 * {@link ArgumentBoxes#fromInstance(Object)} to use reflection to construct
 * an ArgumentBox based on the annotations in a class.
 * 
 * @author dramage
 */
public interface ArgumentBox {
	
	/**
	 * Returns the global unique name of this box.
	 */
	public String getName();
	
	/**
	 * Returns the list of arguments contained in this box.
	 */
	public Collection<ArgumentInfo> getArguments();

	/**
	 * Returns the (Stringified) value of the given argument for this box.
	 */
	public String getValue(ArgumentInfo argument);

	/**
	 * Sets the (Stringified) value of the given argument for this box.
	 */
	public void setValue(ArgumentInfo argument, String value);
	
	/**
	 * Checks that all validity constraints are met.
	 * 
	 * @throws ArgumentException with information about any failures.
	 */
	public void check() throws ArgumentException;
}
