/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * An XMLStream that silently discards all inputs.
 * 
 * @author dramage
 */
public class NullXMLStream implements XMLStream {
	
	private boolean isOpen = true;
	private final LinkedList<String> stack = new LinkedList<String>();
	
	public XMLStream begin(String tag, Object... args) {
		if (isOpen) {
			stack.add(tag);
		}
		return this;
	}

	public void close() {
		isOpen = false;
	}

	public XMLStream end(String tag) {
		if (isOpen) {
			if (!stack.getLast().equals(tag)) {
				throw new XMLException("Tried to close tag \""+tag+"\" " +
						"but expected \""+stack.getLast()+"\"");
			}
			stack.removeLast();
		}
		return this;
	}

	public List<String> getTagStack() {
		return Collections.unmodifiableList(stack);
	}

	public XMLStream line(String tag, Object body, Object... args) {
		return this;
	}

	public XMLStream xml(EscapedXML xml) {
		return this;
	}
}
