

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/* 
 * Counters: Fast & compact NLP data structures for Java
 * Based on fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2007 Daniel Ramage
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.doubles;
import it.unimi.dsi.fastutil.doubles.*;
import java.util.Map;
import java.util.NoSuchElementException;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.AbstractObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
/**
 * A type-specific counter; provides a {@link Map} from key to numeric values that can be incremented and decremented, along with a running total.
 *
 * @see Map
 * @author dramage
 */
/**
 * A Counter implementation backed by an OpenHashMap.
 * 
 * TODO: worry about readObject
 */
public class Double2IntOpenHashCounter extends Double2IntOpenHashMap implements Double2IntCounter {
 public Double2IntOpenHashCounter() {
  super();
 }
 /** Constructor for given expected number of entries */
 public Double2IntOpenHashCounter(int n) {
  super(n);
 }
 /** Constructor for given expected number of entries, load factor */
 public Double2IntOpenHashCounter(int n, float f) {
  super(n,f);
 }
 /** Copy constructor */
 public Double2IntOpenHashCounter(Double2IntCounter counter) {
  super(counter);
  this.total = counter.total();
 }
 /** Copy constructor */
 public Double2IntOpenHashCounter(Map<Double,? extends Number> map) {
  super(map.size());
  for (Map.Entry<Double,? extends Number> entry : map.entrySet()) {
   put((double)entry.getKey(), entry.getValue().intValue());
  }
 }
 protected int total;
 @Override
 public int put(final double k, final int v) {
  final int rv = super.put(k,v);
  total = total - rv + v;
  return rv;
 }
 @Override
 public Integer put(final Double ok, final Integer ov) {
  final Integer rv = super.put(ok,ov);
  total = total - rv + ov;
  return rv;
 }
 @Override
 public void clear() {
  super.clear();
  total = 0;
 }
 /** The entry class for a hash map does not record key and value, but
	 * rather the position in the hash table of the corresponding entry. This
	 * is necessary so that calls to {@link java.util.Map.Entry#setValue(Object)} are reflected in
	 * the map */
 private final class MapEntry implements Double2IntMap.Entry , Map.Entry<Double, Integer> {
  private int index;
  MapEntry( final int index ) {
   this.index = index;
  }
  public Double getKey() {
   return (Double.valueOf(key[ index ]));
  }
  public double getDoubleKey() {
      return key[ index ];
  }
  public Integer getValue() {
   return (Integer.valueOf(value[ index ]));
  }

  public int getIntValue() {
   return value[ index ];
  }


  public int setValue( final int v ) {
   final int oldValue = value[ index ];
   value[ index ] = v;
   total = total - oldValue + v;
   return oldValue;
  }



  public Integer setValue( final Integer v ) {
   return (Integer.valueOf(setValue( ((v).intValue()) )));
  }



  @SuppressWarnings("unchecked")
  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<Double, Integer> e = (Map.Entry<Double, Integer>)o;

   return ( (key[ index ]) == (((e.getKey()).doubleValue())) ) && ( (value[ index ]) == (((e.getValue()).intValue())) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.double2int(key[ index ]) ^ (value[ index ]);
  }


  public String toString() {
   return key[ index ] + "->" + value[ index ];
  }
 }

 /** An iterator over a hash map. */

 private class MapIterator {
  /** The index of the next entry to be returned. */
  int pos = 0;
  /** The index of the last entry that has been returned. */
  int last = -1;
  /** A downward counter measuring how many entries have been returned. */
  int c = count;

  {
   final byte state[] = Double2IntOpenHashCounter.this.state;
   final int n = state.length;

   if ( c != 0 ) while( pos < n && state[ pos ] != OCCUPIED ) pos++;
  }

  public boolean hasNext() {
   return c != 0 && pos < Double2IntOpenHashCounter.this.state.length;
  }

  public int nextEntry() {
   final byte state[] = Double2IntOpenHashCounter.this.state;
   final int n = state.length;

   if ( ! hasNext() ) throw new NoSuchElementException();
   last = pos;
   if ( --c != 0 ) do pos++; while( pos < n && state[ pos ] != OCCUPIED );

   return last;
  }

  @SuppressWarnings("unchecked")
  public void remove() {
   if (last == -1) throw new IllegalStateException();
   if (state[last] == OCCUPIED) {
    total -= value[last];
   }

   state[last] = REMOVED;







   count--;
  }

  public int skip( final int n ) {
   int i = n;
   while( i-- != 0 && hasNext() ) nextEntry();
   return n - i - 1;
  }
 }


 private class EntryIterator extends MapIterator implements ObjectIterator<Double2IntMap.Entry > {
  public Double2IntMap.Entry next() {
   return new MapEntry( nextEntry() );
  }
 }

 public static class BasicEntry implements Double2IntMap.Entry {
  protected double key;
  protected int value;

  public BasicEntry( final Double key, final Integer value ) {
   this.key = ((key).doubleValue());
   this.value = ((value).intValue());
  }



  public BasicEntry( final double key, final int value ) {
   this.key = key;
   this.value = value;
  }



  public Double getKey() {
   return (Double.valueOf(key));
  }


  public double getDoubleKey() {
   return key;
  }


  public Integer getValue() {
   return (Integer.valueOf(value));
  }


  public int getIntValue() {
   return value;
  }


  public int setValue( final int value ) {
   throw new UnsupportedOperationException();
  }



  public Integer setValue( final Integer value ) {
   return Integer.valueOf(setValue(value.intValue()));
  }



  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<?,?> e = (Map.Entry<?,?>)o;

   return ( (key) == (((((Double)(e.getKey())).doubleValue()))) ) && ( (value) == (((((Integer)(e.getValue())).intValue()))) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.double2int(key) ^ (value);
  }


  public String toString() {
   return key + "->" + value;
  }
 }


 private class FastEntryIterator extends MapIterator implements ObjectIterator<Double2IntMap.Entry > {
  final BasicEntry entry = new BasicEntry ( (0), (0) );
  public BasicEntry next() {
   final int e = nextEntry();
   entry.key = key[ e ];
   entry.value = value[ e ];
   return entry;
  }
 }

 @Override
 public Integer remove( final Object ok ) {
  final Integer rv = super.remove(ok);
  if (rv != null) {
   total -= rv;
  }
  return rv;
 }

 @Override
 public int remove(final double k) {
  final int oldcount = count;
  final int rv = super.remove(k);
  if (oldcount < count) {
   total -= rv;
  }
  return rv;
 }

 @SuppressWarnings("unchecked")
 @Override
 public Object clone() {
  Double2IntOpenHashCounter c = (Double2IntOpenHashCounter)super.clone();
  c.total = this.total;
  return c;
 }


 private final class MapEntrySet extends AbstractObjectSet<Double2IntMap.Entry > implements Double2IntMap.FastEntrySet {

  public ObjectIterator<Double2IntMap.Entry > iterator() {
   return new EntryIterator();
  }

  public ObjectIterator<Double2IntMap.Entry > fastIterator() {
   return new FastEntryIterator();
  }

  @SuppressWarnings("unchecked")
  public boolean contains( final Object o ) {
   if (!(o instanceof Double2IntMap.Entry)) return false;
   final Double2IntMap.Entry e = (Double2IntMap.Entry )o;
   final int i = findKey( ((e.getKey()).doubleValue()) );
   return i >= 0 && ( (value[ i ]) == (((e.getValue()).intValue())) );
  }

  @SuppressWarnings("unchecked")
  public boolean remove( final Object o ) {
   if (!(o instanceof Double2IntMap.Entry)) return false;
   final Double2IntMap.Entry e = (Double2IntMap.Entry )o;
   final int i = findKey( ((e.getKey()).doubleValue()) );
   if ( i >= 0 ) Double2IntOpenHashCounter.this.remove( e.getKey() );
   return i >= 0;
  }

  public int size() {
   return count;
  }

  public void clear() {
   Double2IntOpenHashCounter.this.clear();
  }

 }

 public Double2IntMap.FastEntrySet double2IntEntrySet() {
  if ( entries == null ) entries = new MapEntrySet();
  return entries;
 }

 /**
	 * Increments the value associated with the given key by <code>+adjustAmount</code>,
 	 * returning the value in the map before the increment.  This method is faster than
 	 * incrementing a value in the map with two calls - once to get and once to put -
	 * because it caches the correct insertion point into the hashmap.
	 */
 protected int adjust(final double k, final int adjustAmount) {
  final int i = findInsertionPoint( k );

  total += adjustAmount;

  if (i < 0) {
   final int oldValue = value[-i-1];
   value[-i-1] += adjustAmount;
   return oldValue;
  }

  if ( state[i] == FREE ) free--;
  state[i] = OCCUPIED;
  key[i] = k;
  value[i] = adjustAmount;
  if ( ++count >= maxFill ) {
   int newP = Math.min( p + growthFactor, PRIMES.length - 1 );
   // Just to be sure that size changes when p is very small.
   while( PRIMES[ newP ] == PRIMES[ p ] ) newP++;
   rehash( newP ); // Table too filled, let's rehash
  }
  if ( free == 0 ) rehash( p );
  return defRetValue;
 }
 /** {@inheritDoc} */
 public void incrementAll( Double2IntMap counter ) {
  for (Double2IntMap.Entry entry : counter.double2IntEntrySet()) {
   this.increment(entry.getDoubleKey(), entry.getIntValue());
  }
 }
 /** {@inheritDoc} */
 public int increment( double key, int amount ) {
  return adjust(key, amount) + amount;
 }
 /** {@inheritDoc} */
 public int increment( double key ) {
  return adjust(key, 1) + 1;
 }
 /** {@inheritDoc} */
 public int decrement( double key, int amount ) {
  return adjust(key, -amount) - amount;
 }
 /** {@inheritDoc} */
 public int decrement( double key ) {
  return adjust(key, -1) - 1;
 }
 /** {@inheritDoc} */
 public int total() {
  return total;
 }
}
