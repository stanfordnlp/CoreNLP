

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/*		 
 * fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2002-2007 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.ints;
import it.unimi.dsi.fastutil.objects.*;
import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.doubles.*;
import java.util.Map;
import java.util.Iterator;
import java.util.Random;
/** A class providing static methods and objects that do useful things with
 * type-specific counters.
 */
public class Int2DoubleCounters {
 /** Cannot instantiate */
 private Int2DoubleCounters() {}
 /**
	 * Retains all non-zero entries in the counter.
	 */
 public static void retainNonZeros(Int2DoubleCounter counter) {
  final Iterator<Int2DoubleMap.Entry > entries
    = counter.int2DoubleEntrySet().iterator();
  while (entries.hasNext()) {
   final Int2DoubleMap.Entry entry = entries.next();
   if (entry.getDoubleValue() == 0.0) {
    entries.remove();
   }
  }
 }
 /**
	 * Returns a random key from the given counter with probability in
	 * proportion to its total().
	 * @throws IllegalArgumentException if the counter contains no elements.
	 */
 public static int sample(Int2DoubleCounter counter, Random random) {
  if (counter.size() == 0) {
   throw new IllegalArgumentException("Cannot sample from empty counter");
  }
  final double threshold = random.nextDouble();
  final double total = (double)counter.total();
  double sum = 0;
  for (Int2DoubleMap.Entry entry : counter.int2DoubleEntrySet()) {
   sum += (double)(entry.getValue()) / total;
   if (sum > threshold) {
    return entry.getKey();
   }
  }
  return counter.keySet().iterator().next();
 }
 /**
	* Returns a counter backed by the given array.
	*/
 public static Int2DoubleCounter forArray(final double[] array) {
  double tmpTotal = 0;
  for (double v : array) {
   tmpTotal += v;
  }
  final double arrayTotal = tmpTotal;
  return new AbstractInt2DoubleCounter () {
   private static final long serialVersionUID = 1L;
   final double[] values = array;
   double total = arrayTotal;
   @Override
   public boolean containsKey(int key) {
    return key >= 0 && key < values.length;
   }
   @Override
   public double get(int key) {
    return values[key];
   }
   @Override
   public double put(int key, double value) {
    final double old = values[key];
    values[key] = value;
    total += value - old;
    return old;
   }
   @Override
   public int size() {
    return values.length;
   }
   @Override
   protected double adjust(int key, double adjustAmount) {
    final double old = values[key];
    values[key] += adjustAmount;
    total += adjustAmount;
    return old;
   }
   @Override
   public double total() {
    return total;
   }
   @Override
   public ObjectSet<Int2DoubleMap.Entry > int2DoubleEntrySet() {
    return new AbstractObjectSet<Int2DoubleMap.Entry >() {
     public ObjectIterator<Int2DoubleMap.Entry > iterator() {
      return new ObjectIterator<Int2DoubleMap.Entry >() {
       int index = 0;
       public int skip(int n) {
        int oldIndex = index;
        index += n;
        index = Math.max(index, values.length);
        return index-oldIndex;
       }
       public boolean hasNext() {
        return index < values.length;
       }
       public Int2DoubleMap.Entry next() {
        return new Int2DoubleMap.Entry () {
         final int entryIndex = index++;
         public int getIntKey() {
          return entryIndex;
         }

         public Integer getKey() {
          return entryIndex;
         }

         public double getDoubleValue() {
          return values[entryIndex];
         }

         public Double getValue() {
          return values[entryIndex];
         }

         public double setValue(double value) {
          return put(entryIndex, value);
         }

         public Double setValue(Double value) {
          return put(entryIndex, ((value).intValue()));
         }
        };
       }

       public void remove() {
        throw new UnsupportedOperationException();
       }
      };
     }

     public boolean remove(Object k) {
      throw new UnsupportedOperationException();
     }

     public boolean contains(Object o) {
      if (!(o instanceof java.util.Map.Entry)) {
       return false;
      }

      double v = ((Double)o);
      for (int i = 0; i < values.length; i++) {
       if (values[i] == v) {
        return true;
       }
      }
      return false;
     }

     public int size() {
      return values.length;
     }
    };
   }
  };
 }


}
