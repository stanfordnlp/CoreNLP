/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

/**
 * Hint for marking an Argument field with a particular policy
 * during parse.  If the policy is REQUIRED and no value is provided,
 * then an {@link ArgumentPopulator} will flags an error.  Similarly,
 * if the policy is RECOMMENDED and no value is provided, the populator will
 * flag a warning.
 * 
 * @author dramage
 */
public enum ArgumentPolicy {
	/**
	 * The argument parser will signal an error if a REQUIRED
	 * field is missing.
	 */
	REQUIRED,
	
	/**
	 * The argument parser will signal a warning is a RECOMMENDED
	 * field is missing.
	 */
	RECOMMENDED,
	
	/**
	 * The argument parser will signal no errors or warnings if
	 * an OPTIONAL field is missing.
	 */
	OPTIONAL;
	
	
	/** The default argument policy: OPTIONAL */
	public static ArgumentPolicy DEFAULT = OPTIONAL;
}
