/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.arguments;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation for marking a field as an argument.  Requires a descriptive
 * usage string for use, e.g., in displaying help messages.  Other optional
 * argument annotations for the field are defined internally.
 * 
 * @author dramage
 */
@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Argument {

	/** Doc string to print for help */
	String value();
	
	//
	// Sub-annotation definitions
	//

	/**
	 * Annotation for marking inclusion of all arguments contained
	 * in the given field.
	 */
	@Documented
	@Target({ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface ArgumentsInside { }

	/** Global name of annotation; defaults to fully qualified field name. */ 
	@Documented
	@Target({ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Name {
		String value();
	}

	/**
	 * Annotation for marking the switch used to define the given
	 * argument.  Example usage:
	 * 
	 * Argument.Switch({"--switch","-s"})
	 * 
	 * Means that --switch VALUE or -s VALUE will populate this field.
	 * 
	 * Or just: Argument.Switch("--switch") for a single switch.
	 */
	@Documented
	@Target({ElementType.FIELD, ElementType.PARAMETER})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Switch {
		/** Switch to accept on the command line */
		String[] value();
	}
	
	/**
	 * Annotation for marking the field as required, recommended,
	 * or optional.
	 */
	@Documented
	@Target({ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Policy {
		/** Description of the feature for help message */
		ArgumentPolicy value();
	}

	/**
	 * The default String (as if it were typed) for the marked field.
	 * Provides an easy way to specify complex default types, e.g. URLs
	 * without needing to worry about catching exceptions.
	 */
	@Documented
	@Target({ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Default {
		String value();
	}

	/**
	 * Marks the given method as a 'check' method for checking arg validity.
	 * Called automatically after some arguments have been processed, and
	 * may be called more than one time.  The method should take no
	 * arguments and may throw an ArgumentException if the argument values
	 * specified aren't valid.
	 */
	@Documented
	@Target({ElementType.METHOD})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Check {}
	
	/**
	 * Marks the given name as the name of the box.  Goes on surrounding
	 * class definition.
	 */
	@Documented
	@Target({ElementType.TYPE})
	@Retention(RetentionPolicy.RUNTIME)
	public @interface BoxName {
		String value();
	}
}
