/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.util.LinkedList;
import java.util.List;

import org.w3c.dom.Document;

import edu.stanford.cs.ra.arguments.Argument;
import edu.stanford.cs.ra.arguments.ArgumentPolicy;
import edu.stanford.cs.ra.arguments.Arguments;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.xml.XMLUtils;

/**
 * Entry point for generated .jar files.  Reads META-RA/invocation.xml
 * to reconstruct the parameters of the original run.
 * 
 * @author dramage
 */
@Argument.BoxName("RA.JarRunner")
public class JarRunner {
	@Argument("Action to perform on experiment record")
	@Argument.Switch("--ra-action")
	@Argument.Policy(ArgumentPolicy.REQUIRED)
	static JarRunnerAction action;
	
	public static void main(String[] argv) throws Exception {
		Arguments.parse(argv, JarRunner.class);
		action.run();
	}
	
	/** All runnable actions */
	enum JarRunnerAction {
		help(Help.class), run(ReRun.class), saved(SavedRun.class);
		
		private Class<? extends Runnable> type;
		private JarRunnerAction(Class<? extends Runnable> type) {
			this.type = type;
		}
		
		public void run() {
			try {
				type.newInstance().run();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	/** Display a help message. */
	static class Help implements Runnable {
		public void run() {
			System.out.println("Do the help");
		}
	}

	/** Re-runs with the same arguments. */
	static class ReRun implements Runnable {
		public void run() {
			Document doc = IOUtils.readXML(ClassLoader.getSystemResourceAsStream("META-RA/invocation.xml"));

			// read arguments that are not --ra-*
			List<String> savedArgv = XMLUtils.xpathList(doc, "/invoke/environment/arguments/arg/text()");
			List<String> filteredArgv = new LinkedList<String>();
			for (int i = 0; i < savedArgv.size(); i++) {
				if (savedArgv.get(i).startsWith("--ra-")) {
					i += 1;
				} else {
					filteredArgv.add(savedArgv.get(i));
				}
			}
			
			String[] array = new String[filteredArgv.size()];
			for (int i = 0; i < array.length; i++) {
				array[i] = savedArgv.get(i);
			}
			
			try {
				Class<?> main = Class.forName(XMLUtils.xpathList(doc, "/invoke/@class").get(0));
				main.getMethod("main", String[].class).invoke(null, (Object)array);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	/** Outputs old log */
	static class SavedRun implements Runnable {
		public void run() {
			for (String line : IOUtils.readLines(ClassLoader.getSystemResourceAsStream("META-RA/invocation.xml"))) {
				System.out.println(line);
			}
		}
	}
}
