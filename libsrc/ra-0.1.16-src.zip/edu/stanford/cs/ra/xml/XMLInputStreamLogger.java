/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.io.IOException;
import java.io.InputStream;

import edu.stanford.cs.ra.util.IOUtils;

/**
 * Wraps an InputStream, interpreting all read bytes as part of a
 * character stream to be logged to an XMLStream, up to a
 * maximum number of bytes per line.  InputStream bytes are 
 * interpreted as per the current system character encoding,
 * i.e. by {@link String#String(byte[])}).  Only up to
 * {@link XMLInputStreamLogger#MAXIMUM_BYTES_PER_LINE} bytes
 * will be logged for each line (as determined by the presence
 * of '\n').
 * 
 * @author dramage
 */
public class XMLInputStreamLogger extends InputStream {

	/**
	 * The maximum number of bytes that will be output in a single
	 * line to the wrapped XMLStream.
	 * line. */
	public static final int MAXIMUM_BYTES_PER_LINE = 2*1024;
	
	/** Wrapped inner input stream */
	public final InputStream wrapped;
	
	/** XMLOutput stream to log bytes to */
	public final XMLStream out;
	
	/** Tag to use when writing to out */
	public final String tag;
	
	/** Buffer of read bytes */
	private final byte[] buffer = new byte[MAXIMUM_BYTES_PER_LINE];
	
	/** Number of bytes read */
	private int read = 0;
	
	/**
	 * Instantiates the XMLInputStreamLogger to read and return bytes
	 * from the given input stream, logging all bytes read to the given
	 * output XMLStream with the given tag.
	 */
	public XMLInputStreamLogger(InputStream wrapped, XMLStream out, String tag) {
		this.wrapped = wrapped;
		this.out = out;
		this.tag = tag;
		
		IOUtils.closeOnExit(this);
	}
	
	/**
	 * Reads and returns a byte from the underlying wrapped InputStream.
	 * Also adds that byte to the queue of bytes read.
	 */
	@Override
	public int read() throws IOException {
		int b = wrapped.read();
		
		if (b >= 0) {
			buffer[read++] = (byte)b;
			if (read >= buffer.length || b == '\n') {
				flush();
			}
		}
		
		return b;
	}
	
	@Override
    public int read(byte b[], int off, int len) throws IOException {
		// wait for some bytes to become available
		while (available() == 0) {
			Thread.yield();
		}
		
		// read up to len bytes or however many are available
		final int toRead = Math.min(available(), len);

		// fill up the buffer
		for (int i = 0; i < toRead; i++) {
			final int next = read();
			if (next < 0) {
				return i;
			} else {
				b[off+i] = (byte)next;
			}
		}
		
		return toRead;
	}
	
	@Override
	public int available() throws IOException {
		return wrapped.available();
	}
	
	/**
	 * Closes the underlying input stream.
	 */
	@Override
	public void close() throws IOException {
		wrapped.close();
		super.close();
		flush();
	}
	
	/**
	 * Sends the bytes in the buffer to out.
	 */
	private void flush() {
		if (read > 0) {
			read = 0;
			out.line(tag, new String(buffer, 0, read));
		}
	}
}
