/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;

import java.util.LinkedList;
import java.util.List;

import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * Provides n-way branching of an XML stream.
 * 
 * @author dramage
 */
public class BranchedXMLStream implements XMLStream {

	/** Wrapped streams */
	private final List<XMLStream> streams = new LinkedList<XMLStream>();

	/**
	 * Initializes to branch to the given list of streams.
	 */
	public BranchedXMLStream(XMLStream ... streams) {
		for (XMLStream stream : streams) {
			addStream(stream);
		}
	}

	/**
	 * Adds a stream to the list of branches or throws QuietIOException
	 * if the stream is already open.
	 */
	public void addStream(XMLStream stream) {
		if (streams.size() > 0 && getTagStack().size() > 0 || stream.getTagStack().size() > 0) {
			throw new QuietIOException("Cannot add stream to the BranchedXMLStream - tags already open");
		}
		streams.add(stream);
	}
	
	/**
	 * Tells all registered streams to begin.
	 */
	public XMLStream begin(String tag, Object... args) {
		for (XMLStream stream : streams) {
			stream.begin(tag, args);
		}
		return this;
	}

	/**
	 * Tells all registered streams to end.
	 */
	public XMLStream end(String tag) {
		for (XMLStream stream : streams) {
			stream.end(tag);
		}
		return this;
	}

	/**
	 * Tells all registered streams to add a line.
	 */
	public XMLStream line(String tag, Object body, Object... args) {
		for (XMLStream stream : streams) {
			stream.line(tag, body, args);
		}
		return this;
	}

	/**
	 * Tells all registered streams to add the xml.
	 */
	public XMLStream xml(EscapedXML xml) {
		for (XMLStream stream : streams) {
			stream.xml(xml);
		}
		return this;
	}
	
	/**
	 * Closes all registered streams.
	 */
	public void close() {
		for (XMLStream stream : streams) {
			stream.close();
		}
	}
	
	/**
	 * Returns the stack trace of the first XML stream.
	 */
	public List<String> getTagStack() {
		return streams.get(0).getTagStack();
	}

}
