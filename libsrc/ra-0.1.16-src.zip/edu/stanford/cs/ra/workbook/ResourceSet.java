/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.URI;

import edu.stanford.cs.ra.util.IOUtils.QuietIOException;

/**
 * Set of resources with String names; splits by "/" on all architectures.
 * 
 * @author dramage
 */
public interface ResourceSet extends Serializable {

	/**
	 * Lists all resources in the root of this ResourceSet.  Equivalent
	 * to calling <code>listResources("")</code>.
	 */
	public String[] listResources();
	
	/**
	 * Lists all resources that are direct children of this resource set
	 * within the given <code>path</code>, which should specify a valid
	 * folder path ("/"-delimited) relative to this resource's root.  Initial
	 * "/" is optional.  Some resources may optionally but not necessarily
	 * support wildcards such as "*".
	 * 
	 * @param path "/"-delimited folder name within this resource.
	 * @return Array of paths to direct children of the given resource folder.
	 *   Note that each returned path should include the given <code>path</code>
	 *   as a prefix. The array may be of length 0 but is always non-null.
	 */
	public String[] listResources(String path);
	
	/** Returns true if there exists a resource with the given name */
	public boolean hasResource(String path);
	
	/**
	 * Returns an InputStream for reading a resource with the given name.
	 */
	public InputStream getInputStream(String path) throws QuietIOException;
	
	/**
	 * Returns an OutputStream for writing to the given named resource.
	 */
	public OutputStream getOutputStream(String path) throws QuietIOException;
	
	/**
	 * Returns a unique URI describing the absolute path resource, if possible.
	 */
	public URI getInputURI(String path);
	
	/**
	 * Returns a unique URI describing the absolute path resource, if possible.
	 */
	public URI getOutputURI(String path);
}
