/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNInfo;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNStatus;
import org.tmatesoft.svn.core.wc.SVNStatusClient;
import org.tmatesoft.svn.core.wc.SVNStatusType;

import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.IOUtils;
import edu.stanford.cs.ra.util.PathUtils;

/**
 * Utilities for dealing with source code versioning systems (currently only
 * Subversion is supported).
 * 
 * @author dramage
 */
public abstract class VersionControl {

//	/** The global SVN client manager */
//	private static SVNClientManager svn = SVNClientManager.newInstance();
	
	/**
	 * Create a set of VersionControl archives in the given
	 * ZipOutputStream.  Currently only supports subversion.
	 * 
	 * @throws VersionControlException on error.
	 */
	public static void createPacks(File[] roots, ZipOutputStream zip, String prefix) throws VersionControlException {
		if (!prefix.endsWith("/")) { prefix += "/"; }
		
		for (File root : roots) {
			createPack(root, zip, prefix);
		}
	}
	
	/**
	 * Create a VersionControl archive (.zip) into the given
	 * ZipOutputStream.  Currently only supports subversion.
	 * 
	 * @throws VersionControlException On error.
	 */
	public static void createPack(File root, ZipOutputStream zip, String prefix) throws VersionControlException {
		if (!prefix.endsWith("/")) { prefix += "/"; }
		
		System.err.print("RA: Creating source archive for "+root+" ... ");
		boolean isSVN = true;
		try {
			SVNClientManager.newInstance().getStatusClient().doStatus(root, false);
		} catch (SVNException e) {
			isSVN = false;
		}
		
		if (isSVN) {
			createSVNPack(root, zip, prefix);
		} else {
			throw new VersionControlException(root+" is not a valid subversion checkout");
		}
		System.err.println("done");
	}
	
	/**
	 * Creates a zip archive containing all version information, plus diffs,
	 * plus any new non-ignored files writing to the given output stream.
	 */
	private static void createSVNPack(File root, ZipOutputStream zip, String prefix) {
		if (!prefix.endsWith("/")) { prefix += "/"; }
		
		SVNClientManager manager = SVNClientManager.newInstance();

		String url = null;
		
		// get the repository url, and use its hash for the folder name
		try {
			SVNInfo info = manager.getWCClient().doInfo(root, SVNRevision.WORKING);
			url = info.getURL().toString();
		} catch (Exception e) {
			throw new VersionControlException("Unable to get repository info", e);
		}

		// write output into a hashed subfolder
		prefix += String.format("%08d%s", url.hashCode() % 100000000, "/");
		try {
			zip.putNextEntry(new ZipEntry(prefix));
			zip.closeEntry();
		} catch (Exception e) {
			throw new VersionControlException("Unable to create folder");
		}
		
		// output diff
		try {
			zip.putNextEntry(new ZipEntry(prefix+"repository.url"));
			zip.write(url.getBytes());
			zip.closeEntry();
		} catch (Exception e) {
			throw new VersionControlException("Unable to write repository URL", e);
		}
		
		try {
			zip.putNextEntry(new ZipEntry(prefix+"repository.patch"));
			manager.getDiffClient().doDiff(
					root, SVNRevision.BASE,
					root, SVNRevision.WORKING,
					true, true, zip);
			zip.closeEntry();
		} catch (Exception e) {
			throw new VersionControlException("Unable to get diff", e);
		}
		
		
		// get status and revision information for whole tree
		SVNStatusClient client = manager.getStatusClient();
		
		Map<File,SVNStatusType> status = new TreeMap<File,SVNStatusType>();
		Map<File,SVNRevision> revision = new TreeMap<File,SVNRevision>();

		LinkedList<File> queue = new LinkedList<File>();
		queue.add(root);
		while (!queue.isEmpty()) {
			File node = queue.removeFirst();

			if (node.getName().equals(".svn")) {
				// ignore meta-folders
				continue;
			}

			boolean isNew = false;
			try {
				SVNStatus nodeStatus = client.doStatus(node.getAbsoluteFile(), false);

				status.put(node, nodeStatus.getContentsStatus());
				revision.put(node, nodeStatus.getRevision());

				isNew = status.get(node) == SVNStatusType.STATUS_UNVERSIONED;
			} catch (SVNException e) {
				// move on silently
				continue;
			}

			if (node.isDirectory() && !isNew) {
				queue.addAll(Arrays.asList(node.listFiles()));
			}
		}

		// output max revision number
		try {
			long rev = -1;
			for (SVNRevision r : revision.values()) {
				rev = Math.max(rev, r.getNumber()); 
			}
			zip.putNextEntry(new ZipEntry(prefix+"repository.revision"));
			zip.write((""+rev).getBytes());
			zip.closeEntry();
		} catch (IOException e) {
			throw new VersionControlException("Unable to write repository.revision");
		}
		
		// output status
		try {
			zip.putNextEntry(new ZipEntry(prefix+"repository.status"));
			OutputStreamWriter writer = new OutputStreamWriter(zip);
			for (File file : status.keySet()) {
				writer.append(PathUtils.relativePath(file,root)).append("\t");
				writer.append(revision.get(file).toString()).append("\t");
				writer.append(status.get(file).toString()).append("\n");
			}
			writer.flush();
			zip.closeEntry();
		} catch (IOException e) {
			throw new VersionControlException("Unable to write repository.status", e);
		}

		// copy new files not in version control
		for (File file : status.keySet()) {
			if (status.get(file) == SVNStatusType.STATUS_UNVERSIONED) {
				IOUtils.zip(zip, file, root, prefix+"unversioned/", true);
			}
		}
	}
	
	public static Set<String> listPacks(File zipfile, String prefix) {
		if (!prefix.endsWith("/")) { prefix += "/"; }
		final int segmentOffset = prefix.split("/").length;
		
		Set<String> packs = new LinkedHashSet<String>();
		try {
			ZipInputStream zis = new ZipInputStream(IOUtils.openFile(zipfile));
			ZipEntry entry = null;
			while ((entry = zis.getNextEntry()) != null) {
				//System.err.println("!! "+entry.getName());
				if (entry.getName().startsWith(prefix) && !entry.getName().equals(prefix)) {
					packs.add(entry.getName().split("/")[segmentOffset]);
				}
			}
			zis.close();
		} catch (Exception e) {
			throw new VersionControlException("Unable to read archive", e);
		}
		
		return packs;
	}
	
	/**
	 * TODO: deal with the absolute paths in the patch file (borked!)
	 * TODO: deal with relative directory structure issues
	 * 
	 * @param zipfile
	 * @param prefix
	 * @param pack
	 * @param target
	 */
	public static void restorePack(ZipFile zipfile, String prefix, String pack, File target) {
		if (!prefix.endsWith("/")) { prefix += "/"; }
		if (!pack.endsWith("/")) { pack += "/"; }
		
		if (target.exists() && !(target.isDirectory() && target.listFiles().length == 0)) {
			throw new VersionControlException("Unable to restore pack "+pack+": "+target+" already exists");
		}

		// get list of unversioned files
		final String unversioned = prefix+pack+"unversioned/";
		final int segmentOffset = unversioned.split("/").length;
		Set<String> files = new LinkedHashSet<String>();
		try {
			ZipInputStream zis = new ZipInputStream(IOUtils.openFile(new File(zipfile.getName())));
			ZipEntry entry = null;
			while ((entry = zis.getNextEntry()) != null) {
				//System.err.println("!! "+entry.getName());
				if (entry.getName().startsWith(unversioned) && !entry.getName().equals(unversioned)) {
					files.add(entry.getName());
				}
			}
			zis.close();
		} catch (Exception e) {
			throw new VersionControlException("Unable to read archive", e);
		}

		
		try {
			String url = IOUtils.readLines(zipfile.getInputStream(new ZipEntry(prefix+pack+"repository.url"))).iterator().next();
			String rev = IOUtils.readLines(zipfile.getInputStream(new ZipEntry(prefix+pack+"repository.revision"))).iterator().next();
			
//			FileOutputStream patchOut = new FileOutputStream(new File(target, "repository.patch"));
//			IOUtils.drain(zipfile.getInputStream(new ZipEntry(prefix+pack+"repository.patch")), patchOut);
//			patchOut.close();
			
			System.out.println("Run the following commands:\n" +
					"  svn co -r "+rev+" "+url+"\n"+
					"  unzip -p "+zipfile.getName()+" \""+prefix+pack+"repository.patch\" | patch .\n" +
					"  unzip "+zipfile.getName()+" "+Stringify.escapedQuotedJoin(files, ' ', '"'));
			System.out.println("Run the following commands: ");
		} catch (Exception e) {
			throw new VersionControlException("Unable to restore "+pack, e);
		}
	}
	
//	/**
//	 * Signature of a file.
//	 * 
//	 * @author dramage
//	 */
//	public static class VersionControlSignature {
//		
//		/** Name of the file */
//		public final String name;
//		
//		/** Modification date of the file */
//		public final String md5;
//		
//		/** Version control URL of the file or null */
//		public final String vcURL;
//		
//		/** Version control version ID of the file or null */
//		public final String vcVersion;
//		
//		VersionControlSignature(String name, String md5, String vcURL, String vcVersion) {
//			this.name = name;
//			this.md5 = md5;
//			this.vcURL = vcURL;
//			this.vcVersion = vcVersion;
//		}
//		
//		@Override
//		public String toString() {
//			return Stringify.escapedJoin(Arrays.asList(new String[]{
//					name, md5, vcURL, vcVersion}), '\t');
//		}
//		
//		/** Registers this class in the Stringify infrastructure */ 
//		@StaticFromString
//		public static VersionControlSignature fromString(String string) {
//			List<String> values = Stringify.escapedSplit(String.class, string, '\t');
//			return new VersionControlSignature(
//					values.get(0), values.get(1),
//					values.get(2), values.get(3));
//		}
//	}
	
	/**
	 * Exception caused while creating or manipulating a source code
	 * revision archive.  Usually used as a chained exception (i.e.
	 * getCause).
	 * 
	 * @author dramage
	 */
	public static class VersionControlException extends RuntimeException {
		public VersionControlException(String message, Throwable cause) {
			super(message, cause);
		}
		public VersionControlException(String message) {
			super(message);
		}
		private static final long serialVersionUID = 1L;
	}
}
