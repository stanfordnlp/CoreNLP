/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stringify;

import edu.stanford.cs.ra.stringify.Stringify.StaticFromString;
import edu.stanford.cs.ra.stringify.Stringify.StaticToString;
import edu.stanford.cs.ra.stringify.Stringify.StringifyException;

/**
 * ToString and FromString for primitive types.
 * 
 * @author dramage
 */
class StringifyPrimitives {
	
	@StaticToString
	@StaticFromString
	public static String toString(String in) {
		return in;
	}
	
	@StaticFromString
	public static int toInt(String in) {
		try {
			return Integer.parseInt(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_VALUE")) {
				return Integer.MAX_VALUE;
			} else if (in.equals("MIN_VALUE")) {
				return Integer.MIN_VALUE;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Integer toWrappedInteger(String in) {
		return toInt(in);
	}
	
	@StaticFromString
	public static long toLong(String in) {
		try {
			return Long.parseLong(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_VALUE")) {
				return Long.MAX_VALUE;
			} else if (in.equals("MIN_VALUE")) {
				return Long.MIN_VALUE;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Long toWrappedLong(String in) {
		return toLong(in);
	}
	
	@StaticFromString
	public static float toFloat(String in) {
		try {
			return Float.parseFloat(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_EXPONENT")) {
				return Float.MAX_EXPONENT;
			} else if (in.equals("MAX_VALUE")) {
				return Float.MAX_VALUE;
			} else if (in.equals("MIN_EXPONENT")) {
				return Float.MIN_EXPONENT;
			} else if (in.equals("MIN_VALUE")) {
				return Float.MIN_VALUE;
			} else if (in.equals("MIN_NORMAL")) {
				return Float.MIN_NORMAL;
			} else if (in.toLowerCase().equals("nan")) {
				return Float.NaN;
			} else if (in.equals("NEGATIVE_INFINITY") ||
					in.equalsIgnoreCase("-inf") ||
					in.equalsIgnoreCase("-Infinity")) {
				return Float.NEGATIVE_INFINITY;
			} else if (in.equals("POSITIVE_INFINITY") ||
					in.equalsIgnoreCase("inf") ||
					in.equalsIgnoreCase("Infinity")) {
				return Float.POSITIVE_INFINITY;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Float toWrappedFloat(String in) {
		return toFloat(in);
	}
	
	@StaticFromString
	public static double toDouble(String in) {
		try {
			return Double.parseDouble(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_EXPONENT")) {
				return Double.MAX_EXPONENT;
			} else if (in.equals("MAX_VALUE")) {
				return Double.MAX_VALUE;
			} else if (in.equals("MIN_EXPONENT")) {
				return Double.MIN_EXPONENT;
			} else if (in.equals("MIN_VALUE")) {
				return Double.MIN_VALUE;
			} else if (in.equals("MIN_NORMAL")) {
				return Double.MIN_NORMAL;
			} else if (in.toLowerCase().equals("nan")) {
				return Double.NaN;
			} else if (in.equals("NEGATIVE_INFINITY") ||
					in.equalsIgnoreCase("-inf") ||
					in.equalsIgnoreCase("-Infinity")) {
				return Double.NEGATIVE_INFINITY;
			} else if (in.equals("POSITIVE_INFINITY") ||
					in.equalsIgnoreCase("inf") ||
					in.equalsIgnoreCase("Infinity")) {
				return Double.POSITIVE_INFINITY;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Double toWrappedDouble(String in) {
		return toDouble(in);
	}
	
	@StaticFromString
	public static char toChar(String in) {
		if (in.length() == 1) {
			return in.charAt(0);
		}
		
		// try un-escaping
		String unescaped = Stringify.unescape(in);
		if (unescaped.length() == 1) {
			return unescaped.charAt(0);
		}
		
		// try lookup field
		try {
			return Character.class.getField(in).getChar(null);
		} catch (Exception e) {
			// ignored
		}
		
		throw new StringifyException("Invalid character: "+in);
	}
	
	@StaticFromString
	public static Character toWrappedCharacter(String in) {
		return toChar(in);
	}
	
	@StaticFromString
	public static byte toByte(String in) {
		try {
			return Byte.parseByte(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_VALUE")) {
				return Byte.MAX_VALUE;
			} else if (in.equals("MIN_VALUE")) {
				return Byte.MIN_VALUE;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Byte toWrappedByte(String in) {
		return toByte(in);
	}
	
	@StaticFromString
	public static short toShort(String in) {
		try {
			return Short.parseShort(in);
		} catch (NumberFormatException nfe) {
			if (in.equals("MAX_VALUE")) {
				return Short.MAX_VALUE;
			} else if (in.equals("MIN_VALUE")) {
				return Short.MIN_VALUE;
			} else {
				throw new StringifyException(nfe);
			}
		}
	}
	
	@StaticFromString
	public static Short toWrappedShort(String in) {
		return toShort(in);
	}

	@StaticFromString
	public static boolean toBoolean(String in) {
		if (in.equalsIgnoreCase("true")) {
			return true;
		} else if (in.equalsIgnoreCase("false")) {
			return false;
		}
		throw new StringifyException("Invalid boolean: "+in);
	}
	
	@StaticFromString
	public static Boolean toWrappedBoolean(String in) {
		return toBoolean(in);
	}

}
