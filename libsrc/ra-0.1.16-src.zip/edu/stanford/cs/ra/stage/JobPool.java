package edu.stanford.cs.ra.stage;

/**
 * A set of StageRunners with no inter-dependencies that can be run in any
 * order.  Communicates with the {@link StageQueue} such that any time while
 * executing a stage dependency tree, the JobPool will contain the maximal
 * set of jobs that can be run (in any order) given the jobs that have
 * already completed. 
 * 
 * This class is currently unused.
 * 
 * @author dramage
 */
interface JobPool {

	/**
	 * Adds the given job with the given priority to this job pool.  When
	 * the job completes, the given JobListener will be notified.
	 * @param job Job to run
	 * @param priority Higher value is a hint that the job should take
	 *   precedence versus jobs added with a lower priority
	 * @param listener Callback when job completes
	 */
	public void addJob(StageRunner job, double priority, JobListener listener);
	
	/**
	 * {@link JobPool} callback listener, notified when a job completes.
	 * 
	 * @author dramage
	 */
	public interface JobListener {
		
		/** Called by JobPool when the given job has finished. */
		public void completed(StageRunner job);
	}
}
