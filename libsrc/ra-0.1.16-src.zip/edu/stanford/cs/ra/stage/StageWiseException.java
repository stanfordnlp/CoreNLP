package edu.stanford.cs.ra.stage;

/**
 * Runtime exception for cyclic dependencies in a StageGraph.
 */
public class StageWiseException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public StageWiseException(String message, Throwable cause) {
		super(message, cause);
	}
	public StageWiseException(String message) {
		super(message);
	}
}