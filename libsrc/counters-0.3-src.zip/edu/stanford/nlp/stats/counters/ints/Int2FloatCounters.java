

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/*		 
 * fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2002-2007 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.ints;
import it.unimi.dsi.fastutil.objects.*;
import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.ints.*;
import it.unimi.dsi.fastutil.floats.*;
import java.util.Map;
import java.util.Iterator;
import java.util.Random;
/** A class providing static methods and objects that do useful things with
 * type-specific counters.
 */
public class Int2FloatCounters {
 /** Cannot instantiate */
 private Int2FloatCounters() {}
 /**
	 * Retains all non-zero entries in the counter.
	 */
 public static void retainNonZeros(Int2FloatCounter counter) {
  final Iterator<Int2FloatMap.Entry > entries
    = counter.int2FloatEntrySet().iterator();
  while (entries.hasNext()) {
   final Int2FloatMap.Entry entry = entries.next();
   if (entry.getFloatValue() == 0f) {
    entries.remove();
   }
  }
 }
 /**
	 * Returns a random key from the given counter with probability in
	 * proportion to its total().
	 * @throws IllegalArgumentException if the counter contains no elements.
	 */
 public static int sample(Int2FloatCounter counter, Random random) {
  if (counter.size() == 0) {
   throw new IllegalArgumentException("Cannot sample from empty counter");
  }
  final double threshold = random.nextDouble();
  final double total = (double)counter.total();
  double sum = 0;
  for (Int2FloatMap.Entry entry : counter.int2FloatEntrySet()) {
   sum += (double)(entry.getValue()) / total;
   if (sum > threshold) {
    return entry.getKey();
   }
  }
  return counter.keySet().iterator().next();
 }
 /**
	* Returns a counter backed by the given array.
	*/
 public static Int2FloatCounter forArray(final float[] array) {
  float tmpTotal = 0;
  for (float v : array) {
   tmpTotal += v;
  }
  final float arrayTotal = tmpTotal;
  return new AbstractInt2FloatCounter () {
   private static final long serialVersionUID = 1L;
   final float[] values = array;
   float total = arrayTotal;
   @Override
   public boolean containsKey(int key) {
    return key >= 0 && key < values.length;
   }
   @Override
   public float get(int key) {
    return values[key];
   }
   @Override
   public float put(int key, float value) {
    final float old = values[key];
    values[key] = value;
    total += value - old;
    return old;
   }
   @Override
   public int size() {
    return values.length;
   }
   @Override
   protected float adjust(int key, float adjustAmount) {
    final float old = values[key];
    values[key] += adjustAmount;
    total += adjustAmount;
    return old;
   }
   @Override
   public float total() {
    return total;
   }
   @Override
   public ObjectSet<Int2FloatMap.Entry > int2FloatEntrySet() {
    return new AbstractObjectSet<Int2FloatMap.Entry >() {
     public ObjectIterator<Int2FloatMap.Entry > iterator() {
      return new ObjectIterator<Int2FloatMap.Entry >() {
       int index = 0;
       public int skip(int n) {
        int oldIndex = index;
        index += n;
        index = Math.max(index, values.length);
        return index-oldIndex;
       }
       public boolean hasNext() {
        return index < values.length;
       }
       public Int2FloatMap.Entry next() {
        return new Int2FloatMap.Entry () {
         final int entryIndex = index++;
         public int getIntKey() {
          return entryIndex;
         }

         public Integer getKey() {
          return entryIndex;
         }

         public float getFloatValue() {
          return values[entryIndex];
         }

         public Float getValue() {
          return values[entryIndex];
         }

         public float setValue(float value) {
          return put(entryIndex, value);
         }

         public Float setValue(Float value) {
          return put(entryIndex, ((value).intValue()));
         }
        };
       }

       public void remove() {
        throw new UnsupportedOperationException();
       }
      };
     }

     public boolean remove(Object k) {
      throw new UnsupportedOperationException();
     }

     public boolean contains(Object o) {
      if (!(o instanceof java.util.Map.Entry)) {
       return false;
      }

      float v = ((Float)o);
      for (int i = 0; i < values.length; i++) {
       if (values[i] == v) {
        return true;
       }
      }
      return false;
     }

     public int size() {
      return values.length;
     }
    };
   }
  };
 }


}
