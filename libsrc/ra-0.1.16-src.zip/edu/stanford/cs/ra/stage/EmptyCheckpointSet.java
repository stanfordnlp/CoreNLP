package edu.stanford.cs.ra.stage;

import java.util.Map;

/**
 * Default checkpoint set that provides no checkpoints.
 * 
 * @author dramage
 */
public class EmptyCheckpointSet implements CheckpointSet {

	public void createCheckpoint(StageLineage lineage,
			Map<String, Object> context) {
		// does nothing
		
	}

	public boolean hasCheckpoint(StageLineage lineage) {
		return false;
	}

	public Map<String, Object> loadCheckpoint(StageLineage lineage) {
		throw new IllegalArgumentException("No checkpoints defined");
	}

}
