

/* Generic definitions */






/* Assertions (useful to generate conditional code) */
/* Current type and class (and size, if applicable) */
/* Value methods */
/* Interfaces (keys) */
/* Interfaces (values) */
/* Abstract implementations (keys) */
/* Abstract implementations (values) */
/* Static containers (keys) */
/* Static containers (values) */
/* Implementations */
/* Synchronized wrappers */
/* Unmodifiable wrappers */
/* Other wrappers */
/* Methods (keys) */
/* Methods (values) */
/* Methods (keys/values) */
/* Methods that have special names depending on keys (but the special names depend on values) */
/* Equality */
/* Object/Reference-only definitions (keys) */
/* Primitive-type-only definitions (keys) */
/* Object/Reference-only definitions (values) */
/* Primitive-type-only definitions (values) */
/* Counters */
/* 
 * Counters: Fast & compact NLP data structures for Java
 * Based on fastutil: Fast & compact type-specific collections for Java
 *
 * Copyright (C) 2007 Daniel Ramage
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.stanford.nlp.stats.counters.longs;
import it.unimi.dsi.fastutil.longs.*;
import java.util.Map;
import java.util.NoSuchElementException;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.HashCommon;
import it.unimi.dsi.fastutil.objects.AbstractObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
/**
 * A type-specific counter; provides a {@link Map} from key to numeric values that can be incremented and decremented, along with a running total.
 *
 * @see Map
 * @author dramage
 */
/**
 * A Counter implementation backed by an OpenHashMap.
 * 
 * TODO: worry about readObject
 */
public class Long2LongOpenHashCounter extends Long2LongOpenHashMap implements Long2LongCounter {
 public Long2LongOpenHashCounter() {
  super();
 }
 /** Constructor for given expected number of entries */
 public Long2LongOpenHashCounter(int n) {
  super(n);
 }
 /** Constructor for given expected number of entries, load factor */
 public Long2LongOpenHashCounter(int n, float f) {
  super(n,f);
 }
 /** Copy constructor */
 public Long2LongOpenHashCounter(Long2LongCounter counter) {
  super(counter);
  this.total = counter.total();
 }
 /** Copy constructor */
 public Long2LongOpenHashCounter(Map<Long,? extends Number> map) {
  super(map.size());
  for (Map.Entry<Long,? extends Number> entry : map.entrySet()) {
   put((long)entry.getKey(), entry.getValue().longValue());
  }
 }
 protected long total;
 @Override
 public long put(final long k, final long v) {
  final long rv = super.put(k,v);
  total = total - rv + v;
  return rv;
 }
 @Override
 public Long put(final Long ok, final Long ov) {
  final Long rv = super.put(ok,ov);
  total = total - rv + ov;
  return rv;
 }
 @Override
 public void clear() {
  super.clear();
  total = 0;
 }
 /** The entry class for a hash map does not record key and value, but
	 * rather the position in the hash table of the corresponding entry. This
	 * is necessary so that calls to {@link java.util.Map.Entry#setValue(Object)} are reflected in
	 * the map */
 private final class MapEntry implements Long2LongMap.Entry , Map.Entry<Long, Long> {
  private int index;
  MapEntry( final int index ) {
   this.index = index;
  }
  public Long getKey() {
   return (Long.valueOf(key[ index ]));
  }
  public long getLongKey() {
      return key[ index ];
  }
  public Long getValue() {
   return (Long.valueOf(value[ index ]));
  }

  public long getLongValue() {
   return value[ index ];
  }


  public long setValue( final long v ) {
   final long oldValue = value[ index ];
   value[ index ] = v;
   total = total - oldValue + v;
   return oldValue;
  }



  public Long setValue( final Long v ) {
   return (Long.valueOf(setValue( ((v).longValue()) )));
  }



  @SuppressWarnings("unchecked")
  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<Long, Long> e = (Map.Entry<Long, Long>)o;

   return ( (key[ index ]) == (((e.getKey()).longValue())) ) && ( (value[ index ]) == (((e.getValue()).longValue())) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.long2int(key[ index ]) ^ it.unimi.dsi.fastutil.HashCommon.long2int(value[ index ]);
  }


  public String toString() {
   return key[ index ] + "->" + value[ index ];
  }
 }

 /** An iterator over a hash map. */

 private class MapIterator {
  /** The index of the next entry to be returned. */
  int pos = 0;
  /** The index of the last entry that has been returned. */
  int last = -1;
  /** A downward counter measuring how many entries have been returned. */
  int c = count;

  {
   final byte state[] = Long2LongOpenHashCounter.this.state;
   final int n = state.length;

   if ( c != 0 ) while( pos < n && state[ pos ] != OCCUPIED ) pos++;
  }

  public boolean hasNext() {
   return c != 0 && pos < Long2LongOpenHashCounter.this.state.length;
  }

  public int nextEntry() {
   final byte state[] = Long2LongOpenHashCounter.this.state;
   final int n = state.length;

   if ( ! hasNext() ) throw new NoSuchElementException();
   last = pos;
   if ( --c != 0 ) do pos++; while( pos < n && state[ pos ] != OCCUPIED );

   return last;
  }

  @SuppressWarnings("unchecked")
  public void remove() {
   if (last == -1) throw new IllegalStateException();
   if (state[last] == OCCUPIED) {
    total -= value[last];
   }

   state[last] = REMOVED;







   count--;
  }

  public int skip( final int n ) {
   int i = n;
   while( i-- != 0 && hasNext() ) nextEntry();
   return n - i - 1;
  }
 }


 private class EntryIterator extends MapIterator implements ObjectIterator<Long2LongMap.Entry > {
  public Long2LongMap.Entry next() {
   return new MapEntry( nextEntry() );
  }
 }

 public static class BasicEntry implements Long2LongMap.Entry {
  protected long key;
  protected long value;

  public BasicEntry( final Long key, final Long value ) {
   this.key = ((key).longValue());
   this.value = ((value).longValue());
  }



  public BasicEntry( final long key, final long value ) {
   this.key = key;
   this.value = value;
  }



  public Long getKey() {
   return (Long.valueOf(key));
  }


  public long getLongKey() {
   return key;
  }


  public Long getValue() {
   return (Long.valueOf(value));
  }


  public long getLongValue() {
   return value;
  }


  public long setValue( final long value ) {
   throw new UnsupportedOperationException();
  }



  public Long setValue( final Long value ) {
   return Long.valueOf(setValue(value.longValue()));
  }



  public boolean equals( final Object o ) {
   if (!(o instanceof Map.Entry)) return false;
   Map.Entry<?,?> e = (Map.Entry<?,?>)o;

   return ( (key) == (((((Long)(e.getKey())).longValue()))) ) && ( (value) == (((((Long)(e.getValue())).longValue()))) );
  }

  public int hashCode() {
   return it.unimi.dsi.fastutil.HashCommon.long2int(key) ^ it.unimi.dsi.fastutil.HashCommon.long2int(value);
  }


  public String toString() {
   return key + "->" + value;
  }
 }


 private class FastEntryIterator extends MapIterator implements ObjectIterator<Long2LongMap.Entry > {
  final BasicEntry entry = new BasicEntry ( (0), (0) );
  public BasicEntry next() {
   final int e = nextEntry();
   entry.key = key[ e ];
   entry.value = value[ e ];
   return entry;
  }
 }

 @Override
 public Long remove( final Object ok ) {
  final Long rv = super.remove(ok);
  if (rv != null) {
   total -= rv;
  }
  return rv;
 }

 @Override
 public long remove(final long k) {
  final int oldcount = count;
  final long rv = super.remove(k);
  if (oldcount < count) {
   total -= rv;
  }
  return rv;
 }

 @SuppressWarnings("unchecked")
 @Override
 public Object clone() {
  Long2LongOpenHashCounter c = (Long2LongOpenHashCounter)super.clone();
  c.total = this.total;
  return c;
 }


 private final class MapEntrySet extends AbstractObjectSet<Long2LongMap.Entry > implements Long2LongMap.FastEntrySet {

  public ObjectIterator<Long2LongMap.Entry > iterator() {
   return new EntryIterator();
  }

  public ObjectIterator<Long2LongMap.Entry > fastIterator() {
   return new FastEntryIterator();
  }

  @SuppressWarnings("unchecked")
  public boolean contains( final Object o ) {
   if (!(o instanceof Long2LongMap.Entry)) return false;
   final Long2LongMap.Entry e = (Long2LongMap.Entry )o;
   final int i = findKey( ((e.getKey()).longValue()) );
   return i >= 0 && ( (value[ i ]) == (((e.getValue()).longValue())) );
  }

  @SuppressWarnings("unchecked")
  public boolean remove( final Object o ) {
   if (!(o instanceof Long2LongMap.Entry)) return false;
   final Long2LongMap.Entry e = (Long2LongMap.Entry )o;
   final int i = findKey( ((e.getKey()).longValue()) );
   if ( i >= 0 ) Long2LongOpenHashCounter.this.remove( e.getKey() );
   return i >= 0;
  }

  public int size() {
   return count;
  }

  public void clear() {
   Long2LongOpenHashCounter.this.clear();
  }

 }

 public Long2LongMap.FastEntrySet long2LongEntrySet() {
  if ( entries == null ) entries = new MapEntrySet();
  return entries;
 }

 /**
	 * Increments the value associated with the given key by <code>+adjustAmount</code>,
 	 * returning the value in the map before the increment.  This method is faster than
 	 * incrementing a value in the map with two calls - once to get and once to put -
	 * because it caches the correct insertion point into the hashmap.
	 */
 protected long adjust(final long k, final long adjustAmount) {
  final int i = findInsertionPoint( k );

  total += adjustAmount;

  if (i < 0) {
   final long oldValue = value[-i-1];
   value[-i-1] += adjustAmount;
   return oldValue;
  }

  if ( state[i] == FREE ) free--;
  state[i] = OCCUPIED;
  key[i] = k;
  value[i] = adjustAmount;
  if ( ++count >= maxFill ) {
   int newP = Math.min( p + growthFactor, PRIMES.length - 1 );
   // Just to be sure that size changes when p is very small.
   while( PRIMES[ newP ] == PRIMES[ p ] ) newP++;
   rehash( newP ); // Table too filled, let's rehash
  }
  if ( free == 0 ) rehash( p );
  return defRetValue;
 }
 /** {@inheritDoc} */
 public void incrementAll( Long2LongMap counter ) {
  for (Long2LongMap.Entry entry : counter.long2LongEntrySet()) {
   this.increment(entry.getLongKey(), entry.getLongValue());
  }
 }
 /** {@inheritDoc} */
 public long increment( long key, long amount ) {
  return adjust(key, amount) + amount;
 }
 /** {@inheritDoc} */
 public long increment( long key ) {
  return adjust(key, 1l) + 1l;
 }
 /** {@inheritDoc} */
 public long decrement( long key, long amount ) {
  return adjust(key, -amount) - amount;
 }
 /** {@inheritDoc} */
 public long decrement( long key ) {
  return adjust(key, -1l) - 1l;
 }
 /** {@inheritDoc} */
 public long total() {
  return total;
 }
}
