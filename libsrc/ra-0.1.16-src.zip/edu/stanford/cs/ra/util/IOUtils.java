/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import edu.stanford.cs.ra.RA;
import edu.stanford.cs.ra.xml.XMLStream;

/**
 * Generalized utilities and helpers for input/output.
 *  
 * @author dramage
 */
public class IOUtils {
	
	//
	// mechanism for ensuring that open streams are closed on exit
	//
	
	/** callbacks for calling on exit */
	private static final WeakHashMap<Closeable,Boolean> onExit
		= new WeakHashMap<Closeable,Boolean>();
	
	/**
	 * Registers a shutdown hook to call closeRegisteredStreams unless
	 * RA is active (in which case it will call them manually.
	 */
	static {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			public void run() {
				if (!RA.isActive()) {
					closeRegisteredStreams();
				}
			}
		}));
	}
	
	/**
	 * Closes all streams registered with closeOnExit.
	 */
	public static void closeRegisteredStreams() {
		synchronized (onExit) {
			// close any remaing unclosed references
			for (Closeable closeable : onExit.keySet()) {
				try {
					closeable.close();
				} catch (IOException e) {
					// ignore IO exceptions; we're exiting anyway
				}
			}
		}
	}
	
	/**
	 * Registers a weak reference to the given closeable so that if the object
	 * has not been garbage collection by the time the program exits, IOUtils
	 * will call close on it manually.
	 */
	public static void closeOnExit(Closeable closeable) {
		synchronized (onExit) {
			onExit.put(closeable, true);
		}
	}

	/**
	 * Quietly close a stream.
	 */
	public static void close(InputStream stream) throws QuietIOException {
		try {
			stream.close();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}

	/**
	 * Quietly close a stream.
	 */
	public static void close(OutputStream stream) throws QuietIOException {
		try {
			stream.close();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
	
	//
	// wrapped streams
	//
	
	/**
	 * Wraps the given InputStream with an MD5 calculator.  Calls the given
	 * callback when the stream is closed or when the program exits
	 */
	public static InputStream wrapWithMD5(InputStream stream, MD5Listener callback) {
		return new MD5InputStream(stream, callback);
	}
	
	/**
	 * Wraps the given OutputStream with an MD5 calculator.  Calls the given
	 * callback when the stream is closed or when the program exits
	 */
	public static OutputStream wrapWithMD5(OutputStream stream, MD5Listener callback) {
		return new MD5OutputStream(stream, callback);
	}
	
	
	//
	// opening and reading
	//
	
	/**
	 * Quietly opens a URI using that URI's toURL.
	 */
	public static InputStream openURI(URI uri) throws QuietIOException {
		try {
			return openURL(uri.toURL());
		} catch (MalformedURLException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Opens the given URI but also include a status message printed
	 * to RA.stream containing the MD5 hash of its contents.
	 */
	public static InputStream openURIWithSignature(URI uri) {
		try {
			return openURLWithSignature(uri.toURL());
		} catch (MalformedURLException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Opens the given URI but also include a status message printed
	 * to the given XMLStream containing the MD5 hash of its contents.
	 */
	public static InputStream openURIWithSignature(final URI uri, final XMLStream xmlstream) {
		return IOUtils.wrapWithMD5(openURI(uri), new MD5Listener() {
			public void closed(long bytesRead, String hash) {
				xmlstream.line("IORead", "",
						"name", uri, "type", "uri", "read", bytesRead, "hash", hash);
			}
		});
	}
	
	/**
	 * Quietly opens a URL.
	 */
	public static InputStream openURL(String url) throws QuietIOException {
		try {
			return openURL(new URL(url));
		} catch (MalformedURLException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Opens the given URL but also include a status message printed
	 * to RA.stream containing the MD5 hash of its contents.
	 */
	public static InputStream openURLWithSignature(final String url) {
		try {
			return openURLWithSignature(new URL(url));
		} catch (MalformedURLException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Opens the given URL but also include a status message printed
	 * to the given XMLStream containing the MD5 hash of its contents.
	 */
	public static InputStream openURLWithSignature(final String url, final XMLStream xmlstream) {
		try {
			return openURLWithSignature(new URL(url), xmlstream);
		} catch (MalformedURLException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Quietly opens a URL.
	 */
	public static InputStream openURL(URL url) throws QuietIOException {
		try {
			return new BufferedInputStream(url.openConnection().getInputStream());
		} catch (Exception e) {
			throw new QuietIOException(url.toString(), e);
		}
	}
	
	/**
	 * Opens the given URL but also include a status message printed
	 * to RA.stream containing the MD5 hash of its contents.
	 */
	public static InputStream openURLWithSignature(final URL url) {
		return openURLWithSignature(url, RA.stream);
	}
	
	/**
	 * Opens the given URL but also include a status message printed
	 * to the given XMLStream containing the MD5 hash of its contents.
	 */
	public static InputStream openURLWithSignature(final URL url, final XMLStream xmlstream) {
		return IOUtils.wrapWithMD5(openURL(url), new MD5Listener() {
			public void closed(long bytesRead, String hash) {
				xmlstream.line("IORead", "",
						"name", url, "type", "url", "read", bytesRead, "hash", hash);
			}
		});
	}
	

	/**
	 * Returns an InputStream that reads from the given string.
	 */
	public static InputStream openString(String string) {
		return new ByteArrayInputStream(string.getBytes());
	}
	
	/**
	 * Quietly opens a File.  If the file ends with a ".gz" extension,
	 * automatically opens a GZIPInputStream to wrap the constructed
	 * FileInputStream.
	 */
	public static InputStream openFile(File file) throws QuietIOException {
		try {
			InputStream is = new BufferedInputStream(new FileInputStream(file));
			if (file.getName().endsWith(".gz")) {
				is = new GZIPInputStream(is);
			}
			return is;
		} catch (Exception e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Opens the given File but also include a status message printed
	 * to RA.stream containing the MD5 hash of its contents.
	 */
	public static InputStream openFileWithSignature(final File file) {
		return openFileWithSignature(file, RA.stream);
	}
	
	/**
	 * Opens the given File but also include a status message printed
	 * to the given XMLStream containing the MD5 hash of its contents.  If
	 * the file ends with a ".gz" extension, automatically opens a
	 * GZIPInputStream to wrap the constructed FileInputStream.
	 */
	public static InputStream openFileWithSignature(final File file, final XMLStream xmlstream) {
		try {
			InputStream is = IOUtils.wrapWithMD5(
					new FileInputStream(file), new MD5Listener() {
						public void closed(long bytesRead, String hash) {
							xmlstream.line("IORead", "",
									"name", file, "type", "file", "read", bytesRead, "hash", hash);
						}
					});
			return file.getName().endsWith(".gz") ? new GZIPInputStream(is) : is;
		} catch (Exception e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Returns a single-use Iterable over lines in the given stream.
	 */
	public static Iterable<String> readLines(InputStream stream) throws QuietIOException {
		return new OnePassIterable<String>(
				new LineReaderIterator(new BufferedReader(new InputStreamReader(stream))));
	}

	/**
	 * Returns the XML document contained in the given InputStream
	 */
	public static Document readXML(InputStream stream) throws QuietIOException {
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true); // never forget this!
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			Document doc = builder.parse(stream);
			// stream.close();
			return doc;
		} catch (Exception e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Returns a read-once iterator that reads all objects present in the
	 * ObjectReaderIterator.
	 * 
	 * @throws QuietIOException if unable to read or cannot deserialize
	 *   a particular object.
	 */
	public static <E> Iterable<E> readObjects(InputStream stream) throws QuietIOException {
		try {
			ObjectInputStream ois = stream instanceof ObjectInputStream
				? (ObjectInputStream) stream : new ObjectInputStream(stream);
			return new OnePassIterable<E>(new ObjectReaderIterator<E>(ois));
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Reads an object form an input stream.  If the stream is not an instance
	 * of ObjectInputStream, a wrapper instance is created.  This method
	 * should not be called repeatedly - instead use {@link #readObjects}.
	 * 
	 * @throws QuietIOException if unable to read from the stream or cannot
	 *   deserialize an object.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T readObject(InputStream stream) throws QuietIOException {
		Object obj;
		try {
			ObjectInputStream ois = stream instanceof ObjectInputStream
				? (ObjectInputStream)stream : new ObjectInputStream(stream);
			obj = ois.readObject();
		} catch (Exception e) {
			throw new QuietIOException(e);
		}
		return (T)obj;
	}
	
	/**
	 * Adds the file or directory at <code>path</code> to a ZipOutputStream,
	 * preserving its name and last modified time.  If <code>path</code> is
	 * a directory and <code>recursive</code> is true, all sub-files and
	 * sub-folders are also added.  The given oldPrefix is replaced by
	 * newPrefix in every added file's ZipEntry.
	 * 
	 * Returns the set of added files.
	 */
	public static Collection<File> zip(ZipOutputStream zip, File path, File oldPrefix, String newPrefix, boolean recursive)
			throws QuietIOException {
		
		if (path.isFile()) {
			try {
				ZipEntry entry = new ZipEntry(newPrefix+PathUtils.relativePath(path, oldPrefix));
				entry.setTime(path.lastModified());
				zip.putNextEntry(entry);
				drain(new FileInputStream(path), zip);
	            zip.closeEntry();
	            
	            return Collections.singleton(path);
			} catch (IOException e) {
				throw new QuietIOException(e);
			}
		} else if (path.isDirectory() && recursive) {
			List<File> files = new LinkedList<File>();
			try {
				String name = PathUtils.relativePath(path,oldPrefix);
				if (!name.equals(".")) {
					ZipEntry entry = new ZipEntry(newPrefix+name+"/");
					entry.setTime(path.lastModified());
					zip.putNextEntry(entry);
					zip.closeEntry();
				}
				files.add(path);
			} catch (IOException e) {
				throw new QuietIOException(e);
			}
			
			for (File file : path.listFiles()) {
				files.addAll(zip(zip, file, oldPrefix, newPrefix, true));
			}
			return files;
		} else {
			return Collections.emptySet();
		}
	}
	
	/**
	 * Writes all bytes from the given inputstream to the given output stream.
	 * Closes source when complete but does not close sink.
	 * 
	 * @throws QuietIOException On an IOException
	 */
	public static void drain(InputStream source, OutputStream sink)
		throws QuietIOException {
		
		try {
			byte[] buf = new byte[1024];
			int len;
			while ((len = source.read(buf)) > 0) {
				sink.write(buf, 0, len);
			}
			source.close();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Writes the given String to the given OutputStream, then closes it.
	 */
	public static void writeFinalString(OutputStream out, String string) {
		new PrintStream(out).append(string).close();
	}

	/**
	 * Serializes the given Object to the given OutputStream, then closes it.
	 */
	public static void writeFinalObject(OutputStream out, Object object) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(out);
			oos.writeObject(object);
			oos.close();
			out.close();
		} catch (IOException e) {
			throw new QuietIOException(e);
		}
	}
	
	/**
	 * Iterates through lines in a Reader.
	 */
	private static class LineReaderIterator implements Iterator<String> {

		private BufferedReader reader;
		private String next;
		
		public LineReaderIterator(BufferedReader reader) {
			this.reader = reader;
			next();
		}

		public boolean hasNext() {
			return next != null;
		}

		public String next() {
			String current = next;
			try {
				next = reader.readLine();
				if (next == null) {
					reader.close();
				}
			} catch (IOException e) {
				throw new QuietIOException(e);
			}
			return current;
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}
	}

	/**
	 * Iterates through objects in an ObjectInputStream
	 */
	private static class ObjectReaderIterator<E> implements Iterator<E> {

		private final ObjectInputStream ois;
		private E next;
		
		public ObjectReaderIterator(ObjectInputStream ois) {
			this.ois = ois;
			next();
		}
		
		public boolean hasNext() {
			return next != null;
		}

		@SuppressWarnings("unchecked")
		public E next() {
			E current = next;
			try {
				next = (E) ois.readObject();
			} catch (EOFException e) {
				// thrown when actually out of objects
				next = null;
				try {
					ois.close();
				} catch (IOException ioE) {
					// was going to close it anyway
				}
			} catch (Exception e) {
				// real, horrible exception
				throw new QuietIOException(e);
			}
			return current;
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
	
	/**
	 * One-pass iterable returning a single iterator only once.
	 */
	private static class OnePassIterable<E> implements Iterable<E> {
		private final Iterator<E> iterator;
		private boolean requested = false;

		public OnePassIterable(Iterator<E> iterator) {
			this.iterator = iterator;
		}
		
		public synchronized Iterator<E> iterator() {
			if (requested) {
				throw new QuietIOException("Attempt to read a one-pass Iterable more than once");
			}
			requested = true;
			return iterator;
		}
	}
	
	/**
	 * Listener notified when an MD5-wrapped stream closes.
	 */
	public interface MD5Listener {
		public void closed(long bytesProcessed, String hash);
	}
	
	/**
	 * Runtime wrapper of IOException.
	 * 
	 * @author dramage
	 */
	public static class QuietIOException extends RuntimeException {

		private static final long serialVersionUID = 1L;
		
		public QuietIOException(String msg, Exception cause) {
			super(msg, cause);
		}
		
		public QuietIOException(String msg) {
			super(msg);
		}
		
		public QuietIOException(Exception e) {
			super(e);
		}
	}

}
