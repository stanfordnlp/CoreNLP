/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.stanford.cs.ra.RA;
import edu.stanford.cs.ra.arguments.Argument;
import edu.stanford.cs.ra.arguments.ArgumentPolicy;
import edu.stanford.cs.ra.arguments.ArgumentPopulator;
import edu.stanford.cs.ra.arguments.ArgumentPopulators;
import edu.stanford.cs.ra.arguments.Flag;
import edu.stanford.cs.ra.xml.XMLStream;

/**
 * Runtime context and scheduling for running all stages in a stage dependency
 * graph.
 * 
 * @author dramage
 */
@Argument.BoxName("RA.StageWise")
public class StageWise {
	
	/** Should old lineages be ignored */
	@Argument("When set, StageWise will never load from a checkpoint")
	@Argument.Switch("--ra-fresh")
	Flag freshness;
	
	/** XMLBuilder for output */
	final XMLStream stream;
	
	/** Checkpoints storage info */
	final CheckpointSet checkpoints;

	/** Static argument sources */
	final ArgumentPopulator arguments;
	
	/** Fields in context */
	private final Map<String, Object> context
		= new HashMap<String, Object>();

	/** Shared runners by their lineage */
	final Map<StageLineage,StageRunner> runners
		= new HashMap<StageLineage,StageRunner>();
	
	/** Queue of stages to run */
	final StageQueue queue = new StageQueue(this);
	
	/**
	 * Default constructor uses RA's global arguments, workbook, and
	 * XMLStream
	 */
	public StageWise() {
		this(RA.getArgumentPopulator(), RA.getWorkbook(), RA.streams.log);
	}
	
	/**
	 * Initializes this StageWise to use the given ArgumentParser for
	 * instantiating argument values in stages; the given workbook for
	 * saving results, and the given XMLBuilder for console output.
	 */
	public StageWise(ArgumentPopulator arguments,
			CheckpointSet checkpoints, XMLStream stream) {
		
		this.arguments = arguments;
		this.stream = stream;
		this.checkpoints = checkpoints;
		
		arguments.populate(this);
		
		// export default fields into the context
		setField("StageWise", this);
	}
	
	/**
	 * Runs the {@link StageRunner} instantiated by reflection on the
	 * given class via {@link #run(StageRunner)}.  Returns this for convenience.
	 */
	public StageWise run(Class<?> type) {
		return run(getStageRunner(type));
	}
	
	/**
	 * Runs the {@link StageRunner} instantiated by reflection on the given
	 * class. The runner is given additional arguments that may override those
	 * already provided in this StageWise instance's static argument set.
	 * Returns this for convenience.
	 */
	public StageWise run(Class<?> type, ArgumentPopulator additionalArguments) {
		return run(getStageRunner(type, additionalArguments));
	}
	
	/**
	 * Adds the {@link StageRunner} to the end of the run queue and starts
	 * running stages from the queue until the queue empties.  Returns this
	 * for convenience.
	 */
	public StageWise run(StageRunner runner) {
		queue.enqueue(getSharedRunner(runner));
		queue.runAll();
		return this;
	}

	/**
	 * Returns a {@link StageRunner} instantiated by reflection on the given
	 * type.
	 */
	public StageRunner getStageRunner(Class<?> type) {
		return getSharedRunner(ReflectedStageRunner.fromClass(type, arguments, this));
	}
	
	/**
	 * Returns a {@link StageRunner} instantiated by reflection on the given
	 * class. The runner is given additional arguments that may override those
	 * already provided in this StageWise instance's static argument set.
	 */
	public StageRunner getStageRunner(Class<?> type, ArgumentPopulator additionalArguments) {
		return getSharedRunner(ReflectedStageRunner.fromClass(type,
				ArgumentPopulators.fromPopulators(this.arguments,
						additionalArguments), this));
	}
	
	/**
	 * Gets the StageRunner that should actually be run by hashing on
	 * the given runner's StageDescriptor.
	 */
	StageRunner getSharedRunner(StageRunner runner) {
		StageLineage lineage = StageLineage.fromStageRunner(runner);
		
		if (!runners.containsKey(lineage)) {
			runners.put(lineage, runner);
		}
		return runners.get(lineage);
	}
	
	/**
	 * Returns the set of fields available in this context.
	 */
	public Set<String> getFieldSet() {
		return context.keySet();
	}
	
	/**
	 * Returns true if a value is defined for the given field.
	 */
	public boolean hasField(String field) {
		return context.containsKey(field);
	}

	/**
	 * Returns the unique instance associated with the given NamedType
	 * in this context pool.  If no value exists, return null.
	 */
	@SuppressWarnings("unchecked")
	public <T> T getField(String field) {
		return (T)context.get(field);
	}
	
	/**
	 * Sets the value for the given field, returning the previous
	 * (replaced) value or null if no value was defined for the field.
	 */
	public Object setField(String field, Object value) {
		return context.put(field, value);
	}

	
	//
	// global entry point - runs a named Stage
	//
	
	private static class StageWiseMainArguments {
		/** Arguments for main */
		@Argument("Stage to run")
		@Argument.Switch("--stage")
		@Argument.Policy(ArgumentPolicy.REQUIRED)
		private static Class<? extends Stage> mainStage;
	}
	
	/**
	 * Global entry point.  Runs a named stage.
	 */
	public static void main(String[] argv) {
		RA.begin(argv, StageWiseMainArguments.class);
		new StageWise().run(StageWiseMainArguments.mainStage);
	}

	
	//
	// static utilities and helpers
	//

	/**
	 * Throws a {@link StageWiseException} if the given element is already
	 * in the visited list.
	 */
	static <T> void assertNoCircularDependency(T element, List<T> visited)
		throws StageWiseException {
		
		if (!visited.contains(element)) {
			return;
		}
		
		StringBuilder builder = new StringBuilder("Circular dependency: ");
		for (T s : visited.subList(visited.indexOf(element), visited.size())) {
			builder.append(s).append(" : ");
		}
		builder.append(element);
		throw new StageWiseException("Circular dependency: "+builder.toString());
	}
}
