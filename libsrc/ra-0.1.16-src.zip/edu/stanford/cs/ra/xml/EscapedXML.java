/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.xml;


/**
 * Class that marks a string as pre-escaped XML.
 * 
 * @author dramage
 */
public class EscapedXML {
	public final String xml;
	
	/**
	 * Wraps the given string, which must be valid parseable XML.  Parses
	 * that XML with {@link XMLUtils#documentFromString(String)} to ensure
	 * validity.
	 */ 
	public EscapedXML(String xml) throws XMLException {
		// set the value if it was parseable
		this.xml = xml;
	}
	
	@Override
	public String toString() {
		return this.xml;
	}
	
	/**
	 * Validates the XML in this instance by attempting to parse its contents.
	 * If parsing fails, throws an XMLException that wraps whatever 
	 * underlying problem caused the exception.  Otherwise returns true.
	 */
	public boolean validate() {
		if ((xml.trim().length() > 0) && (xml.indexOf('<') >= 0 || xml.indexOf('>') >= 0)) {
			try {
				XMLUtils.documentFromString(xml);
			} catch (XMLException e) {
				throw e;
			} catch (Exception e) {
				throw new XMLException(e);
			}
		}
		return true;
	}
}
