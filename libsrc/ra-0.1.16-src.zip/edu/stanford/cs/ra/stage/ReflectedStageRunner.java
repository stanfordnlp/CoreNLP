/*
 * Distributed as part of ResearchAssistant, a scientific research tool.
 * 
 * Copyright (C) 2007 Daniel Ramage
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.

 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.

 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 USA 
 */
package edu.stanford.cs.ra.stage;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import edu.stanford.cs.ra.arguments.ArgumentBox;
import edu.stanford.cs.ra.arguments.ArgumentBoxes;
import edu.stanford.cs.ra.arguments.ArgumentPopulator;
import edu.stanford.cs.ra.arguments.ArgumentPopulators;
import edu.stanford.cs.ra.arguments.Arguments;
import edu.stanford.cs.ra.stringify.Stringify;
import edu.stanford.cs.ra.util.ReflectionUtils;

/**
 * A {@link StageRunner} constructed automatically by reading {@link Stage}
 * annotations from a Class.  Create an instance using the {@link #fromClass}
 * static constructor method.
 * 
 * @author dramage
 */
class ReflectedStageRunner implements StageRunner {

	// 
	// static constructor and helpers
	//
	
	/**
	 * Instantiates a ReflectedStageRunner based on the given class using
	 * the given argument source to instantiate values. Throws
	 * {@link StageWiseException} if there is a circular dependency
	 * in the stage annotation graph.
	 */
	static ReflectedStageRunner fromClass(
			Class<?> type, ArgumentPopulator arguments, StageWise stagewise) {
		return fromClass(type, arguments, new LinkedList<Class<?>>(), stagewise);
	}
	
	private static ReflectedStageRunner fromClass(
			Class<?> type, ArgumentPopulator arguments,
			List<Class<?>> visited, StageWise stagewise) {
		
		visited = new LinkedList<Class<?>>(visited);
		visited.add(type);
		
		// create instance
		Object instance = Arguments.instantiate(type);
		
		// populate arguments
		arguments.populate(instance);
		
		// StageRunner prerequisites
		List<StageRunner> required = new LinkedList<StageRunner>(); 
		
		for (RequirementEntry prereq : getRequiredClasses(instance, stagewise)) {
			StageWise.assertNoCircularDependency(prereq.type, visited);
			
			ArgumentPopulator populator =
				ArgumentPopulators.fromPopulators(arguments, prereq.populator);
			
			required.add(fromClass(prereq.type, populator, visited, stagewise));
		}

		return new ReflectedStageRunner(stagewise, instance, required);
	}
	
	/**
	 * Type for bundling a class with an argument populator for that class.
	 */
	private static class RequirementEntry {
		public final Class<?> type;
		public final ArgumentPopulator populator;
		
		public RequirementEntry(Class<?> type, ArgumentPopulator populator) {
			this.type = type;
			this.populator = populator;
		}
	}
	
	/**
	 * Returns the list of Stage classes marked with the {@link Stage.Requires}
	 * annotation with populators for setting their arguments.
	 */
	private static List<RequirementEntry> getRequiredClasses(
			Object instance, StageWise stagewise) {
		
		Class<?> type = instance.getClass();
		
		List<RequirementEntry> required	= new LinkedList<RequirementEntry>();
		Stage.Requires annotation = type.getAnnotation(Stage.Requires.class);
		
		// get prerequisites from stage.Requires class annotation
		if (annotation  != null) {
			required.addAll(getRequirementEntries(type, annotation));
		}
		
		// get prerequisites from Stage.Requires field arguments
		for (Field field : ReflectionUtils.getAllFields(type)) {
			if (field.getAnnotation(Stage.Requires.class) != null) {
				if (field.getAnnotation(Stage.Requires.class).value().length > 0) {
					throw new StageWiseException(
							"Stage.Requires annotation does not expect " +
							"arguments when applied to a field: "+field);
				}
				Class<? extends Stage> stageType
					= ReflectionUtils.getFieldValue(instance, field);
				required.add(new RequirementEntry(stageType,
						ArgumentPopulators.emptyPopulator()));
			}
		}
		
		return required;
	}
	
	/**
	 * Returns an ArgumentPopulator for populating additional arguments
	 * to the particular prerequisite stage.
	 */
	private static List<RequirementEntry> getRequirementEntries(
			Class<?> type, Stage.Requires annotation) {
		
		if (annotation.arguments().length > 0 &&
				annotation.value().length != annotation.arguments().length) {
			
			throw new StageWiseException(
					"Stage.Requires annotation for " + type + " " +
					"must specify either no arguments or exactly one " +
					"argument string for each required class");
		}

		List<RequirementEntry> entries = new LinkedList<RequirementEntry>();
		
		for (int i = 0; i < annotation.value().length; i++)  {
			ArgumentPopulator populator;
			
			if (annotation.arguments().length == 0) {
				populator = ArgumentPopulators.emptyPopulator();
			} else {
				Map<String,String> args = new HashMap<String,String>();
				for (String keyval : Stringify.escapedSplit(
						String.class, annotation.arguments()[i], ',')) {
					int split = keyval.indexOf('=');
					if (split < 0) {
						throw new StageWiseException(
								"Stage.Requires annotaiton for " + type + " " +
								"expects comma delimited list of key=value " +
						"pairs");
					}
					args.put(keyval.substring(0, split),
							keyval.substring(split+1));
				}
				populator = ArgumentPopulators.fromStrings(args);
			}
			
			entries.add(new RequirementEntry(annotation.value()[i], populator));
		}
		
		return entries;
	}
	
	//
	// actual class
	//
	
	/** Descriptor of this stage */
	private final StageDescriptor descriptor;
	
	/** Stage instance */
	private final Object instance;
	
	/** All required stages */
	private final List<StageRunner> requires;

	/** All fields */
	private final Map<String,Field> fields;

	/** {@link Stage.ExportField}s */
	private final List<String> exportFields;

	/** {@link Stage.ImportField}s */
	private final List<String> importFields;

	/**
	 * {@link Stage.ExportField}s that are marked as return values from
	 * method calls.
	 */
	private final Map<String,Method> methodExports =
		new HashMap<String,Method>();
	
	/**
	 * {@link Stage.ImportField}s that are marked on parameters to their
	 * param position.
	 */
	private final Map<String,Integer> parameterImports =
		new HashMap<String,Integer>();
	
	/** Values for each parameter */
	private final Object[] parameterValues;
	
	/** List of run methods */
	private final Method runMethod;
	
	/** True if we have @StageSerialize marked */
	private final boolean serialize;
	
	private ReflectedStageRunner(StageWise stagewise,
			Object instance,
			List<StageRunner> requires) {
		
		Class<?> type = instance.getClass();
		
		this.instance = instance;
		this.requires = requires;

		// instantiate descriptor
		this.descriptor = new StageDescriptor(type.getName(),
				ArgumentBoxes.asMap(getArgumentBox(), false));

		// field information
		this.fields= new HashMap<String,Field>();
		this.exportFields = new LinkedList<String>();
		this.importFields = new LinkedList<String>();
		
		for (Field field : ReflectionUtils.getAllFields(type)) {
			if (field.getAnnotation(Stage.ExportField.class) != null) {
				String fieldName = field.getAnnotation(Stage.ExportField.class).value();
				if (fieldName.length() == 0) {
					fieldName = field.getName();
				}

				fields.put(fieldName, field);
				exportFields.add(fieldName);
			}

			if (field.getAnnotation(Stage.ImportField.class) != null) {
				String fieldName = field.getAnnotation(Stage.ImportField.class).value();
				if (fieldName.length() == 0) {
					fieldName = field.getName();
				}
				
				fields.put(fieldName, field);
				importFields.add(fieldName);
			}

//			// an ExportStream is represented just as a 
//			if (field.getAnnotation(Stage.ExportStream.class) != null) {
//				String fieldName = field.getAnnotation(Stage.ExportStream.class).value();
//				if (fieldName.length() == 0) {
//					fieldName = field.getName();
//				}
//				
//				fieldName = "RA:stream:"+fieldName; 
//				fields.put(fieldName, field);
//				exportFields.add(fieldName);
//			}
		}
		
		// the run method and field export methods
		Method runMethod = null;
		for (Method method : ReflectionUtils.getAllMethods(type)) {
			if (method.getAnnotation(Stage.Run.class) != null) {
				if (runMethod != null) {
					throw new StageWiseException("Stage " +
							type + " (with subclasses) cannot mark more " +
							"than one method with @Stage.Run");
				}
				runMethod = method;
			} else if (method.getAnnotation(Stage.ExportField.class) != null) {
				String name = method.getAnnotation(Stage.ExportField.class).value();
				if (name == null) {
					name = method.getName();
					if (name.startsWith("get")) {
						name = name.substring(3);
					}
				}
				if (exportFields.contains(name)) {
					throw new StageWiseException("Stage "+
							type + " has duplicate export"+name);
				}
				exportFields.add(name);
				methodExports.put(name, method);
			}
		}
		this.runMethod = runMethod;
		if (this.runMethod == null) {
			for (Method method : type.getDeclaredMethods()) {
				if (method.getAnnotation(Stage.Init.class) == null) {
					throw new StageWiseException("Stage " + type +
							" defines methods but none of them are marked" +
							" with @Stage.Run");
				}
			}
		}
		
		if (runMethod == null) {
			this.parameterValues = new Object[0];
		} else {
			// parameters for the run method
			this.parameterValues = new Object[runMethod.getParameterTypes().length];
			final Annotation[][] annotations = runMethod.getParameterAnnotations();

			for (int i = 0; i < parameterValues.length; i++) {
				for (Annotation annotation : annotations[i]) {
					if (annotation.annotationType() == Stage.ExportField.class) {
						throw new StageWiseException("Stage run method " +
								runMethod + " cannot mark parameter values with " +
								"@Stage.ExportField - only imports allowed as " +
						"parameters.");
					} else if (annotation.annotationType() == Stage.ImportField.class) {
						String name = ((Stage.ImportField)annotation).value();
						if (name.length() == 0) {
							throw new StageWiseException("Parameters " +
									"marked with @Stage.ImportField must specify" +
							"a field name");
						}
						importFields.add(name);
						parameterImports.put(name, i);
					}
				}
			}
		}
		
		// TODO: Arguments as parameters
		// ...
		
		// get prerequisites from Stage.Init methods
		for (Method method : ReflectionUtils.getAllMethods(type)) {
			if (method.getAnnotation(Stage.Init.class) != null) {
				Class<?>[] params = method.getParameterTypes();
				Class<?> rettype = method.getReturnType();
				
				if (params.length != 1 || params[0] != StageWise.class ||
						(rettype != null && rettype != new StageRunner[0].getClass())) {
					
					throw new StageWiseException(
							"Stage.Init annotation can only be applied " +
							"to methods that accept a single StageWise " +
							"instance and return StageRunner[] or void:" +
							method);
				}
			
				boolean accessible = method.isAccessible();
				if (!accessible) {
					method.setAccessible(true);
				}

				StageRunner[] rv;
				try {
					rv = (StageRunner[]) method.invoke(instance, stagewise);
				} catch (IllegalArgumentException e) {
					throw new StageWiseException(
							"Unable to run Stage.Init method "+method, e);
				} catch (IllegalAccessException e) {
					throw new StageWiseException(
							"Unable to run Stage.Init method "+method, e);
				} catch (InvocationTargetException e) {
					throw new StageWiseException(
							"Error while running Stage.Init method "+method,
							e.getCause());
				} finally {
					if (!accessible) {
						method.setAccessible(false);
					}
				}
				
				for (StageRunner stage : rv) {
					requires.add(stage);
				}
			}
		}
		
		
		// serialization information
		this.serialize = type.getAnnotation(Stage.Serialize.class) != null;
	}

	public StageDescriptor getStageDescriptor() {
		return descriptor;
	}

	public Collection<String> getExportFields() {
		return Collections.unmodifiableCollection(exportFields);
	}

	public Collection<String> getImportFields() {
		return Collections.unmodifiableCollection(importFields);
	}

	public Collection<StageRunner> getRequiredStages() {
		return Collections.unmodifiableCollection(requires);
	}

	public ArgumentBox getArgumentBox() {
		return ArgumentBoxes.fromInstance(instance);
	}


	public void setField(String name, Object value) {
		if (fields.containsKey(name)) {
			ReflectionUtils.setFieldValue(instance, fields.get(name), value);
		} else if (parameterImports.containsKey(name)) {
			parameterValues[parameterImports.get(name)] = value;
		} else if (methodExports.containsKey(name)) {
			throw new IllegalArgumentException("Field "+name+" is read-only");
		} else {
			throw new IllegalArgumentException("Unkown field "+name);
		}
	}

	public Object getField(String name) {
		if (fields.containsKey(name)) {
			return ReflectionUtils.getFieldValue(instance, fields.get(name));
		} else if (methodExports.containsKey(name)) {
			try {
				return methodExports.get(name).invoke(instance);
			} catch (Exception e) {
				throw new StageWiseException("Unable to retrieve value for "+name, e);
			}
		} else if (parameterImports.containsKey(name)) {
			throw new IllegalArgumentException("Field "+name+" is write-only");
		} else {
			throw new IllegalArgumentException("Unkown field "+name);
		}
	}

	public boolean shouldCheckpoint() {
		return serialize;
	}
	
	public void run(StageWise context, StageLineage lineage) {
		if (runMethod == null) {
			return;
		}
		
		boolean accessible = runMethod.isAccessible();
		if (!accessible) {
			runMethod.setAccessible(true);
		}
		
		try {
			runMethod.invoke(instance, parameterValues);
		} catch (IllegalArgumentException e) {
			throw new StageWiseException(
					"Could not invoke run method for "+instance.getClass(), e);
		} catch (IllegalAccessException e) {
			throw new StageWiseException(
					"Could not invoke run method for "+instance.getClass(), e);
		} catch (InvocationTargetException e) {
			if (e.getCause() == null) {
				throw new StageWiseException(
						"Exception while running "+instance.getClass(), e);
			} else if (!(e.getCause() instanceof RuntimeException)) {
				throw new StageWiseException(
						"Exception while running "+instance.getClass(), e.getCause());
			} else {
				// it's a runtime exception, so throw it directly
				throw (RuntimeException)e.getCause();
			}
		} finally {
			if (!accessible) {
				runMethod.setAccessible(false);
			}
		}
	}
}
